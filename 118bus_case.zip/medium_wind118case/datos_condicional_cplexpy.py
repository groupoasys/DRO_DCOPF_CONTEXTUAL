# -*- coding: utf-8 -*-
"""
Created on Mon Feb  3 18:14:29 2020

@author: Usuario
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Dec 11 10:34:36 2019

@author: Usuario
"""
import gurobipy as gp
from gurobipy import GRB
# import matplotlib.pyplot as plt
# plt.rcParams.update({'font.size': 10.7})
#plt.rc('axes', facecolor = 'white')
# from supress_log_file import custom_solver_factory
from docplex.mp.model import Model
import itertools
from itertools import product
import random
import time
import math
import random
import numpy as np
from numpy import linalg
# import scipy
import pandas as pd


import pandas as pd
# import scipy
import math
#from pyomo.environ import *
from collections import defaultdict
# from pyomo.opt import SolverStatus, TerminationCondition
# from matplotlib import pyplot as plt
# from sklearn.neighbors import KNeighborsRegressor
import numpy as np
import pandas as pd
# import scipy
import csv
import pandas as pd 
from random import randint
import power_tools
import pandas as pd
import numpy as np
import pandas as pd

#  lines - parameters of line
#  n_nodes - number of nodes
#  node_ref - reference node

def ptdf_matrix(lines,n_nodes,node_ref):

    list_nodes = list(range(1,n_nodes+1))
    
    X = pd.DataFrame(0,index=lines.index,columns=lines.index) # Diagonal matrix of branch reactances
    B = pd.DataFrame(0,index=list_nodes,columns=list_nodes)   # B is the Img of Admitance matrix
    A = pd.DataFrame(0,index=lines.index,columns=list_nodes)  # Incidence matrix
    
    for l in lines.index: 
        X.loc[l,l] = 1/lines.loc[l,'Suscep(MW)']
        from_bus = lines.loc[l,'from_bus']
        to_bus = lines.loc[l,'to_bus']
        A.loc[l,from_bus] = 1
        A.loc[l,to_bus]   = -1
        
    for n in list_nodes:
        node_list   = lines[lines.loc[:,'from_bus'] == n].loc[:,'to_bus'].to_list()
        line_susc   = lines[lines.loc[:,'from_bus'] == n].loc[:,'Suscep(MW)'].to_list()
        node_list   += lines[lines.loc[:,'to_bus'] == n].loc[:,'from_bus'].to_list()
        line_susc   += lines[lines.loc[:,'to_bus'] == n].loc[:,'Suscep(MW)'].to_list()
            
            
        B.loc[n,n]  = sum(line_susc[i] for i in range(len(node_list)))
        for i in range(len(node_list)):  
            B.loc[n,node_list[i]] = -line_susc[i]
    
    
    # Convert to matrix
    B = B.drop(index=node_ref)
    B = B.drop(columns=[node_ref],axis=1)
    A = A.drop(columns=[node_ref],axis=1)
    
    X_m = X.values
    B_m = B.values
    A_m = A.values
    
    S_f = np.dot(np.linalg.inv(X_m),np.dot(A_m,np.linalg.inv(B_m)))
    list_nodes.remove(node_ref)
    PTDF = pd.DataFrame(S_f,index=lines.index,columns=list_nodes)
    
    return PTDF


def real_dispatch_piecewise_mixed_cplex(m,index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_MATRIX,PTDF_gen,PTDF_wind,capline):
    
    
    set_i=set_knn_real
    tt=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf'))
    loadshed=m.continuous_var_dict(list(product(set_i,set_nbus)),lb=0)
    windspill=m.continuous_var_dict(list(product(set_i,set_nwind)),lb=0)
    reservas=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf'))
    # model.loadshed=pe.Var(model.i,model.nbus, within=pe.NonNegativeReals)
    # model.windspill=pe.Var(model.i,model.nwind,within=pe.NonNegativeReals)
    # model.reservas=pe.Var(model.i,model.ngen,within=pe.Reals)
     # r_D=m.addVars(list(set_ngen),name='r_D',lb=0)
     # r_U=m.addVars(list(set_ngen),name='r_U',lb=0)
     
    g=array_to_dict(dfgen)
    r_D=array_to_dict(dfr_D)
    r_U=array_to_dict(dfr_U)

    # tdata=m.addVars(list(product(set_i,set_ngen)),name='tt',lb=-float('inf'))  

    
    
     # (1/len(model.i))*sum( sum(tt[i,j]  for j in set_ngen)+sum(500*loadshed[i,b] for b in set_nbus) for i in set_i)+sum(coste_reserv_d[j]*(r_D[j])+coste_reserv_u[j]*(r_U[j])  for j in set_ngen)
    m.minimize( (1/len(set_i))*sum( sum(tt[i,j]  for j in set_ngen)+sum(500*loadshed[i,b] for b in set_nbus) for i in set_i)+sum(coste_reserv_d[j]*(r_D[j])+coste_reserv_u[j]*(r_U[j])  for j in set_ngen)  )


    # c1=m.addConstrs((  tt[i,j]>=sum(tdata[i,j] for j in set_ngen) for i in set_i   ))
    # model.slopes_gen[j,s]*(model.g[j]+model.reservas[i,j])+model.intercepts_gen[j,s]<=model.tt[i,j]
    c1=m.add_constraints((  tt[i,j]>=slopes_gen[j,s]*(g[j]+reservas[i,j])+intercepts_gen[j,s] for i in set_i for j in set_ngen for s in set_pieces ))
     

    # c3=m.addConstrs((  gmin[j]-(g[j]-beta[j]*sum(ydataknnproj_dict[i,l] for l in set_nwind))<=0 for i in set_i for j in set_ngen  ))

               
     # c4=m.addConstrs((  g[j]-beta[j]*sum(ydataknnproj_dict[i,l] for l in set_nwind)<=gmax[j] for i in set_i for j in set_ngen   ))

           
    c2=m.add_constraints((  reservas[i,j]>=-r_D[j] for i in set_i for j in set_ngen  ))

               
    c3=m.add_constraints((  reservas[i,j]<=r_U[j] for i in set_i for j in set_ngen   ))              
           
    
    
    c4=m.add_constraints((  windspill[i,mm]<=forecasted_wind[mm]+ydataknnreal[i-1,mm-1] for i in set_i for mm in set_nwind   ))
     
    c5=m.add_constraints((  loadshed[i,b]<=load[b] for i in set_i for b in set_nbus   ))
    
    
    
    
    
    PTDF_gen=PTDF_MATRIX.transpose() @ (array_matrixGbus)
    PTDF_wind=PTDF_MATRIX.transpose() @ (array_matrixHbus)
    


    lin_gen=[sum([ (PTDF_gen[k-1,j-1])*g[j] for j in set_ngen]) for k in set_nlines]        
    lin_load=[sum([ (PTDF_MATRIX[b-1,k-1])*(-load[b]) for b in set_nbus] ) for k in set_nlines]
            
    # lin_wind=[sum([ (PTDF_wind[k-1,mm-1]*(forecasted_wind[mm]+ydataknnreal[i-1,mm-1])) for mm in set_nwind]) for k in set_nlines]
    
     # PTDF_wind=PTDF_MATRIX.transpose() @ (array_matrixHbus)
     # gp.LinExpr([ (PTDF_MATRIX[b,k],-load[b]) for b in set_nbus])
     # gp.LinExpr([ (PTDF_gen[k,j],beta[j]*sum(omegadata[i,l] for l in set_nwind)) for j in set_ngen])      
     # c7=m.addConstrs((   -capline[k]-(sum(PTDF_dict[index_genbus[j],k]*(g[j]-beta[j]*sum(omegadata[i,l] for l in set_nwind)   ) for j in set_ngen)+sum(PTDF_dict[index_windbus[mm],k]*(forecasted_wind[mm]+omegadata[i,mm]   ) for mm in set_nwind)+sum(PTDF_dict[b,k]*(-load[b]) for b in  set_nbus))<=0 for i in set_i for k in set_nlines   ))              
    
    
    
    
    
    
    
    
    c7=m.add_constraints((  -capline[k]-( lin_gen[k-1]+m.sum( PTDF_gen[k-1,j-1]*reservas[i,j] for j in set_ngen)     +
                                     +sum([ (PTDF_wind[k-1,mm-1]*(forecasted_wind[mm]+ydataknnreal[i-1,mm-1])) for mm in set_nwind])-m.sum( PTDF_wind[k-1,m-1]*windspill[i,m] for m in set_nwind) +lin_load[k-1]+m.sum( (PTDF_MATRIX[b-1,k-1])*loadshed[i,b] for b in set_nbus) )   <=0 for i in set_i for k in set_nlines   ))              
    c8=m.add_constraints((  ( lin_gen[k-1]+m.sum( PTDF_gen[k-1,j-1]*reservas[i,j] for j in set_ngen)     +
                                     +sum([ (PTDF_wind[k-1,mm-1]*(forecasted_wind[mm]+ydataknnreal[i-1,mm-1])) for mm in set_nwind])-m.sum( PTDF_wind[k-1,m-1]*windspill[i,m] for m in set_nwind) +lin_load[k-1]+m.sum((PTDF_MATRIX[b-1,k-1])*loadshed[i,b] for b in set_nbus) )   <=capline[k] for i in set_i for k in set_nlines   ))        
     # c7=m.addConstrs(( -capline[k]-( gp.LinExpr([ (PTDF_gen[k,j],g[j]) for g in set_ngen])-(PTDF_gen[k,j],beta[j]*sum(omegadata[i,l] for l in set_nwind)) for g in set_ngen] +gp.LinExpr([ (PTDF_wind[k,mm],forecasted_wind[mm]+omegadata[i,mm]) for mm in set_nwind])+gp.LinExpr([ (PTDF_wind[k,mm],forecasted_wind[mm]+omegadata[i,mm]) for mm in set_nwind]) +gp.LinExpr([ (PTDF_MATRIX[b,k],-load[b]) for b in set_nbus]) )   <=0 for i in set_i for k in set_nlines ))
     # c8=m.addConstrs((   (sum(PTDF_dict[index_genbus[j],k]*(g[j]-beta[j]*sum(omegadata[i,l] for l in set_nwind)   ) for j in set_ngen)+sum(PTDF_dict[index_windbus[mm],k]*(forecasted_wind[mm]+omegadata[i,mm]   ) for mm in set_nwind)+sum(PTDF_dict[b,k]*(-load[b]) for b in  set_nbus))<=capline[k] for i in set_i for k in set_nlines   ))              
     # c8=m.addConstrs((  ( gp.LinExpr([ (PTDF_gen[k-1,j-1],g[j]) for j in set_ngen])-sum(ydataknnproj_dict[i,l] for l in set_nwind)*gp.LinExpr([ (PTDF_gen[k-1,j-1],beta[j]) for j in set_ngen])     +
     #                                 +sum([ (PTDF_wind[k-1,mm-1]*(forecasted_wind[mm]+ydataknnproj_dict[i,mm])) for mm in set_nwind]) +sum([ (PTDF_MATRIX[b-1,k-1])*(-load[b]) for b in set_nbus] ) )   <=capline[k] for i in set_i for k in set_nlines   ))              

           # return sum(model.reservas[i,j] for j in model.ngen)+sum(model.loadshed[i,b] for b in model.nbus)+sum(model.omega_dispatch[i,m]-model.windspill[i,m] for m in model.nwind)==0

  
    c9=m.add_constraints(( sum(reservas[i,j] for j in set_ngen)+sum(loadshed[i,b] for b in set_nbus)+sum(ydataknnreal[i-1,m-1]-windspill[i,m] for m in set_nwind)==0 for i in set_i   ))     
           
           


    return m

# import pyomo.environ as pe
from collections import defaultdict
# from pyomo.opt import SolverStatus, TerminationCondition
# from pyomo.opt.base import SolverFactory
from matplotlib import pyplot as plt
# from sklearn.neighbors import KNeighborsRegressor
import numpy as np
import pandas as pd
# import scipy
import csv
import pandas as pd 
from random import randint
# from scipy import array, linalg, dot
from numpy.linalg import inv
# plt.rcParams.update({'font.size': 12})
import numpy as np
import pandas as pd
import os
from collections import defaultdict
# from pyomo.opt import SolverStatus, TerminationCondition
# from matplotlib import pyplot as plt
# from sklearn.neighbors import KNeighborsRegressor
import numpy as np
import pandas as pd
# import scipy
import csv
import pandas as pd 
from random import randint
# from scipy import array, linalg, dot
from numpy.linalg import inv
# plt.rcParams.update({'font.size': 12})
import numpy as np
import pandas as pd
import os
# from scipy import integrate
# from scipy import linalg
from numpy.linalg import matrix_power
# from scipy.stats import norm,beta
# from scipy.stats.mstats import mquantiles
# from pyomo.opt import SolverStatus, TerminationCondition
import numpy as np
# import matplotlib.pyplot as plt
import numpy as np
from numpy import array,append
# from sklearn.cluster import KMeans
# from sklearn import datasets,svm
# from sklearn.svm import SVC
# from pyomo.environ import *
# import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
# from scipy import integrate
# from scipy.stats import beta
# from scipy.stats.mstats import mquantiles
# from pyomo.opt import SolverStatus, TerminationCondition
# from sklearn.linear_model import SGDClassifier
# from sklearn.svm import LinearSVC
# from sklearn.datasets.samples_generator import make_blobs
# from sklearn.decomposition import PCA
# from sklearn.multiclass import OneVsRestClassifier
# from sklearn import tree
# from scipy.stats import beta
def array_to_dict(array):
    shp=np.shape(array)
    length=len(shp)
    assert length>0 and length<4 
    dictionary={}
    if length==3:
        l,n,m=shp
        for k in range(l):
            for i in range(n):
                for j in range(m):
                    dictionary[str(k)+str(i)+str(j)]=array[k,i,j]
    elif length==2:
        n,m=shp 
        for i in range(n):
            for j in range(m):
                dictionary[(i+1,j+1)]=array[i,j]
    elif length==1:
        dictionary=dict([i+1,array[i]] for i in range(shp[0]))
    return dictionary
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='mdc opf two stage, unc. set norma infinito de radio W')
    
    ##Define sets##
    model.dim_vector_d=pe.Set(initialize=list(range(1,len(vector_d)+1)))
    model.i=pe.Set(initialize=set_i)
    model.i.pprint()
    model.p=pe.Set(initialize=set_p) #dim z
    model.p.pprint()
    model.l=pe.Set(initialize=set_l) #dim omega
    
    model.pieces_gen=pe.Set(initialize=set_pieces_gen)
    model.pieces_lines=pe.Set(initialize=set_pieces_lines)
    
    model.ngen=pe.Set(initialize=set_ngen)
    model.nwind=pe.Set(initialize=set_nwind)
    model.nbus=pe.Set(initialize=set_nbus)
    model.nbus.pprint()
    model.nlines=pe.Set(initialize=set_nlines)
    model.nlines.pprint()
    model.pieces=pe.Set(initialize=set_pieces)
    model.slopes_gen=pe.Param(model.ngen, model.pieces,initialize=slopes_gen)
    model.intercepts_gen=pe.Param(model.ngen, model.pieces,initialize=intercepts_gen)
#    model.p.pprint()
    model.gen_node=pe.Param(model.ngen,initialize=gen_node)
    model.gen_node.pprint()
    model.wind_node=pe.Param(model.nwind,initialize=wind_node)
    model.wind_node.pprint()
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=False, doc='Number of samples')
    model.N.pprint()
#    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
#    model.h.pprint()
    
#    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
#    model.b.pprint()
#   
    model.ro=pe.Param(initialize=ro,mutable=True)
    model.ro.pprint()
    # model.zdata=pe.Param(model.i,model.p,initialize=zdata, doc='Sample data points')
    # model.zdata.pprint()
    model.omegadata=pe.Param(model.i,model.l,initialize=omegadata, mutable=False, doc='Sample data points wind forecast error')
    model.Omegadata=pe.Param(model.i, initialize=Omegadata,mutable=False)
    model.Omegadata.pprint()
    # model.zpred=pe.Param(model.p, initialize=zpred)
    # model.zpred.pprint()
  
    # model.mass=pe.Param(initialize=mass)
    # model.mass.pprint()
    model.coste1=pe.Param(model.ngen,initialize=coste1,mutable=False)
    # model.coste1.pprint()
    model.coste2=pe.Param(model.ngen,initialize=coste2,mutable=False)
    # model.coste2.pprint()
    model.coste3=pe.Param(model.ngen,initialize=coste3,mutable=False)
    # model.coste3.pprint()
    model.coste_reserv_d=pe.Param(model.ngen,initialize=coste_reserv_d,mutable=False)
    model.coste_reserv_u=pe.Param(model.ngen,initialize=coste_reserv_u,mutable=False)
    # model.coste_reserv.pprint()
    model.loads=pe.Param(model.nbus,initialize=loads,mutable=False)
    model.forecasted_wind=pe.Param(model.nwind,initialize=forecasted_wind,mutable=False)
    
    model.liminf_Omega=pe.Param(initialize=liminf_Omega,mutable=False)
    model.limsup_Omega=pe.Param(initialize=limsup_Omega,mutable=False)
    # model.liminf_Omega.pprint()
    # model.limsup_Omega.pprint()
    
    # model.cost_GD=pe.Param(model.ngen, initialize=cost_GD,mutable=False)
    # model.cost_GU=pe.Param(model.ngen, initialize=cost_GU,mutable=False)
    # model.cost_RD=pe.Param(model.ngen, initialize=cost_RD,mutable=False)
    # model.cost_RU=pe.Param(model.ngen, initialize=cost_RU,mutable=False)
    # model.cost_LD=pe.Param(model.nlines, initialize=cost_LD,mutable=False)
    # # model.cost_LD.pprint()
    # model.cost_LU=pe.Param(model.nlines, initialize=cost_LU,mutable=False)
    # model.cost_LU.pprint()
    # model.PTDF=pe.Param(model.nbus,model.nlines,initialize=PTDF,mutable=False)
    # model.PTDF.pprint()
    # model.matrixGbus=pe.Param(model.nbus,model.ngen,  initialize=matrixGbus,mutable=False)
    # model.matrixHbus=pe.Param(model.nbus,model.nwind,  initialize=matrixHbus,mutable=False)
    # model.matrixHbus.pprint()
#    model.liminf_reserv=pe.Param(model.ngen, initialize=liminf_reserv)
#    model.limsup_reserv=pe.Param(model.ngen, initialize=limsup_reserv)
    model.gmin=pe.Param(model.ngen,initialize=gmin,mutable=False)
    # model.gmin.pprint()
    model.gmax=pe.Param(model.ngen,initialize=gmax,mutable=False)
#    model.rmin=pe.Param(model.ngen,initialize=rmin)
#    model.rmax=pe.Param(model.ngen,initialize=rmax)
    model.capline=pe.Param(model.nlines,initialize=capline,mutable=False)
    
    # model.B=pe.Param(model.nwind,model.nwind,  initialize=B,mutable=False)
    
    # model.size_support=pe.Param(initialize=size_supportset,mutable=False)
    # model.size_support.pprint()
    # model.coste_reserv=pe.Param(model.ngen,initialize=coste_reserv,mutable=False)
#    model.mass.pprint()
#    model.vecsupport=pe.Param(model.l,initialize=vecsupport)
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
#    model.x=pe.Var(within=pe.Reals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.Reals)
    # model.theta=pe.Var(within=pe.Reals)
    
    
#    model.lambda1=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.lambda2=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.mu=pe.Var(model.i, within=pe.Reals)
    model.z=pe.Var(model.i,model.nwind,within=pe.Reals)
    model.beta=pe.Var(model.ngen,within=pe.NonNegativeReals)
    model.g=pe.Var(model.ngen,within=pe.NonNegativeReals)
    
    model.r_D=pe.Var(model.ngen,within=pe.NonNegativeReals)
    model.r_U=pe.Var(model.ngen,within=pe.NonNegativeReals)
#    model.lambda1tilde=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.lambda2tilde=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.mutilde=pe.Var(model.i, within=pe.Reals)
#    
  
    
    
    
    


    
    model.vtilde=pe.Var(model.i,model.nwind,within=pe.Reals)
    model.v=pe.Var(model.i,model.nwind,within=pe.Reals)
    # model.GtildeD=pe.Var(model.nlines,model.nbus,model.nwind  ,within=pe.Reals )
    # model.GtildeU=pe.Var(model.nlines,model.nbus,model.nwind  ,within=pe.Reals )
#    model.eta=pe.Var(model.l,within=pe.NonNegativeReals)
#    model.etaprima=pe.Var(model.l,within=pe.NonNegativeReals)
    
#    model.vprima=pe.Var(model.i,model.p, within=pe.Reals)
#    model.wprima=pe.Var(model.i, within=pe.Reals)
#    model.w=pe.Var(model.i, within=pe.Reals)
#    model.wtilde=pe.Var(model.i, within=pe.Reals)
#    model.vprimatilde=pe.Var(model.i,model.p, within=pe.Reals)
#    model.wprimatilde=pe.Var(model.i, within=pe.Reals)
    # print("model.zdata[1,2]",model.zdata[1,2])
    ##Define pe.Objective and constrains rules##
    model.tdown=pe.Var(model.i,model.ngen,within=pe.Reals)
    model.tup=pe.Var(model.i,model.ngen,within=pe.Reals)
    model.tdata=pe.Var(model.i,model.ngen,within=pe.Reals)
    model.tt=pe.Var(model.i,within=pe.Reals)
    def obj_rule(model): 
        return (1/(model.N))*sum(model.tt[i]   for i in model.i)+sum(model.coste_reserv_d[j]*(model.r_D[j])+model.coste_reserv_u[j]*(model.r_U[j])  for j in model.ngen)
        
    

    
    
    
    
    # def con_rule_1(model,i):
    #     return model.mubarra[i]>=model.tt[i]
     
    # def con_rule_1b(model,i):
    #     return model.tt[i]>=sum(model.tdown[i,j] for j in model.ngen) +model.lamb*(model.liminf_Omega-model.Omegadata[i])
    
    # def con_rule_1c(model,i,j,s):
    #         return model.tdown[i,j]>=model.slopes_gen[j,s]*(model.g[j]-model.beta[j]*model.liminf_Omega)+model.intercepts_gen[j,s]


         
        

    # def con_rule_2b(model,i):
    #     return model.tt[i]>=sum(model.tup[i,j] for j in model.ngen)-model.lamb*(model.limsup_Omega-model.Omegadata[i])
        
    # def con_rule_2c(model,i,j,s):
    #     return model.tup[i,j]>=model.slopes_gen[j,s]*(model.g[j]-model.beta[j]*model.limsup_Omega)+model.intercepts_gen[j,s]

    # print("lista_index_outsideOmega", lista_index_outsideOmega)
    def con_rule_3b(model,i):
        return model.tt[i]>=sum(model.tdata[i,j] for j in model.ngen)

        
    def con_rule_3c(model,i,j,s):
        return model.tdata[i,j]>=model.slopes_gen[j,s]*(model.g[j]-model.beta[j]*model.Omegadata[i])+model.intercepts_gen[j,s]

    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    # model.con1 = pe.Constraint(model.i,  rule=con_rule_1)
    # model.con1.pprint()
    # model.con1b = pe.Constraint(model.i,  rule=con_rule_1b)
    # model.con1c = pe.Constraint(model.i,model.ngen,model.pieces,  rule=con_rule_1c)
    # model.con1b.pprint()
    
    # model.con2b = pe.Constraint(model.i,  rule=con_rule_2b)
    # model.con2c = pe.Constraint(model.i,model.ngen,model.pieces,  rule=con_rule_2c)
    
    model.con3b = pe.Constraint(model.i,  rule=con_rule_3b)
    model.con3c = pe.Constraint(model.i,model.ngen,model.pieces,  rule=con_rule_3c)
    
    
    

    
    
    
  
    

    
    def con_rule_6b(model,i,k):
        return model.gmin[k]-(model.g[k]-model.beta[k]*sum(model.omegadata[i,l] for l in model.nwind))<=0
    
    def con_rule_6c(model,i,k):
        return model.g[k]-model.beta[k]*sum(model.omegadata[i,l] for l in model.nwind)<=model.gmax[k]
            
     


                
    
      
    model.con6b = pe.Constraint( model.i,model.ngen, rule=con_rule_6b) 
    model.con6c = pe.Constraint( model.i,model.ngen, rule=con_rule_6c)
    
    def con_rule_7b(model,i,k):
        return -model.r_D[k]<=-model.beta[k]*sum(model.omegadata[i,l] for l in model.nwind)
    
    def con_rule_7c(model,i,k):
        return -model.beta[k]*sum(model.omegadata[i,l] for l in model.nwind)<=model.r_U[k]
            
     


                
    
      
    model.con7b = pe.Constraint( model.i,model.ngen, rule=con_rule_7b) 
    model.con7c = pe.Constraint( model.i,model.ngen, rule=con_rule_7c)
    
    
    
    
    
        
    def con_rule_10b(model,i,k):
        return -model.capline[k]-(sum(PTDF[gen_node[j],k]*(model.g[j]-model.beta[j]*sum(model.omegadata[i,l] for l in model.nwind)   ) for j in model.ngen)+sum(PTDF[wind_node[mm],k]*(model.forecasted_wind[mm]+model.omegadata[i,mm]   ) for mm in model.nwind)+sum(PTDF[b,k]*(-model.loads[b]) for b in  model.nbus))<=0
     
    def con_rule_10c(model,i,k):
        return sum(PTDF[gen_node[j],k]*(model.g[j]-model.beta[j]*sum(model.omegadata[i,l] for l in model.nwind)   ) for j in model.ngen)+sum(PTDF[wind_node[mm],k]*(model.forecasted_wind[mm]+model.omegadata[i,mm]   ) for mm in model.nwind)+sum(PTDF[b,k]*(-model.loads[b]) for b in  model.nbus)-model.capline[k]<=0
   
    # model.con10 = pe.Constraint( rule=con_rule_10)     
    model.con10b = pe.Constraint( model.i,model.nlines, rule=con_rule_10b) 
    
    
    
    model.con10c = pe.Constraint( model.i,model.nlines, rule=con_rule_10c) 
    
   
    
    
    
    
    
    def con_rule_balance(model):
        return sum(model.g[m] for m in model.ngen)==sum(model.loads[b] for b in model.nbus)-sum(model.forecasted_wind[j] for j in model.nwind)
    def con_part(model):
        return sum(model.beta[j] for j in model.ngen)==1
    model.con_rule_balance=pe.Constraint(rule=con_rule_balance)
  
    model.con_part=pe.Constraint(rule=con_part)
    
    # def con_rule_32(model,j):
    #     return model.r_D[j]<=model.gmax[j]
    # def con_rule_32b(model,j):
    #     return model.r_D[j]>=model.gmin[j]
    # def con_rule_33(model,j):
    #     return model.r_U[j]<=model.gmax[j]
    def con_rule_32(model,j):
        return model.g[j]+model.r_U[j]<=model.gmax[j]
    def con_rule_32b(model,j):
        return model.g[j]-model.r_D[j]>=0
    # def con_rule_33(model,j):
    #     return model.r_U[j]<=model.gmax[j]
    # def con_rule_33b(model,j):
    #     return model.r_U[j]>=model.gmin[j]
    model.con32 = pe.Constraint(model.ngen, rule=con_rule_32)
    model.con32b = pe.Constraint(model.ngen, rule=con_rule_32b)


    return model


def ptdf_matrix(lines,n_nodes,node_ref):

    list_nodes = list(range(1,n_nodes+1))
    
    X = pd.DataFrame(0,index=lines.index,columns=lines.index) # Diagonal matrix of branch reactances
    B = pd.DataFrame(0,index=list_nodes,columns=list_nodes)   # B is the Img of Admitance matrix
    A = pd.DataFrame(0,index=lines.index,columns=list_nodes)  # Incidence matrix
    
    for l in lines.index: 
        X.loc[l,l] = 1/lines.loc[l,'Suscep(MW)']
        from_bus = lines.loc[l,'from_bus']
        to_bus = lines.loc[l,'to_bus']
        A.loc[l,from_bus] = 1
        A.loc[l,to_bus]   = -1
        
    for n in list_nodes:
        node_list   = lines[lines.loc[:,'from_bus'] == n].loc[:,'to_bus'].to_list()
        line_susc   = lines[lines.loc[:,'from_bus'] == n].loc[:,'Suscep(MW)'].to_list()
        node_list   += lines[lines.loc[:,'to_bus'] == n].loc[:,'from_bus'].to_list()
        line_susc   += lines[lines.loc[:,'to_bus'] == n].loc[:,'Suscep(MW)'].to_list()
            
            
        B.loc[n,n]  = sum(line_susc[i] for i in range(len(node_list)))
        for i in range(len(node_list)):  
            B.loc[n,node_list[i]] = -line_susc[i]
    
    
    # Convert to matrix
    B = B.drop(index=node_ref)
    B = B.drop(columns=[node_ref],axis=1)
    A = A.drop(columns=[node_ref],axis=1)
    
    X_m = X.values
    B_m = B.values
    A_m = A.values
    
    S_f = np.dot(np.linalg.inv(X_m),np.dot(A_m,np.linalg.inv(B_m)))
    list_nodes.remove(node_ref)
    PTDF = pd.DataFrame(S_f,index=lines.index,columns=list_nodes)
    
    return PTDF


    








# n_mixt_real =10000
#


#cov_cond=np.eye(6)
#matriz_cond_product=np.dot(matriz_cond_raiz,matriz_cond_raiz)

# zprediccion_feature={}
# zprediccion_feature[1]=(1000-1000)/50
# zprediccion_feature[2]=(0.01-0.02)/0.01
# zprediccion_feature[3]=(5-math.exp(1/2))/(math.sqrt((math.exp(1)-1)*math.exp(1)))


# from scipy import stats
# from scipy.stats import multivariate_normal
#calculo el soporte de la distribucion par el modelo de kuhn
num_features=8
# num_dy=6
set_dz=range(1,num_features+1)
# set_dy=range(1,num_dy +1)
# set_dx=set_dy
set_k=range(1,2+1)
# 





muestra_real_conjunta=[]
maxgen_nwind1=200
maxgen_nwind2=200
maxgen_nwind3=200
maxgen_nwind4=200
maxgen_nwind5=200
maxgen_nwind6=200
maxgen_nwind7=200
maxgen_nwind8=200
# maxgen_nwind5=400
# maxgen_nwind6=250

# list_forecasted_wind=[100,200,50,150,80,100]

list_forecasted_wind=[maxgen_nwind1*0.9,maxgen_nwind2*0.9,maxgen_nwind3*0.9,maxgen_nwind4*0.9,maxgen_nwind5*0.9,maxgen_nwind6*0.9,maxgen_nwind7*0.9,maxgen_nwind8*0.9]
forecasted_wind=array_to_dict(list_forecasted_wind)
zpred={}
zpred[1]=forecasted_wind[1]
zpred[2]=forecasted_wind[2]
zpred[3]=forecasted_wind[3]
zpred[4]=forecasted_wind[4]
zpred[5]=forecasted_wind[5]
zpred[6]=forecasted_wind[6]
zpred[7]=forecasted_wind[7]
zpred[8]=forecasted_wind[8]
support_liminfconjunta=array_to_dict([-maxgen_nwind1,-maxgen_nwind2,-maxgen_nwind3,-maxgen_nwind4,-maxgen_nwind5,-maxgen_nwind6,-maxgen_nwind7,-maxgen_nwind8])
support_limsupconjunta=array_to_dict([maxgen_nwind1,maxgen_nwind2,maxgen_nwind3,maxgen_nwind4,maxgen_nwind5,maxgen_nwind6,maxgen_nwind7,maxgen_nwind8])

support_liminfcond=array_to_dict([-zpred[1],-zpred[2],-zpred[3],-zpred[4],-zpred[5],-zpred[6],-zpred[7],-zpred[8]])
support_limsupcond=array_to_dict([maxgen_nwind1-zpred[1],maxgen_nwind2-zpred[2],maxgen_nwind3-zpred[3],maxgen_nwind4-zpred[4],maxgen_nwind4-zpred[5],maxgen_nwind4-zpred[6],maxgen_nwind4-zpred[7],maxgen_nwind4-zpred[8]])


#construyo matriz del soporte de la condicional CTy d









liminf_Omega_conjunta=-maxgen_nwind1-maxgen_nwind2-maxgen_nwind3-maxgen_nwind4-maxgen_nwind5-maxgen_nwind6-maxgen_nwind7-maxgen_nwind8

limsup_Omega_conjunta=maxgen_nwind1+maxgen_nwind2+maxgen_nwind3+maxgen_nwind4+maxgen_nwind5+maxgen_nwind6+maxgen_nwind7+maxgen_nwind8

liminf_Omega_cond=-zpred[1]-zpred[2]-zpred[3]-zpred[4]-zpred[5]-zpred[6]-zpred[7]-zpred[8]

limsup_Omega_cond=maxgen_nwind1-zpred[1]+maxgen_nwind2-zpred[2]+maxgen_nwind3-zpred[3]+maxgen_nwind4-zpred[4]+maxgen_nwind5-zpred[5]+maxgen_nwind6-zpred[6]+maxgen_nwind7-zpred[7]+maxgen_nwind8-zpred[8]

Nwind=8
Nfeature=8




# df=(pd.read_csv("windpowermeasurements.csv")).dropna(how='any',axis=0)

# df=(pd.read_csv("dataset_wind_europe_2015_2019.csv", usecols = ['DK1_won_da','DK1_woff_da','DK2_won_da','DK2_woff_da','SE3_won_da','SE4_won_da','DK1_won_real','DK1_woff_real','DK2_won_real','DK2_woff_real','SE3_won_real','SE4_won_real'],)).dropna(how='any',axis=0)
# df=(pd.read_csv("dataset_wind_europe_2015_2019.csv")).dropna(how='any',axis=0)
df=pd.read_csv("datos_features_conjunta.csv").dropna(how='any',axis=0)
# df=df[(df[df.columns] > 0).all(axis=1)]
# listcols=["wp2","wp3","wp4","wp5","wp6","wp7"]
# df=df[(df[df.columns] > 0).all(axis=1)]
# df=(pd.read_csv("windpowermeasurements.csv", usecols =listcols,)).dropna(how='any',axis=0)
df[df <= 0.05] = 0.05
df[df >= 0.95] = 0.95
# df[df == 'NA'] = 0.05
# df['DK1_won_da'].interpolate(method='polynomial', order=1)
# df['DK2_won_da'].interpolate(method='polynomial', order=1)
times_muestra_conjunta=df.shape[0]
# times_muestra_conjunta=30000
# df2=(df[0:times_muestra_conjunta])
df2=df.copy()
# times_muestra_conjunta=df2.shape[0]
# max_valuew1 = df2["DK1_won_da"].max()
# max_valuew2 = df2["DK1_woff_da"].max()
# max_valuew3 = df2["DK2_won_da"].max()
# max_valuew4 = df2["DK2_woff_da"].max()
# max_valuew5 = df2["SE3_won_da"].max()
# max_valuew6 = df2["SE4_won_da"].max()




# max_valuew1real = df2["DK1_won_real"].max()
# max_valuew2real = df2["DK1_woff_real"].max()
# max_valuew3real = df2["DK2_won_real"].max()
# max_valuew4real = df2["DK2_woff_real"].max()
# max_valuew5real = df2["SE3_won_real"].max()
# max_valuew6real = df2["SE4_won_real"].max()

# normalizo:
    
    
# df2["DK1_won_da"]=(1/max_valuew1)*df2["DK1_won_da"]
# df2["DK1_woff_da"]=(1/max_valuew2)*df2["DK1_woff_da"]
# df2["DK2_won_da"]=(1/max_valuew3)*df2["DK2_won_da"]
# df2["DK2_woff_da"]=(1/max_valuew4)*df2["DK2_woff_da"]
# df2["SE3_won_da"]=(1/max_valuew5)*df2["SE3_won_da"]
# df2["SE4_won_da"]=(1/max_valuew6)*df2["SE4_won_da"]

# df2["DK1_won_real"]=(1/max_valuew1real)*df2["DK1_won_real"]
# df2["DK1_woff_real"]=(1/max_valuew2real)*df2["DK1_woff_real"]
# df2["DK2_won_real"]=(1/max_valuew3real)*df2["DK2_won_real"]
# df2["DK2_woff_real"]=(1/max_valuew4real)*df2["DK2_woff_real"]
# df2["SE3_won_real"]=(1/max_valuew5real)*df2["SE3_won_real"]
# df2["SE4_won_real"]=(1/max_valuew6real)*df2["SE4_won_real"]


# errores ya normalizados
# df2['omega1']=df2["DK1_won_real"]-df2["DK1_won_da"]
# df2['omega2']=df2["DK1_woff_real"]-df2["DK1_woff_da"]
# df2['omega3']=df2["DK2_won_real"]-df2["DK2_won_da"]
# df2['omega4']=df2["DK2_woff_real"]-df2["DK2_woff_da"]
# df2['omega5']=df2["SE3_won_real"]-df2["SE3_won_da"]
# df2['omega6']=df2["SE4_won_real"]-df2["SE4_won_da"]






#multiplico por la cap maxima
# df2["DK1_won_da"]=maxgen_nwind1*df2["DK1_won_da"]
# df2["DK1_woff_da"]=maxgen_nwind2*df2["DK1_woff_da"]
# df2["DK2_won_da"]=maxgen_nwind3*df2["DK2_won_da"]
# df2["DK2_woff_da"]=maxgen_nwind4*df2["DK2_woff_da"]
# df2["SE3_won_da"]=maxgen_nwind5*df2["SE3_won_da"]
# df2["SE4_won_da"]=maxgen_nwind6*df2["SE4_won_da"]

# df2["omega1"]=maxgen_nwind1*df2["omega1"]
# df2["omega2"]=maxgen_nwind2*df2["omega2"]
# df2["omega3"]=maxgen_nwind3*df2["omega3"]
# df2["omega4"]=maxgen_nwind4*df2["omega4"]
# df2["omega5"]=maxgen_nwind5*df2["omega5"]
# df2["omega6"]=maxgen_nwind6*df2["omega6"]


# zdata1=df2['DK1_won_da'].values
# zdata2=df2['DK1_woff_da'].values
# zdata3=df2['DK2_won_da'].values
# zdata4=df2['DK2_woff_da'].values
# zdata5=df2['SE3_won_da'].values
# zdata6=df2['SE4_won_da'].values

# omega1=df2['omega1'].values
# omega2=df2['omega2'].values
# omega3=df2['omega3'].values
# omega4=df2['omega4'].values
# omega5=df2['omega5'].values
# omega6=df2['omega6'].values

# Omega=(df2['omega1']+df2['omega2']+df2['omega3']+df2['omega4']+df2['omega5']+df2['omega6']).values


zdata1=df2['f1'].values
zdata2=df2['f10'].values
zdata3=df2['f3'].values
zdata4=df2['f5'].values

zdata5=df2['f2'].values
zdata6=df2['f4'].values
zdata7=df2['f9'].values
zdata8=df2['f6'].values

# zdata5=df2['f5'].values
# zdata6=df2['f6'].values
#correlo los datos
# from scipy.linalg import cholesky               

# from scipy.stats import random_correlation
matrixSize = 4

# Arandom= np.random.rand(matrixSize, matrixSize)
# corrmatrix  =random_correlation.rvs((1,2,0.25,1.1,0.4,0.25))# corrmatrix=np.array([[ 1. ,  0.74903226,  0.96385643, 0.69888852],
#         [ 0.74903226,  1.  ,  0.79156355, 0.60378441],
#     [ 0.96385643,  0.79156355 ,  1, 0.65834194],
#     [ 0.69888852,  0.60378441,  0.65834194,1 ]])

# corrmatrix=np.array([[ 1.        , 0.05867069, 0.076225272,  0.0498951, -0.054927931,0.72254816 ],
#         [0.05867069,  1.        ,  0.7449723, 0.028276822,  -0.24330941, 0.026264467],
#         [0.076225272,  0.7449723,  1.        , 0.24240607,  0.017499963,0.4282097],
#         [ 0.0498951, 0.028276822, 0.24240607,  1.        , 0.08955274,-0.0812716  ],
#         [-0.054927931,  -0.24330941,  0.017499963, 0.08955274,  1.        ,0.052024766],
#         [0.72254816 ,  0.026264467,  0.4282097, -0.0812716  ,  0.052024766,1.        ]])
# corrmatrix=np.array([[ 1. ,  0.44903226,  0.76385643, 0.69888852],
#         [ 0.44903226,  1.  ,  0.79156355, 0.20378441],
#     [ 0.76385643,  0.79156355 ,  1, 0.5834194],
#     [ 0.69888852,  0.20378441,  0.5834194,1 ]])

# from scipy.stats import truncnorm

# population = [1, 2]
# weights = [0.5,0.5]
# weights2 = [0.3,0.5,0.2]
# weights3 = [0.5,0.2,0.3]
# weights4 = [0.2,0.3,0.5]

# samples_mixture=[choices(population, weights)[0] for x in range(100000)]
# samples_mixture2=[choices(population, weights2)[0] for x in range(100000)]

import random
from random import randint
# zz1 = truncnorm.rvs(0,1, loc=0, scale=1, size=6)
# muestra=np.zeros(shape=(times_muestra_conjuntaz,6))
# muestra=np.zeros(shape=(10,6))
# for j in range(times_muestra_conjuntaz):
#     print("j features",j)
#     if randint(0,1)==0:
#         muestra[j,:]=truncnorm.rvs(0.7,0.99, loc=0, scale=1, size=6)
#     else:
#         muestra[j,:]=truncnorm.rvs(0.25,0.6, loc=0, scale=1, size=6)
#calculo
# for j in range(times_muestra_conjuntaz):
#     print("j features",j)
#     muestra[j,:]=truncnorm.rvs(0.01,0.99, loc=0, scale=1, size=6)
  

# Generate samples from three independent normally distributed random
# variables (with mean 0 and std. dev. 1).


# We need a matrix `c` for which `c*c^T = r`.  We can use, for example,
# the Cholesky decomposition, or the we can construct `c` from the
# eigenvectors and eigenvalues.


# cmatrixchol = cholesky(corrmatrix, lower=True)

# print("correlo los datos")
# Convert the data to correlated random variables. 
# zz2 = np.dot(cmatrixchol, (df2.values).transpose()).transpose()  
# zz2=np.clip(zz2,0.01,0.99)

# zdata1=zz2[:,0]
# zdata2=zz2[:,1]
# zdata3=zz2[:,2]
# zdata4=zz2[:,3]
# zdata5=zz2[:,4]
# zdata6=zz2[:,5]
# np.savetxt("muestra_real_conjunta_corrz.csv", zz2, delimiter=",")




# omega1=df2['omega1'].values
# omega2=df2['omega2'].values
# omega3=df2['omega3'].values
# omega4=df2['omega4'].values
# omega5=df2['omega5'].values
# omega6=df2['omega6'].values

# Omega=(df2['omega1']+df2['omega2']+df2['omega3']+df2['omega4']+df2['omega5']+df2['omega6']).values
# import seaborn as sns                  
# sns.pairplot(df, diag_kind="kde")    

# g = sns.PairGrid(pd.DataFrame(zdataconjunta), diag_sharey=False, corner=True)
# g.map_lower(sns.scatterplot)
# g.map_diag(sns.kdeplot)


load_array=pd.read_csv("myload_118.csv", header=None).values
Nbus=load_array.shape[1]
load_array=load_array.flatten()
peak_load=35
load=array_to_dict(peak_load*load_array)

# load[116]=20
# load[12]=20
# load[34]=20
# load[82]=20
# load[87]=20
# load[55]=60

print("demanda total=",sum(load.values()))
print("penetraccion de eolica-->", sum(zpred.values()) /sum(load.values()))
Nlines=186
gen_118=pd.read_csv("mygen_118.csv", header=None)
Ngen=gen_118.shape[0]-1

Nsamples=100

indices=pd.read_csv("indices100.csv", header=None).values   







set_i=range(1,Nsamples+1)
set_l=range(1,Nwind +1 )
set_p=range(1,Nfeature+1)


set_ngen=range(1,Ngen+1)

set_nwind=range(1,Nwind+1)
set_nbus=range(1,Nbus+1)
set_nlines=range(1,Nlines+1)

set_pieces_gen=range(1,Ngen+1+1)
set_pieces_lines=range(1,Nlines+1+1)




npiecesgen=3
set_pieces=range(1,npiecesgen+1)
slopes_gen=np.empty((len(set_ngen),len(set_pieces)), dtype=object)
intercepts_gen=np.empty((len(set_ngen),len(set_pieces)), dtype=object)

gmin=array_to_dict((gen_118.iloc[1:Ngen+2,5]).values.astype(np.float))
gmax=array_to_dict(gen_118.iloc[1:Ngen+2,6].values.astype(np.float))

coste1=array_to_dict(gen_118.iloc[1:Ngen+2,2].values.astype(np.float))
coste2=array_to_dict(gen_118.iloc[1:Ngen+2,3].values.astype(np.float))
coste3=array_to_dict(gen_118.iloc[1:Ngen+2,4].values.astype(np.float))




coste_reserv_d=array_to_dict(1*gen_118.iloc[1:Ngen+2,7].values.astype(np.float))
coste_reserv_u=array_to_dict(1*gen_118.iloc[1:Ngen+2,8].values.astype(np.float))


index_genbus=array_to_dict((gen_118.iloc[1:Ngen+2,1]).values.astype(int))

array_indexgenbus=(gen_118.iloc[1:Ngen+2,1]).values.astype(int)


index_busgen={key: {} for key in set_nbus}
for jj in set_nbus:
    index_busgen[jj]=list([k for k,v in index_genbus.items() if v==jj])


# plt.hist(muestra_real_conjunta[:,[4]],bins=100,density=True),plt.hist(muestra_real_cond[:,[0]],bins=100,density=True)

# plt.hist(muestra_real_conjunta[:,[5]],bins=100,density=True),plt.hist(muestra_real_cond[:,[1]],bins=100,density=True)
# plt.hist(muestra_real_conjunta[:,[6]],bins=100,density=True),plt.hist(muestra_real_cond[:,[2]],bins=100,density=True)
# plt.hist(muestra_real_conjunta[:,[7]],bins=100,density=True),plt.hist(muestra_real_cond[:,[3]],bins=100,density=True)



# import pwlf
# for j in set_ngen:
#     print("j",j)
#     c1=coste1[j]
#     c2=coste2[j]
#     c3=coste3[j]
#     x_grid= np.linspace(gmin[j],gmax[j], 100)
#     y_grid=np.array([c1*x**2+c2*x+c3 for x in x_grid])
#     # print("ygrid",y_grid)
#     # # axes.set_yscale('log')  
#     # plt.figure()
#     # plt.axis('auto')
#     plt.plot(x_grid,y_grid)
#     # plt.show()
#     #fit your data (x and y)
#     myPWLF = pwlf.PiecewiseLinFit(x_grid, y_grid)
    
#     # #fit the data for n line segments
#     breaks= myPWLF.fit(npiecesgen)
#     # print("breaks",breaks)
#     # calculate slopes
#     slopes = myPWLF.calc_slopes()
#     intercepts=myPWLF.intercepts
#     for s in range(npiecesgen):
#         slopes_gen[j-1,s]=slopes[s]
#         intercepts_gen[j-1,s]=intercepts[s]
    
# print("slopes_gen",slopes_gen)

# print("intercepts_gen",intercepts_gen)
# print("slopes_gen antes",slopes_gen)

# print("intercepts_gen antes",intercepts_gen)

# np.savetxt("slopes_gen.csv", slopes_gen, delimiter=",")


slopes_gen=array_to_dict(pd.read_csv("slopes_gen.csv", header=None).values)


# np.savetxt("intercepts_gen.csv", intercepts_gen, delimiter=",")


intercepts_gen=array_to_dict(pd.read_csv("intercepts_gen.csv", header=None).values)






import cProfile
import pstats
import io
# from pyomo.common.timing import TicTocTimer, report_timing
# from pyomo.opt.results import assert_optimal_termination
    
    
    
    
    
    
    
    
wind_118node=pd.read_csv("wind_118node.csv", header=None)
index_windbus=array_to_dict((wind_118node.iloc[1:Nwind+2,1]).values.astype(int))

index_buswind={key: {} for key in set_nbus}
for jj in set_nbus:
    index_buswind[jj]=list([k for k,v in index_windbus.items() if v==jj])
    
 
    
 
matrixC=np.zeros((2*Nwind, Nwind))
matrixC[0,0]=-1
matrixC[1,0]=1
matrixC[2,1]=-1
matrixC[3,1]=1
matrixC[4,2]=-1
matrixC[5,2]=1
matrixC[6,3]=-1
matrixC[7,3]=1
matrixC[8,4]=-1
matrixC[9,4]=1
matrixC[10,5]=-1
matrixC[11,5]=1
matrixC[12,6]=-1
matrixC[13,6]=1
matrixC[14,7]=-1
matrixC[15,7]=1



vectord=np.zeros((2*Nwind,))

vectord[0]=-support_liminfcond[1]
vectord[1]=support_limsupcond[1]
vectord[2]=-support_liminfcond[2]
vectord[3]=support_limsupcond[2]
vectord[4]=-support_liminfcond[3]
vectord[5]=support_limsupcond[3]
vectord[6]=-support_liminfcond[4]
vectord[7]=support_limsupcond[4]
vectord[8]=-support_liminfcond[5]
vectord[9]=support_limsupcond[5]
vectord[10]=-support_liminfcond[6]
vectord[11]=support_limsupcond[6]
vectord[12]=-support_liminfcond[7]
vectord[13]=support_limsupcond[7]
vectord[14]=-support_liminfcond[8]
vectord[15]=support_limsupcond[8]



CT=array_to_dict(matrixC.transpose())
d_vector=array_to_dict(vectord)    
 
    
vectordconjunta=np.zeros((2*Nwind,))

vectordconjunta[0]=-support_liminfconjunta[1]
vectordconjunta[1]=support_limsupconjunta[1]
vectordconjunta[2]=-support_liminfconjunta[2]
vectordconjunta[3]=support_limsupconjunta[2] 
vectordconjunta[4]=-support_liminfconjunta[3]
vectordconjunta[5]=support_limsupconjunta[3]
vectordconjunta[6]=-support_liminfconjunta[4]
vectordconjunta[7]=support_limsupconjunta[4] 
vectordconjunta[8]=-support_liminfconjunta[5]
vectordconjunta[9]=support_limsupconjunta[5]
vectordconjunta[10]=-support_liminfconjunta[6]
vectordconjunta[11]=support_limsupconjunta[6]    
vectordconjunta[12]=-support_liminfconjunta[7]
vectordconjunta[13]=support_limsupconjunta[7]
vectordconjunta[14]=-support_liminfconjunta[8]
vectordconjunta[15]=support_limsupconjunta[8] 


d_vectorconjunta=array_to_dict(vectordconjunta)   
    
 
    
####creo la muestra conjunta
# from scipy.stats import binom

# # from scipy.stats import binom
# from random import choices
# population = [1, 2, 3]
# weights = [0.2,0.5,0.3]
# weights2 = [0.3,0.5,0.2]
# weights3 = [0.5,0.2,0.3]
# weights4 = [0.2,0.3,0.5]

# samples_mixture=[choices(population, weights)[0] for x in range(100000)]
# samples_mixture2=[choices(population, weights2)[0] for x in range(100000)]
# samples_mixture3=[choices(population, weights3)[0] for x in range(100000)]
# samples_mixture4=[choices(population, weights4)[0] for x in range(100000)]

# # zdata1=[np.random.uniform(0.15,0.2,1) if x==1 else np.random.uniform(0.45,0.55,1) if x==2 else np.random.uniform(0.8,0.85,1) if x==3 for x in samples_mixture]
# zdata1=[]
# for kk in samples_mixture:
#     if kk==1:
#         num_mixture_sample=np.random.normal(0.1,0.03,1)
#     elif kk==2:
#         num_mixture_sample=np.random.normal(0.5,0.03,1)
#     else:
#         num_mixture_sample=np.random.normal(0.9,0.03,1)
#     zdata1.append(num_mixture_sample)
# zdata2=[]
# for kk in samples_mixture2:
#     if kk==1:
#         num_mixture_sample2=np.random.normal(0.1,0.03,1)
#     elif kk==2:
#         num_mixture_sample2=np.random.normal(0.5,0.03,1)
#     else:
#         num_mixture_sample2=np.random.normal(0.9,0.03,1)
#     # zdata1.append(num_mixture_sample)    
    
#     zdata2.append(num_mixture_sample2)
#     # zdata3.append(num_mixture_sample3)
#     # zdata4.append(num_mixture_sample4)
# zdata3=[]
# for kk in samples_mixture3:
#     if kk==1:
#         num_mixture_sample3=np.random.normal(0.1,0.03,1)
#     elif kk==2:
#         num_mixture_sample3=np.random.normal(0.5,0.03,1)
#     else:
#         num_mixture_sample3=np.random.normal(0.9,0.03,1)
#     # zdata1.append(num_mixture_sample)    
    
#     zdata3.append(num_mixture_sample3)
    
# zdata4=[]
# for kk in samples_mixture2:
#     if kk==1:
#         num_mixture_sample4=np.random.normal(0.1,0.03,1)
#     elif kk==2:
#         num_mixture_sample4=np.random.normal(0.5,0.03,1)
#     else:
#         num_mixture_sample4=np.random.normal(0.9,0.03,1)
#     # zdata1.append(num_mixture_sample)    
    
#     zdata4.append(num_mixture_sample4)
# zdata1=np.array([x for x in lk])
# zdata2=np.array([])
len_muestraconjunta=0
j=0


# from scipy.optimize import fsolve
import math



def equations(p,zprediccion,sigma):
    a, b = p
    return (zprediccion-a/(a+b), sigma**2-(a*b)/((a+b+1)*(a+b)**2))

# x, y =  fsolve(equations, (0.5, 0.5), args=(zprediccion,sigma))

# print equations((x, y))      
j=0   

def sigma_param(p1,p2,zpred):
    
    sigma=math.sqrt(zpred*(1-zpred)*(-p2*zpred**2+p1*zpred))
    return sigma

while len(muestra_real_conjunta)<times_muestra_conjunta:
    vector_muestra=[]
    
    # print("j",j)
    
    
 #    sigma_w1=sigma_param(1,0.35,zdata1[j])
 # #predicion de 6 horas
 #    sigma_w2=sigma_param(1,0.35,zdata2[j])
 #   #predicion de 6  horas
 #    sigma_w3= sigma_param(1,0.35,zdata3[j])
 # #predicion de 6 horas
 #    sigma_w4=sigma_param(1,0.35,zdata4[j])
 
    sigma_w1=(0.2*zdata1[j]+0.02) 
    sigma_w2=(0.2*zdata2[j]+0.02) 
    sigma_w3=(0.2*zdata3[j]+0.02)
    sigma_w4=(0.2*zdata4[j]+0.02)  #predicion de 6 horas
    sigma_w5=(0.2*zdata5[j]+0.02)  #predicion de 6 horas
    sigma_w6=(0.2*zdata6[j]+0.02)  #predicion de 6 horas
    sigma_w7=(0.2*zdata7[j]+0.02)
    sigma_w8=(0.2*zdata8[j]+0.02)
    # sigma_w1=(0.1818*zdata1[j]+0.01818)  #predicion de 6 horas
    # sigma_w2=(0.1818*zdata2[j]+0.01818)   #predicion de 6 horas
    # sigma_w3=(0.1818*zdata3[j]+0.01818)  #predicion de 6 horas
    # sigma_w4=(0.1818*zdata4[j]+0.01818)   #predicion de 6 horas
    # sigma_w5=(0.1818*zdata5[j]+0.01818)  #predicion de 6 horas
    # sigma_w6=(0.1818*zdata6[j]+0.01818)  #predicion de 6 horas
    
    sigma2_w1=(sigma_w1)**2 #predicion de 6 horas
    sigma2_w2=(sigma_w2)**2   #predicion de 6 horas
    sigma2_w3=(sigma_w3)**2  #predicion de 6 horas
    sigma2_w4=(sigma_w4)**2   #predicion de 6 horas
    sigma2_w5=(sigma_w5)**2  #predicion de 6 horas
    sigma2_w6=(sigma_w6)**2   #predicion de 6 horas
    sigma2_w7=(sigma_w7)**2  #predicion de 6 horas
    sigma2_w8=(sigma_w8)**2   #predicion de 6 horas
    
    # alpha_w5,beta_w5=getAlphaBeta(zdata5[j],sigma_w5)
    
    # alpha_w6,beta_w6=getAlphaBeta(zdata6[j],sigma_w6)
    # alpha_w1,beta_w1=fsolve(equations, (1, 0.5), args=(zdata1[j],sigma_w1))
    
    # alpha_w2,beta_w2=fsolve(equations, (1, 0.5), args=(zdata2[j],sigma_w2))
    
    # alpha_w3,beta_w3=fsolve(equations, (1, 0.5), args=(zdata3[j],sigma_w3))
    
    # alpha_w4,beta_w4=fsolve(equations, (1, 0.5), args=(zdata4[j],sigma_w4))
    
    # alpha_w5,beta_w5=fsolve(equations, (5, 0.5), args=(zdata5[j],sigma_w5))
    
    # alpha_w6,beta_w6=fsolve(equations, (5, 0.5), args=(zdata6[j],sigma_w6))
    alpha_w1=((1-zdata1[j])*(zdata1[j])**2)/(sigma2_w1)-zdata1[j]
    
   
    beta_w1=((1-zdata1[j])/zdata1[j])*alpha_w1
        
    alpha_w2=((1-zdata2[j])*(zdata2[j])**2)/(sigma2_w2)-zdata2[j]
    beta_w2=(((zdata2[j]))*(1-zdata2[j])**2)/(sigma2_w2)+zdata2[j]-1
    
    
    
    
    
    alpha_w3=((1-zdata3[j] )*(zdata3[j] )**2)/(sigma2_w3)-zdata3[j] 
    
   
    beta_w3=((zdata3[j])*(1-zdata3[j] )**2)/(sigma2_w3)+zdata3[j] -1
    
    alpha_w4=((1-zdata4[j])*(zdata4[j])**2)/(sigma2_w4)-zdata4[j]
    beta_w4=((zdata4[j])*(1-zdata4[j])**2)/(sigma2_w4)+zdata4[j]-1

    alpha_w5=((1-zdata5[j])*(zdata5[j])**2)/(sigma2_w5)-zdata5[j]
    beta_w5=((zdata5[j])*(1-zdata5[j])**2)/(sigma2_w5)+zdata5[j]-1

    alpha_w6=((1-zdata6[j])*(zdata6[j])**2)/(sigma2_w6)-zdata6[j]
    beta_w6=((zdata6[j])*(1-zdata6[j])**2)/(sigma2_w6)+zdata6[j]-1
    
    
    alpha_w7=((1-zdata7[j])*(zdata7[j])**2)/(sigma2_w7)-zdata7[j]
    beta_w7=((zdata7[j])*(1-zdata7[j])**2)/(sigma2_w7)+zdata7[j]-1

    alpha_w8=((1-zdata8[j])*(zdata8[j])**2)/(sigma2_w8)-zdata8[j]
    beta_w8=((zdata8[j])*(1-zdata8[j])**2)/(sigma2_w8)+zdata8[j]-1

    
    
    # print("alpha_1",alpha_w1)
    # print("beta_1",beta_w1)
    # print("alpha_2",alpha_w2)
    # print("beta_2",beta_w2)
    # import pdb
    # pdb.set_trace()
    # vector_muestra.append(zdata1[j])
    # vector_muestra.append(zdata2[j])
    # vector_muestra.append(zdata3[j])
    # vector_muestra.append(zdata4[j])
    # vector_muestra.append(zdata5[j])    
    # vector_muestra.append(zdata6[j])    
    # vector_muestra.append(omega1[j])
    # vector_muestra.append(omega2[j])
    # vector_muestra.append(omega3[j])
    # vector_muestra.append(omega4[j])
    # vector_muestra.append(omega5[j])
    # vector_muestra.append(omega6[j])
    # vector_muestra.append(Omega[j])
    # muestra_real_conjunta.append(vector_muestra)
    # len_muestraconjunta=len_muestraconjunta+1
    if alpha_w1>=0 and beta_w1>=0 and alpha_w2>=0 and beta_w2>=0 and alpha_w3>=0 and beta_w3>=0 and alpha_w4>=0 and beta_w4>=0    :
        # print("alpah bien")
        

        omega1=(np.random.beta(alpha_w1,beta_w1) -zdata1[j]  )
    

        omega2=(np.random.beta(alpha_w2,beta_w2) -zdata2[j]  )
        

        omega3=(np.random.beta(alpha_w3,beta_w3) -zdata3[j]  )
    

        omega4=(np.random.beta(alpha_w4,beta_w4) -zdata4[j]  )
    
        omega5=(np.random.beta(alpha_w5,beta_w5) -zdata5[j]  )
        omega6=(np.random.beta(alpha_w6,beta_w6) -zdata6[j]  )
        
        omega7=(np.random.beta(alpha_w7,beta_w7) -zdata7[j]  )
        omega8=(np.random.beta(alpha_w8,beta_w8) -zdata8[j]  )
        
    
    
    
        vector_muestra.append(maxgen_nwind1*zdata1[j])
        vector_muestra.append(maxgen_nwind2*zdata2[j])
        vector_muestra.append(maxgen_nwind3*zdata3[j])
        vector_muestra.append(maxgen_nwind4*zdata4[j])
        vector_muestra.append(maxgen_nwind5*zdata5[j])
        vector_muestra.append(maxgen_nwind6*zdata6[j])
        
        vector_muestra.append(maxgen_nwind7*zdata7[j])
        vector_muestra.append(maxgen_nwind8*zdata8[j])
        
        vector_muestra.append(maxgen_nwind1*omega1)
        vector_muestra.append(maxgen_nwind2*omega2)
        vector_muestra.append(maxgen_nwind3*omega3)
        vector_muestra.append(maxgen_nwind4*omega4)
        vector_muestra.append(maxgen_nwind5*omega5)
        vector_muestra.append(maxgen_nwind6*omega6)
        vector_muestra.append(maxgen_nwind7*omega7)
        vector_muestra.append(maxgen_nwind8*omega8)
        
    # vector_muestra.append(zdata1[j])
    # vector_muestra.append(zdata2[j])
    # vector_muestra.append(zdata3[j])
    # vector_muestra.append(zdata4[j])
    # vector_muestra.append(zdata5[j])
    # vector_muestra.append(zdata6[j])        
    # vector_muestra.append(omega1)
    # vector_muestra.append(omega2)
    # vector_muestra.append(omega3)
    # vector_muestra.append(omega4)
    # vector_muestra.append(omega5)
    # vector_muestra.append(omega6)
    
        Omega=maxgen_nwind1*omega1+maxgen_nwind2*omega2+maxgen_nwind3*omega3+maxgen_nwind4*omega4+maxgen_nwind5*omega5+maxgen_nwind6*omega6+maxgen_nwind7*omega7+maxgen_nwind8*omega8
    # Omega=omega1+omega2+omega3+omega4

        vector_muestra.append(Omega)
        muestra_real_conjunta.append(vector_muestra)
        len_muestraconjunta=len_muestraconjunta+1
    
    # else:
    #     print("mala combinacion alfa y beta:", alpha_w1, beta_w1)
    #     print("mala combinacion alfa y beta:", alpha_w2, beta_w2)
    #     print("mala combinacion alfa y beta:", alpha_w3, beta_w3)
    #     print("mala combinacion alfa y beta:", alpha_w4, beta_w4)
    #     # print("mala combinacion alfa y beta:", alpha_w5, beta_w5)
    #     # print("mala combinacion alfa y beta:", alpha_w6, beta_w6)
    #     print("j--> ", j, "zdata=",zdata1[j])
    #     print("j--> ", j, "zdata=",zdata2[j])
    #     print("j--> ", j, "zdata=",zdata3[j])
    #     print("j--> ", j, "zdata=",zdata4[j])
        # print("j--> ", j, "zdata=",zdata5[j])
        # print("j--> ", j, "zdata=",zdata6[j])
    # print("---------------------------")
    print("len_muestraconjunta",len_muestraconjunta)
    j=j+1

 

np.savetxt("muestra_real_conjunta.csv", muestra_real_conjunta, delimiter=",")

# muestra_real_conjunta=[]
# with open("muestra_real_conjunta.csv", newline='') as File:
#     reader = csv.reader(File)
#     for row in reader:
#         muestra_real_conjunta.append(np.array(list(map(float,row))))

# muestra_real_conjunta_bernouilli=np.asarray(muestra_real_conjunta)
# # 


muestra_real_conjunta=pd.read_csv("muestra_real_conjunta.csv", header=None).values
# np.savetxt("muestra_real_conjunta.csv", muestra_real_conjunta, delimiter=",")
# muestra_real_conjunta=[]
# with open("muestra_real_conjunta.csv", newline='') as File:
#     reader = csv.reader(File)
#     for row in reader:
#         muestra_real_conjunta.append(np.array(list(map(float,row))))

# muestra_real_conjunta_bernouilli=np.asarray(muestra_real_conjunta)
# # 



# import seaborn as sns
# def corrdot(*args, **kwargs):
#     corr_r = args[0].corr(args[1], 'pearson')
#     corr_text = f"{corr_r:2.2f}".replace("0.", ".")
#     ax = plt.gca()
#     ax.set_axis_off()
#     marker_size = abs(corr_r) * 10000
#     ax.scatter([.5], [.5], marker_size, [corr_r], alpha=0.6, cmap="coolwarm",
#                vmin=-1, vmax=1, transform=ax.transAxes)
#     font_size = abs(corr_r) * 40 + 5
#     ax.annotate(corr_text, [.5, .5,],  xycoords="axes fraction",
#                 ha='center', va='center', fontsize=font_size)

# sns.set(style='white', font_scale=1.6)
# iris = sns.load_dataset('iris')
# gplot = sns.PairGrid(iris, aspect=1.4, diag_sharey=False)
# gplot.map_lower(sns.regplot, lowess=True, ci=False, line_kws={'color': 'black'})
# gplot.map_diag(sns.distplot, kde_kws={'color': 'black'})
# gplot.map_upper(corrdot)




# sns.pairplot(pd.DataFrame(muestra_real_conjunta), diag_kind="kde")
# corrmat = pd.DataFrame(muestra_real_conjunta).corr()
# f, ax = plt.subplots(figsize=(12, 10))
# sns.heatmap(corrmat, ax=ax, cmap="YlGnBu", linewidths=0.1)
# gplot.map_lower(corrfunc)
# plt.show()


zdataconjunta=muestra_real_conjunta[:,[0,1,2,3]]
ydataconjunta=muestra_real_conjunta[:,[4,5,6,7,8]]
omegadataconjunta=muestra_real_conjunta[:,[4,5,6,7]]

Omegadataconjunta=muestra_real_conjunta[:,[8]]







# # cov= np.cov(omegadataconjunta.transpose())


# # for j in range(25000):
# #     if np.linalg.norm(np.dot(mcholesky,omegadataconjunta[j,:]), ord=1)<=3.5 and len(muestra_real_conjunta_def)<30000:
# #         muestra_real_conjunta_def.append(muestra_real_conjunta[j,:] )
        
    

    
    




# np.savetxt("muestra_real_conjunta_bernouilli.csv", muestra_real_conjunta_bernouilli, delimiter=",")

# # muestra_real_conjunta=[]
# # with open("muestra_real_conjunta.csv", newline='') as File:
# #     reader = csv.reader(File)
# #     for row in reader:
# #         muestra_real_conjunta.append(np.array(list(map(float,row))))

# # muestra_real_conjunta=np.asarray(muestra_real_conjunta)
# ###############################################################################################

#genero la condicional real
len_muestracond=0
j=0
times_muestra_cond=1000
muestra_real_cond=[]


while len(muestra_real_cond)<times_muestra_cond:
    vector_muestra=[]
    
    # print("j",j)
    sigma_w1=(0.2*(zpred[1]/maxgen_nwind1)+0.02)  #predicion de 48 horas
    sigma_w2=(0.2*(zpred[2]/maxgen_nwind2)+0.02)  #predicion de 48 horas
    sigma_w3=(0.2*(zpred[3]/maxgen_nwind3)+0.02)  #predicion de 48 horas
    sigma_w4=(0.2*(zpred[4]/maxgen_nwind4)+0.02)  #predicion de 48 horas    

    sigma_w5=(0.2*(zpred[5]/maxgen_nwind5)+0.02)  #predicion de 48 horas
    sigma_w6=(0.2*(zpred[6]/maxgen_nwind6)+0.02)  #predicion de 48 horas
    sigma_w7=(0.2*(zpred[7]/maxgen_nwind7)+0.02)  #predicion de 48 horas
    sigma_w8=(0.2*(zpred[8]/maxgen_nwind8)+0.02)  #predicion de 48 horas
    sigma2_w1=(sigma_w1)**2 #predicion de 48 horas
    sigma2_w2=(sigma_w2)**2   #predicion de 48 horas
    sigma2_w3=(sigma_w3)**2  #predicion de 48 horas
    sigma2_w4=(sigma_w4)**2   #predicion de 48 horas
    sigma2_w5=(sigma_w5)**2  #predicion de 48 horas
    sigma2_w6=(sigma_w6)**2   #predicion de 48 horas
    sigma2_w7=(sigma_w7)**2  #predicion de 48 horas
    sigma2_w8=(sigma_w8)**2   #predicion de 48 horas   
    

   
    alpha_w1=((1-zpred[1]/maxgen_nwind1)*(zpred[1]/maxgen_nwind1)**2)/(sigma2_w1)-zpred[1]/maxgen_nwind1
    
   
    beta_w1=((zpred[1]/(maxgen_nwind1))*(1-zpred[1]/maxgen_nwind1)**2)/(sigma2_w1)+zpred[1]/maxgen_nwind1-1
        
    alpha_w2=((1-zpred[2]/maxgen_nwind2)*(zpred[2]/maxgen_nwind2)**2)/(sigma2_w2)-zpred[2]/maxgen_nwind2
    beta_w2=((zpred[2]/(maxgen_nwind2))*(1-zpred[2]/maxgen_nwind2)**2)/(sigma2_w2)+zpred[2]/maxgen_nwind2-1
    
    
    
    
    
    alpha_w3=((1-zpred[3]/maxgen_nwind3)*(zpred[3]/maxgen_nwind3)**2)/(sigma2_w3)-zpred[3]/maxgen_nwind3
    
   
    beta_w3=((zpred[3]/(maxgen_nwind3))*(1-zpred[3]/maxgen_nwind3)**2)/(sigma2_w3)+zpred[3]/maxgen_nwind3-1
    
    alpha_w4=((1-zpred[4]/maxgen_nwind4)*(zpred[4]/maxgen_nwind4)**2)/(sigma2_w4)-zpred[4]/maxgen_nwind4
    beta_w4=((zpred[4]/(maxgen_nwind4))*(1-zpred[4]/maxgen_nwind4)**2)/(sigma2_w4)+zpred[4]/maxgen_nwind4-1

    alpha_w5=((1-zpred[5]/maxgen_nwind5)*(zpred[5]/maxgen_nwind5)**2)/(sigma2_w5)-zpred[5]/maxgen_nwind5
    beta_w5=((zpred[5]/(maxgen_nwind5))*(1-zpred[5]/maxgen_nwind5)**2)/(sigma2_w5)+zpred[5]/maxgen_nwind5-1

    alpha_w6=((1-zpred[6]/maxgen_nwind6)*(zpred[6]/maxgen_nwind6)**2)/(sigma2_w6)-zpred[6]/maxgen_nwind6
    beta_w6=((zpred[6]/(maxgen_nwind6))*(1-zpred[6]/maxgen_nwind6)**2)/(sigma2_w6)+zpred[6]/maxgen_nwind6-1
    
    
    alpha_w7=((1-zpred[7]/maxgen_nwind7)*(zpred[7]/maxgen_nwind7)**2)/(sigma2_w7)-zpred[7]/maxgen_nwind7
    beta_w7=((zpred[7]/(maxgen_nwind7))*(1-zpred[7]/maxgen_nwind7)**2)/(sigma2_w7)+zpred[7]/maxgen_nwind7-1

    alpha_w8=((1-zpred[8]/maxgen_nwind8)*(zpred[8]/maxgen_nwind8)**2)/(sigma2_w8)-zpred[8]/maxgen_nwind8
    beta_w8=((zpred[8]/(maxgen_nwind8))*(1-zpred[8]/maxgen_nwind8)**2)/(sigma2_w8)+zpred[8]/maxgen_nwind8-1
    
    
    if alpha_w1>=0 and beta_w1>=0 and alpha_w2>=0 and beta_w2>=0 and alpha_w3>=0 and beta_w3>=0 and alpha_w4>=0 and beta_w4>=0   :
        # print("alpha bien cond")
        omega1=maxgen_nwind1*(np.random.beta(alpha_w1,beta_w1) -zpred[1]/maxgen_nwind1  )
        omega2=maxgen_nwind2*(np.random.beta(alpha_w2,beta_w2) -zpred[2]/maxgen_nwind2  )
        omega3=maxgen_nwind3*(np.random.beta(alpha_w3,beta_w3) -zpred[3]/maxgen_nwind3 )
        omega4=maxgen_nwind4*(np.random.beta(alpha_w4,beta_w4) -zpred[4]/maxgen_nwind4  )
        
        omega5=maxgen_nwind5*(np.random.beta(alpha_w5,beta_w5) -zpred[5]/maxgen_nwind5 )
        omega6=maxgen_nwind6*(np.random.beta(alpha_w6,beta_w6) -zpred[6]/maxgen_nwind6  )
        
        omega7=maxgen_nwind7*(np.random.beta(alpha_w7,beta_w7) -zpred[7]/maxgen_nwind7 )
        omega8=maxgen_nwind8*(np.random.beta(alpha_w8,beta_w8) -zpred[8]/maxgen_nwind8  )
        
        # omega1=(np.random.beta(alpha_w1,beta_w1) -zpred[1]/maxgen_nwind1  )
        # omega2=(np.random.beta(alpha_w2,beta_w2) -zpred[2]/maxgen_nwind2  )
        # omega3=(np.random.beta(alpha_w3,beta_w3) -zpred[3]/maxgen_nwind3 )
        # omega4=(np.random.beta(alpha_w4,beta_w4) -zpred[4]/maxgen_nwind4  )
        
        # omega5=(np.random.beta(alpha_w5,beta_w5) -zpred[5]/maxgen_nwind5 )
        # omega6=(np.random.beta(alpha_w6,beta_w6) -zpred[6]/maxgen_nwind6  )
        
        
        
        # Omega=omega1+omega2+omega3+omega4
        
    
    
        vector_muestra.append(omega1)
        vector_muestra.append(omega2)
        vector_muestra.append(omega3)
        vector_muestra.append(omega4)
        vector_muestra.append(omega5)
        vector_muestra.append(omega6)
        vector_muestra.append(omega7)
        vector_muestra.append(omega8)
        # vector_muestra.append(Omega)
        muestra_real_cond.append(vector_muestra)
        len_muestracond=len_muestracond+1
    
    print("len_muestracond",len_muestracond)
    
    j=j+1
np.savetxt("muestra_real_cond.csv", muestra_real_cond, delimiter=",")


puntos_zkn_array=muestra_real_conjunta[:,[0,1,2,3,4,5,6,7]]
puntos_ykn_array=muestra_real_conjunta[:,[8,9,10,11,12,13,14,15,16]]

puntos_omegakn_array=muestra_real_conjunta[:,[8,9,10,11,12,13,14,15,]]
# print("puntos_omegakn_array",puntos_omegakn_array)
puntos_Omegakn_array=(muestra_real_conjunta[:,[16]]).reshape(times_muestra_conjunta,)






# np.savetxt("muestra_real_cond_beta.csv", muestra_real_cond, delimiter=",")
# np.savetxt("muestra_real_cond_knn.csv", muestra_real_cond_knn, delimiter=",")
muestra_real_cond=pd.read_csv("muestra_real_cond.csv", header=None).values

# np.savetxt("muestra_real_cond_knn.csv", muestra_real_cond, delimiter=",")

# muestra_real_cond_beta=pd.read_csv("muestra_real_cond_beta.csv", header=None).values
# muestra_real_cond_knn=pd.read_csv("muestra_real_cond_knn.csv", header=None).values
# zdataconjunta=muestra_real_cond[:,[0,1]]
# ydataconjunta=muestra_real_conjunta[:,[2,3,4]]
omegadatacond=muestra_real_cond[:,[0,1,2,3]]

Omegadatacond=np.sum(muestra_real_cond,axis=1)




# sns.kdeplot(muestra_real_cond[:,3])
# sns.kdeplot(muestra_real_cond_knn[:,3])
# indices=pd.read_csv("indices200.csv", header=None).values


# print("INDICES",indices)




matrixGbus=np.zeros((Nbus,Ngen))


    
for j in index_busgen.keys():
    for k in index_busgen[j]:
        matrixGbus[j-1,k-1]=1
    
    
array_matrixGbus=matrixGbus

matrixGbus=array_to_dict(matrixGbus)
matrixHbus=np.zeros((Nbus,Nwind))



# matrixHbus[17-1,0]=1
# matrixHbus[37-1,1]=1
# matrixHbus[80-1,2]=1
# matrixHbus[54-1,3]=1
# matrixHbus[100-1,4]=1
# matrixHbus[9-1,5]=1
# matrixHbus[30-1,6]=1
# matrixHbus[68-1,7]=1

matrixHbus[16-1,0]=1
matrixHbus[37-1,1]=1
matrixHbus[83-1,2]=1
matrixHbus[55-1,3]=1
matrixHbus[116-1,4]=1
matrixHbus[2-1,5]=1
matrixHbus[33-1,6]=1
matrixHbus[67-1,7]=1




array_matrixHbus=matrixHbus
matrixHbus=array_to_dict(matrixHbus)
# matrixGbus=array_to_dict(np.array([[1,0,0],[0,1,0],[0,0,0],[0,0,0],[0,0,0],[0,0,1]]))
# matrixHbus=array_to_dict(np.array([[1,0],[0,0],[0,0],[0,0],[0,1],[0,0]]))

# matrixGbusdict={}
# for i in range(len(set_nbus)):
#     for j in range(len(set_ngen)):
#         matrixGbusdict[(i+1,j+1)]=matrixGbus[i,j]

# matrixHbus=array_to_dict(matrixHbus)

# 


node_ref=1
lines=pd.read_csv('mylines_118.csv', index_col=0)
capline=array_to_dict(list(1*lines['C(MW)'].values))

# capline=array_to_dict([2000,10000,20000,10000,10000,20000,20000])
from power_tools import compute_ptdf_matrix
# PTDF_MATRIX=(np.append(np.zeros((Nlines,1)), ptdf_matrix(lines,Nbus,node_ref).values, axis=1)).transpose()
PTDF_MATRIX=(np.append(np.zeros((Nlines,1)), compute_ptdf_matrix(lines,node_ref).values, axis=1)).transpose()
# compute_ptdf_matrix(input_data, ref_node=None)
print(PTDF_MATRIX)
PTDF_dict=array_to_dict(PTDF_MATRIX)














#calculo media y covarianza

# puntos_yconjunta_real=muestra_real_conjunta[:,[3,4,5,6,7,8]]

# cov_yrealconjunta=np.cov(puntos_yconjunta_real,rowvar=False)

# #std_yrealconjunta=sqrtm(cov_yrealconjunta)
# std_yrealconjunta=np.diag(np.sqrt(np.diag(cov_yrealconjunta)))
# media_yrealconjunta=puntos_yconjunta_real.mean(axis=0)

# #np.savetxt("media_yrealconjunta.csv", media_yrealconjunta, delimiter=",")
# #np.savetxt("cov_yrealconjunta.csv", cov_yrealconjunta, delimiter-
# n_mixt_real=muestra_real_conjunta.shape[0]
# n_mixt_real=2

# knnreal=math.floor(n_mixt_real/(math.log(n_mixt_real+1)))

knnreal=times_muestra_cond
# #knn=math.floor(math.sqrt(n_mixt_real))
# print("knn es",knn)
# #set_knn_real=list(range(1, 1000+1))
# set_knn_real=list(range(1, n_mixt_real+1))
# set_dx=list(range(1,6+1))
# set_dy=set_dx
# set_k=list(range(1,3))




# zdataconjunta=muestra_real_conjunta[np.array(list(range(0, 2)))[:,None],[0,1]]
# ydataconjunta=muestra_real_conjunta[np.array(list(range(0, 2)))[:,None],[2,3,4]]

# omegadataconjunta=muestra_real_conjunta[np.array(list(range(0, 2)))[:,None],[2,3]]

# Omegadataconjunta=muestra_real_conjunta[np.array(list(range(0, 2)))[:,None],[4]]

#
# from sklearn.neighbors import KNeighborsRegressor
# neigh = KNeighborsRegressor(n_neighbors=knnreal,metric='minkowski',p=1)
# neigh.fit(zdataconjunta,ydataconjunta) 

# dist,entornos=neigh.kneighbors([[zpred[1],zpred[2]]]) 
# media_dist_knn_muestra=np.array([]) 

# dist_knnreal=np.mean(dist)


# #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
# dict_entornos=array_to_dict(entornos)
# #print("diccionario de entornos", dict_entornos)
# #print("lista de ebtriornbos",  list(dict_entornos.values()))
# ydataknnreal={}
# ydataknndroboot_array=[]
# ydataknnreal_dict={}
# Omegadataknnreal={}
# for i in range(1,len(list(dict_entornos.values()))+1):
# #    ydataknn[i]=XX[dict_entornos[1,i],1]
#     ydataknnreal[i]=omegadataconjunta[dict_entornos[1,i],[0,1]]
    
#     Omegadataknnreal[i]=(Omegadataconjunta[dict_entornos[1,i],[0]])[0]
#     for jj in range(0,len(set_nwind)):
#         ydataknnreal_dict[i,jj+1]=(ydataknnreal[i])[jj]








# mass=knnreal/n_mixt_real




# def pyomo_to_pandas1(instance,variable):

#     #Function that converts variables in pyomo instance to dataframe
#         df_variables = pd.DataFrame()
#         for v in instance.component_objects(pe.Var, active=True):
#             if str(variable) == str(v):
#                 for i in v:
#                     df_variables.loc[i, str(v)] = v[i].value
#         return df_variables
    
# def pyomo_to_pandas(instance,variable):

#     #Function that converts variables in pyomo instance to dataframe
#         df_variables = pd.DataFrame()
#         for v in instance.component_objects(pe.Var, active=True):
#             if str(variable) == str(v):
#                 for e,i in v:
#                     df_variables.loc[e,i] = v[e,i].value
                    
#         return df_variables
    
# for j in range(times_muestra_conjunta):
#     print(j)
#     if np.linalg.norm(np.dot(mcholesky,omegadataconjunta[j,:]), ord=1)<=3.5:
#         plt.scatter(omegadataconjunta[j,0],omegadataconjunta[j,1],color='red')


# import seaborn as sns
# sns.jointplot(x=muestra_real_cond[:,0], y=muestra_real_cond[:,1], kind="kde")
# sns.jointplot(x=omegadataconjunta[:,0], y=omegadataconjunta[:,1], kind="kde")
# sns.kdeplot(data=omegadataconjunta)
# times_data=0
# for j in range(50000):
#     # print(j)
#     aa= np.array([np.random.uniform(-40,40),np.random.uniform(-40,40)]) 
    
#     if np.linalg.norm(np.dot(mcholesky, aa ), ord=1)<=size_supportset:
#         plt.scatter(aa[0],aa[1],color='red')        
        
# sns.jointplot(x=muestra_real_cond[:,0], y=muestra_real_conda[:,1], kind="kde")
        

ydataknnreal=muestra_real_cond[:,[0,1,2,3,4,5,6,7]]

ydataknnreal_dict=array_to_dict(muestra_real_cond[:,[0,1,2,3,4,5,6,7]])

Omegadataknnreal=array_to_dict(np.sum(muestra_real_cond,axis=1))

knnreal=len(Omegadataknnreal)

set_knn_real=list(range(1, knnreal+1))




# sns.pairplot(pd.DataFrame(muestra_real_cond), diag_kind="kde")
# import seaborn as sns

# sns.jointplot(x=zdataconjunta[:,0], y=zdataconjunta[:,1])

# vector_b1=[500,1000]
# times=200
# for i in vector_b1:
#     Nsamples=i
#     indices={}
#     indices_list=[]
#     for j in list(range(times)):
    
#         #saco la muestra
#         indices[j]=np.random.choice(muestra_real_conjunta.shape[0], Nsamples, replace=True)
        
#         indices_list.append(indices [j])
    
#     np.savetxt("indices"+str(Nsamples)+".csv", indices_list,delimiter=",", fmt='%d')

 

# sns.jointplot(x=omegadataconjunta[:,0], y=omegadataconjunta[:,1])

# sns.jointplot(x=muestra_real_cond[:,0], y=muestra_real_cond[:,1])

epsGD=0.1



# np.savetxt("eps_desired.csv", np.array([epsGD])) 




#genero las muestras:


from itertools import product


#picasso
import os
os.environ["OMP_NUM_THREADS"] = "22" 

# vector_b1 =vector_b1 =[ 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.2, 1.5, 2, 3]

# #
# case = int(os.environ['SLURM_ARRAY_TASK_ID']) 
# b1 = vector_b1[case-1]


# vector_b1 =[0.005,0.01,0.02,0.05, 0.1,0.15, 0.2,0.25, 0.3,0.35, 0.4,0.45, 0.5,0.55, 0.6,0.65, 0.7,0.75, 0.8, 0.9, 1, 1.25]



vector_sample =list(range(200))
nmethods=3
allcases=[[i,m] for i in vector_sample for m in [1,2,3] ]
case=allcases[int(os.environ['SLURM_ARRAY_TASK_ID'])-1]

index_samplepicasso=case[0]
metodo=case[1]

# index_samplepicasso=199
# metodo=1
print("muestra numero-->",index_samplepicasso)
# os.environ['OMP_NUM_THREADS'] = '10'
range_radios=[1,2,3,4,5,6,7,8,9,10,15,20]
# range_radios=[15]
# range_radios=[0.1,100,1000]
# if metodo==3:
#     range_radios=[0.01,0.02,0.03,0.04,0.05 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.2, 1.5, 2, 3]
# else:
#     range_radios=[0.05,0.25, 0.5, 0.7,0.75, 1,1.25, 1.5, 2, 3]


# metodo=3
# index_samplepicasso=23
#pasada=1
# times=100
data_a=[]
data_b=[]
data_a2=[]







data_q1_knn=[]
data_q1_knn_robust=[]
data_q1_knn_dro=[]
data_q1_kn=[]
data_a21=[]
data_a22=[]
data_a23=[]
data_a24=[]
data_a25=[]
data_b2=[]
data_d2=[]
data_e2=[]
data_c2=[]
data_f2=[]

data_a21kuhn=[]
data_a22kuhn=[]
data_a23kuhn=[]
data_a24kuhn=[]
data_a25kuhn=[]
data_b2kuhn=[]
data_d2kuhn=[]
data_e2kuhn=[]
data_c2kuhn=[]
data_f2kuhn=[]
array_o1n=np.array([])#Array para guardar out of sample disappointment
array_okn=np.array([])
array_oknn=np.array([])
array_oknn_dro=np.array([])
array_oknn_robust=np.array([])
array_outofsamplecond=np.array([])
array_performancecond=np.array([])
array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_eknn=np.array([])
array_eknn_dro=np.array([])
array_eknn_robust=np.array([])

array_gen1=np.array([])
array_gen2=np.array([])
array_reserv_tot_D=np.array([])
array_reserv_tot_U=np.array([])
array_gen3=np.array([])
array_beta1=np.array([])
array_beta2=np.array([])
array_beta3=np.array([])
array_beta3kuhn=np.array([])
array_beta3knn=np.array([])
array_objval_1kn=np.array([])



array_o1n=np.array([])#Array para guardar out of sample disappointment
array_okn=np.array([])
array_oknn=np.array([])
array_oknn_dro=np.array([])
array_oknn_robust=np.array([])
array_outofsamplecondkuhn=np.array([])
array_performancecondkuhn=np.array([])
array_outofsamplecondkuhnnoside=np.array([])
array_performancecondkuhnnoside=np.array([])
array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_eknn=np.array([])
array_eknn_dro=np.array([])
array_eknn_robust=np.array([])

array_gen1kuhn=np.array([])
array_gen2kuhn=np.array([])
array_reserv_totkuhn_D=np.array([])
array_reserv_totkuhn_U=np.array([])
array_gen3kuhn=np.array([])
array_beta1kuhn=np.array([])
array_beta2kuhn=np.array([])
array_objval_1kuhn=np.array([])

array_gen1kuhnnoside=np.array([])
array_gen2kuhnnoside=np.array([])
array_reserv_totkuhnnoside_D=np.array([])
array_reserv_totkuhnnoside_U=np.array([])
array_reserv_totscen_D=np.array([])
array_reserv_totscen_U=np.array([])
array_gen3kuhnnoside=np.array([])
array_beta1kuhnnoside=np.array([])
array_beta2kuhnnoside=np.array([])
array_beta3kuhnnoside=np.array([])
array_objval_1kuhnnoside=np.array([])


array_o1n=np.array([])#Array para guardar out of sample disappointment
array_okn=np.array([])
array_oknn=np.array([])
array_oknn_dro=np.array([])
array_oknn_robust=np.array([])
array_outofsamplecondknn=np.array([])
array_performancecondknn=np.array([])
array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_eknn=np.array([])
array_eknn_dro=np.array([])
array_eknn_robust=np.array([])

array_gen1knn=np.array([])
array_gen2knn=np.array([])
array_reserv_totknn_D=np.array([])
array_reserv_totknn_U=np.array([])
array_gen3knn=np.array([])
array_beta1knn=np.array([])
array_beta2knn=np.array([])
array_objval_1knn=np.array([])

data_a21kuhnnoside=[]
data_a22kuhnnoside=[]
data_a23kuhnnoside=[]
data_a24kuhnnoside=[]
data_a25kuhnnoside=[]
data_b2kuhnnoside=[]
data_d2kuhnnoside=[]
data_e2kuhnnoside=[]
data_c2kuhnnoside=[]
data_f2kuhnnoside=[]

array_gen1kuhn=np.array([])
array_gen2kuhn=np.array([])
array_reserv_totkuhn_D=np.array([])
array_reserv_totkuhn_U=np.array([])
array_gen3kuhn=np.array([])
array_beta1kuhn=np.array([])
array_beta2kuhn=np.array([])
array_objval_1kuhn=np.array([])

array_gen1kuhnnoside=np.array([])
array_gen2kuhnnoside=np.array([])
array_reserv_totkuhnnoside_D=np.array([])
array_reserv_totkuhnnoside_U=np.array([])
array_gen3kuhnnoside=np.array([])
array_beta1kuhnnoside=np.array([])
array_beta2kuhnnoside=np.array([])
array_beta3kuhnnoside=np.array([])
array_objval_1kuhnnoside=np.array([])


array_o1n=np.array([])#Array para guardar out of sample disappointment
array_okn=np.array([])
array_oknn=np.array([])
array_oknn_dro=np.array([])
array_oknn_robust=np.array([])
array_outofsamplecondknn=np.array([])
array_performancecondknn=np.array([])
array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_eknn=np.array([])
array_eknn_dro=np.array([])
array_eknn_robust=np.array([])

array_gen1knn=np.array([])
array_gen2knn=np.array([])
array_reserv_totknn_D=np.array([])
array_reserv_totknn_U=np.array([])
array_gen3knn=np.array([])
array_beta1knn=np.array([])
array_beta2knn=np.array([])
array_objval_1knn=np.array([])

data_a21knn=[]
data_a22knn=[]
data_a23knn=[]
data_a24knn=[]
data_a25knn=[]
data_b2knn=[]
data_d2knn=[]
data_e2knn=[]
data_c2knn=[]
data_f2knn=[]
data_g2=[]
data_g2knn=[]
data_g2kuhn=[]
data_g2kuhnnoside=[]
data_q1_knn=[]

data_d2=[]
data_a2=[]
data_q1_kuhn=[]





range_ro_knn={}
range_ro_kn={}
range_ro_kndro={}
parametros_kn={}
range_eps_knnrobust={}
parametros_knnrobust={}
parametros_knndro={}
#for j in list(range(b1,b1+1)):
#    range_ro_knn[j]=list([math.floor(j/(math.log(j+1)))])
#    
#    #range_ro_kn[j]=[(k*math.sqrt(j)/j**(l))+k/(j**(l)) for k in [2,50,100,500,3000] for l in [0.02,0.03]]
##    range_ro_kn[20]=list([80,85,90,100,120,150]) 
##    range_ro_kn[30]=list([60,65,70,80,90,100,120])
##    range_ro_kn[40]=list([50,55,60,65,70,80,100])
##    range_ro_kn[50]=list([30,35,40,45,55,70])
##    range_ro_kn[60]=list([20,25,30,35,45,60])
##    range_ro_kn[70]=list([20,25,30,35])
##    range_ro_kn[80]=list([8.5,9,15,22,30]) 
##    range_ro_kn[100]=list([8,12,15,22,25])
##    range_ro_kn[200]=list([7.5,10,15,20,25])
##    range_ro_kn[300]=list([7,10,15,20])
##    range_ro_kn[400]=list([6.5,10,14,18])
##    range_ro_kn[500]=list([6,7,8,10])
##    range_ro_kn[600]=list([5,6,7,8])
#    print("numero de muestras j",j)
#    if j>40:
#        range_ro_kndro[j]=[k/(j**(l)) for k in [1] for l in [1/9,0.06]]
#        range_eps_knnrobust[j]=[k/(j**(l)) for k in [1800] for l in [0.08,0.06]]
#    else:
#        range_ro_kndro[j]=[k/(j**(l)) for k in [4] for l in [1/9,0.02]]
#        range_eps_knnrobust[j]=[k/(j**(l)) for k in [4000] for l in [0.02,0.05]]
#
#        
##    parametros_kn[j]=list(map(list,product(range_ro_knn[j],range_ro_kn[j])))
#    
#    
#    
#    parametros_knnrobust[j]=list(map(list,product(range_ro_knn[j],range_eps_knnrobust[j])))
#
#    parametros_knndro[j]=list(map(list,product(range_ro_knn[j],range_ro_kndro[j])))
#
##picasso
##case = int(os.environ['SLURM_ARRAY_TASK_ID']) 
##b1 = vector_b1[case-1]
#print(" parametros_knnrobust",parametros_knnrobust)
    
#b1=20



data_a=[]
data_b=[]
data_a2=[]

data_q1_knn=[]
data_q1_knn_robust=[]
data_q1_knn_dro=[]
data_q1_kn=[]
data_a21=[]
data_a22=[]
data_a23=[]
data_a24=[]
data_a25=[]
data_b2=[]
data_d2=[]
data_e2=[]
data_c2=[]
data_f2=[]

data_a21kuhn=[]
data_a22kuhn=[]
data_a23kuhn=[]
data_a24kuhn=[]
data_a25kuhn=[]
data_b2kuhn=[]
data_d2kuhn=[]
data_e2kuhn=[]
data_c2kuhn=[]
data_f2kuhn=[]


data_a21kuhnnoside=[]
data_a22kuhnnoside=[]
data_a23kuhnnoside=[]
data_a24kuhnnoside=[]
data_a25kuhnnoside=[]
data_b2kuhnnoside=[]
data_d2kuhnnoside=[]
data_e2kuhnnoside=[]
data_c2kuhnnoside=[]
data_f2kuhnnoside=[]
data_g2kuhnnoside=[]


data_a21knn=[]
data_a22knn=[]
data_a23knn=[]
data_a24knn=[]
data_a25knn=[]
data_b2knn=[]
data_d2knn=[]
data_e2knn=[]
data_c2knn=[]
data_f2knn=[]
data_g2=[]
data_g2knn=[]
data_g2kuhn=[]

data_q1_knn=[]

data_d2=[]
data_a2=[]
data_q1_kuhn=[]



array_oscen=np.array([])
array_oscen_dro=np.array([])
array_oscen_robust=np.array([])
array_outofsamplecondscen=np.array([])
array_performancecondscen=np.array([])
array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_escen=np.array([])
array_escen_dro=np.array([])
array_escen_robust=np.array([])

array_gen1scen=np.array([])
array_gen2scen=np.array([])
array_reserv_totscen=np.array([])
array_gen3scen=np.array([])
array_beta1scen=np.array([])
array_beta2scen=np.array([])
array_objval_1scen=np.array([])


data_a26scen=[]




data_a21scen=[]
data_a22scen=[]
data_a23scen=[]
data_a24scen=[]
data_a25scen=[]
data_b2scen=[]
data_d2scen=[]
data_e2scen=[]
data_c2scen=[]
data_f2scen=[]
data_g2scen=[]



confidence_level=0.
array_o1n=np.array([])#Array para guardar out of sample disappointment
array_okn=np.array([])
array_oknn=np.array([])
array_oknn_dro=np.array([])
array_oknn_robust=np.array([])
array_outofsamplecond=np.array([])
array_performancecond=np.array([])
array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_eknn=np.array([])
array_eknn_dro=np.array([])
array_eknn_robust=np.array([])

array_gen1=np.array([])
array_gen2=np.array([])
array_reserv_tot=np.array([])
array_gen3=np.array([])
array_beta1=np.array([])
array_beta2=np.array([])
array_beta3=np.array([])
array_beta3kuhn=np.array([])
array_beta3knn=np.array([])
array_objval_1kn=np.array([])



array_o1n=np.array([])#Array para guardar out of sample disappointment
array_okn=np.array([])
array_oknn=np.array([])
array_oknn_dro=np.array([])
array_oknn_robust=np.array([])
array_outofsamplecondkuhn=np.array([])
array_performancecondkuhn=np.array([])
array_outofsamplecondkuhnnoside=np.array([])
array_performancecondkuhnnoside=np.array([])
array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_eknn=np.array([])
array_eknn_dro=np.array([])
array_eknn_robust=np.array([])

array_gen1kuhn=np.array([])
array_gen2kuhn=np.array([])
array_reserv_totkuhn=np.array([])
array_gen3kuhn=np.array([])
array_beta1kuhn=np.array([])
array_beta2kuhn=np.array([])
array_objval_1kuhn=np.array([])

array_gen1kuhnnoside=np.array([])
array_gen2kuhnnoside=np.array([])
array_reserv_totkuhnnoside=np.array([])
array_gen3kuhnnoside=np.array([])
array_beta1kuhnnoside=np.array([])
array_beta2kuhnnoside=np.array([])
array_beta3kuhnnoside=np.array([])
array_objval_1kuhnnoside=np.array([])


array_o1n=np.array([])#Array para guardar out of sample disappointment
array_okn=np.array([])
array_oknn=np.array([])
array_oknn_dro=np.array([])
array_oknn_robust=np.array([])
array_outofsamplecondknn=np.array([])
array_performancecondknn=np.array([])
array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_eknn=np.array([])
array_eknn_dro=np.array([])
array_eknn_robust=np.array([])

array_gen1knn=np.array([])
array_gen2knn=np.array([])
array_reserv_totknn=np.array([])
array_gen3knn=np.array([])
array_beta1knn=np.array([])
array_beta2knn=np.array([])
array_objval_1knn=np.array([])


data_a26knn=[]
data_a26kuhn=[]
data_a26=[]
data_a26kuhnnoside=[]
indices_list=[]


    


nocreado_pasadamodel=True

for rr in range_radios:
    # j=3
    b1=rr
    #saco la muestra
#    indices[j]=np.random.choice(muestra_real_conjunta.shape[0], Nsamples, replace=True)
#    print("indices[j]", indices[j])
    set_indices=set(indices[index_samplepicasso])
#    print("set_indices",set_indices)
    muestra_conjunta_sample=muestra_real_conjunta[indices[index_samplepicasso]]
    # print("muestra_conjunta",muestra_conjunta_sample)
    # print("muestra de la real",muestra_real_conjunta[indices[j]])
    #metodo knn
    
    print("pasada radio ", rr)
#
     
    # knn=math.floor(Nsamples/(math.log(Nsamples+1)))
    # knn=math.floor(math.pow(Nsamples,0.9))
#    print("valor k modelo 1-k/n",value_knchosen) 
    #knn=math.floor(math.pow(n_mixt_real,0.75))

    set_knntotal=list(range(1, Nsamples+1))
    
    puntos_zkn_array=muestra_conjunta_sample[:,[0,1,2,3,4,5,6,7]]
    puntos_ykn_array=muestra_conjunta_sample[:,[8,9,10,11,12,13,14,15,16]]
    
    puntos_omegakn_array=muestra_conjunta_sample[:,[8,9,10,11,12,13,14,15]]
    # print("puntos_omegakn_array",puntos_omegakn_array)
    puntos_Omegakn_array=(muestra_conjunta_sample[:,[16]]).reshape(Nsamples,)
    
    
    
    
    # neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
    
    
    # neigh.fit(puntos_zkn_array,puntos_ykn_array) 
    # neigh.fit(puntos_zkn_array,puntos_omegakn_array) 
    
    
    

    # dist,entornos=neigh.kneighbors([[zpred[1],zpred[2],zpred[3],zpred[4],zpred[5],zpred[6]]]) 
    # media_dist_knn_muestra=np.array([]) 
    
    # dist_knnreal=np.mean(dist)
    # dict_entornos=array_to_dict(entornos)
    
    
    # neigh.fit(puntos_zkn_array,puntos_Omegakn_array) 
    
    
    

    # dist2,entornos2=neigh.kneighbors([[zpred[1],zpred[2],zpred[3],zpred[4],zpred[5],zpred[6]]]) 
    # media_dist_knn_muestra=np.array([]) 
    
    # dist_knnreal2=np.mean(dist2)
    # dict_entornos2=array_to_dict(entornos2)

    ydataknn={}
    ydataknndroboot_array=[]
    ydataknn_dict={}
    Omegadataknn={}
    Omegadataknnproj={}
    ydataknnproj_dict={}
    lista_dist_minOmega1=[]
    
    
    
    # from sklearn.neighbors import KNeighborsRegressor
    # neigh = KNeighborsRegressor(n_neighbors=kn,metric='minkowski',p=1)
    #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
    #        print("y ", XX[:,1])
    # puntos_zkn_array=muestra_conjunta_sample[:,[0,1,2,3,4,5]]
    # puntos_ykn_array=muestra_conjunta_sample[:,[6,7,8,9,10,11,12]]
    
    # puntos_omegakn_array=muestra_conjunta_sample[:,[6,7,8,9,10,11]]
    # puntos_Omegakn_array=(muestra_conjunta_sample[:,[12]]).reshape(Nsamples,)
    puntos_omegakn_array_proj={}
    puntos_Omegakn_array_proj={}
    # puntos_omegakn_array_proj=muestra_conjunta_sample[:,[6,7,8,9,10,11]]
    # puntos_Omegakn_array_proj=(muestra_conjunta_sample[:,[12]]).reshape(Nsamples,)
    # puntos_zkn_array=muestra_real_conjunta[np.array([0,1,2])[:,None],[0,1]]
    # puntos_ykn_array=muestra_real_conjunta[np.array([0,1,2])[:,None],[2,3,4]]
    
    # puntos_omegakn_array=muestra_real_conjunta[np.array([0,1,2])[:,None],[2,3]]
    # puntos_Omegakn_array=(muestra_real_conjunta[np.array([0,1,2])[:,None],[4]]).reshape(Nsamples,)
    
    

  
#    print("incremento de radio modelo ro kn elegido",value_rochosen)
    
#    cov_yrealconjunta=np.cov(muestra_conjunta_sample[:,[3,4,5,6,7,8]],rowvar=False)

#std_yrealconjunta=sqrtm(cov_yrealconjunta)
#    std_yrealconjunta_sample=np.diag(np.sqrt(np.diag(cov_yrealconjunta)))



#    media_yrealconjunta_sample=muestra_conjunta_sample[:,[3,4,5,6,7,8]].mean(axis=0)
    
    
    # puntos_ykn_array=np.zeros(shape=(Nsamples,6))
    # for j in range(Nsamples):
    #     puntos_ykn_array[j,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
    
    # neigh.fit(puntos_zkn_array,puntos_omegakn_array) 
    # puntos_yknescalado=array_to_dict(puntos_ykn_array)
    # dist,entornos=neigh.kneighbors([[zpred[1],zpred[2],zpred[3],zpred[4],zpred[5],zpred[6]]]) 
#    dist,entornos=neigh.kneighbors([[970,0,10]])
    # dist_mediaknn=np.mean(dist)
    # print("distancia media knn trimm",dist_mediaknn )
    
    
    

#    radio_rokn_totkn=dist_mediaknn+1000000000000000
    # print("radio_rokn_totkn",radio_rokn_totkn)
   
#    portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_tot,mass,zprediccion_feature,puntos_zboot,puntos_ybootescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
    # modelokn=portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_totkn,mass,zprediccion_feature,puntos_zkn,puntos_yknescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))

    zdata=array_to_dict(puntos_zkn_array)
    # print("zdata",zdata)
    omegadata=array_to_dict(puntos_omegakn_array)
    Omegadata=array_to_dict(puntos_Omegakn_array )
    
    # mass=knn/Nsamples
    # mass2=mass
    
    
    
    # dist_mediaknn=0
    # puntos_ykn_array=np.zeros(shape=(Nsamples,6))
    lista_dist_min=[]
    dist_recintoOmega={}
    lista_dist_minOmega=[]
    distnorma1recinto=0
    lista_index_outsideOmega_left=[]
    lista_index_outsideOmega_right=[]
    
    for j in range(Nsamples):
        # puntos_ykn_array[j,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
        # zdato=(puntos_zkn_array[j]).tolist()
        lista_dist_minOmegasum=0
        distnorma1recinto=0
        

        for mm in set_nwind:
            distnorma1recinto=distnorma1recinto+abs(puntos_zkn_array[j,mm-1]-zpred[mm])
            lista_dist_minOmegasum=lista_dist_minOmegasum+abs(puntos_zkn_array[j,mm-1]-zpred[mm])
            puntos_omegakn_array_proj[j,mm-1]=puntos_omegakn_array[j,mm-1]
            
            
            if puntos_omegakn_array[j,mm-1]> support_limsupcond[mm]  :
                puntos_omegakn_array_proj[j,mm-1]=support_limsupcond[mm] 
                distnorma1recinto=distnorma1recinto+abs(puntos_omegakn_array[j,mm-1]- support_limsupcond[mm])
                print("he proyectado omega",j,mm)
            
                # print("distnorma1recinto",distnorma1recinto)
            if puntos_omegakn_array[j,mm-1]< support_liminfcond[mm] :
                puntos_omegakn_array_proj[j,mm-1]=support_liminfcond[mm]
                distnorma1recinto=distnorma1recinto+abs(puntos_omegakn_array[j,mm-1]- support_liminfcond[mm])
                print("he proyectado omega",j,mm)
        puntos_Omegakn_array_proj[j]=puntos_Omegakn_array[j]
        if puntos_Omegakn_array[j]<liminf_Omega_cond:
            puntos_Omegakn_array_proj[j]=liminf_Omega_cond
                                    
            lista_dist_minOmegasum=lista_dist_minOmegasum+abs(puntos_Omegakn_array[j]-liminf_Omega_cond)
            print("he proyectado Omega", j)
            lista_index_outsideOmega_left.append(j+1)
        if  puntos_Omegakn_array[j] >limsup_Omega_cond:
            puntos_Omegakn_array_proj[j]=limsup_Omega_cond
            lista_dist_minOmegasum=lista_dist_minOmegasum+abs(puntos_Omegakn_array[j]-limsup_Omega_cond)
            print("he proyectado Omega",j)
            lista_index_outsideOmega_right.append(j+1)
           
        
        
        # print("punto j= ", j, "con distancia z recinto igual a ",np.linalg.norm(puntos_zkn_array[j,:]-np.array([zpred[1],zpred[2]]), ord=1) )
        # print("distnorma1recinto+np.linalg.norm(puntos_zkn_array[j,:]-np.array([zpred[1],zpred[2]]), ord=1)",distnorma1recinto+np.linalg.norm(puntos_zkn_array[j,:]-np.array([zpred[1],zpred[2]]), ord=1))
        # lista_dist_min.append(distnorma1recinto+np.linalg.norm(puntos_zkn_array[j,:]-np.array([zpred[1],zpred[2],zpred[3],zpred[4],zpred[5],zpred[6]]), ord=1))
        # lista_dist_minOmega.append(lista_dist_minOmegasum+np.linalg.norm(puntos_zkn_array[j,:]-np.array([zpred[1],zpred[2],zpred[3],zpred[4],zpred[5],zpred[6]]), ord=1))
        
        
        lista_dist_min.append(distnorma1recinto)
        lista_dist_minOmega.append(lista_dist_minOmegasum)

                
    dict_somega= { i : lista_dist_min[i] for i in range(len(lista_dist_min)) }
    
    
    lista_dist_min_sorted=  {k: v for k, v in sorted(dict_somega.items(), key=lambda item: item[1])}
    lista_dist_min_sorted_index=list(lista_dist_min_sorted.keys())

    

    # lista_dist_min_sortedOmega= { i :sorted((e,i) for i,e in enumerate(lista_dist_minOmega))[i] for i in range(0, len(sorted((e,i) for i,e in enumerate(lista_dist_minOmega))) ) }

    dict_sOmega= { i : lista_dist_minOmega[i] for i in range(len(lista_dist_minOmega)) }
    
    
    lista_dist_min_sortedOmega=  {k: v for k, v in sorted(dict_sOmega.items(), key=lambda item: item[1])}
    lista_dist_min_sortedOmega_index=list(lista_dist_min_sortedOmega.keys())




        
    ydataknntotalproj_dict={}    
    Omegadataknntotalproj={}  
    for i in list(range(Nsamples)):
        for j in set_nwind:
            ydataknntotalproj_dict[i+1,j]=puntos_omegakn_array_proj[lista_dist_min_sorted_index[i],j-1]
        
        Omegadataknntotalproj[i+1]=puntos_Omegakn_array_proj[lista_dist_min_sortedOmega_index[i]] 
           
        
    print("lista_index_outsideOmega_left",lista_index_outsideOmega_left)
    print("lista_index_outsideOmega_right",lista_index_outsideOmega_right)
    # print("dist media knn Omega",dist_mediaknnOmega)
    lista_index_interval=list(set(range(1,Nsamples+1)) - set(lista_index_outsideOmega_left)-set(lista_index_outsideOmega_right))
    print("lista_index_interval",lista_index_interval)
    set_knntotal=list(range(1, Nsamples+1))
    
    
    if metodo==1:
        rho2kuhn=b1
        
        
        
        
        knn=math.floor(math.pow(Nsamples,0.9))
        set_knn=list(range(1, knn+1))
        #calculo los puntos proyectados:
        # ydataknnproj_dict={}    
        # Omegadataknnproj={}
        
        # for i in list(range(knn)):
        #     for j in set_nwind:
        #         ydataknnproj_dict[i+1,j]=puntos_omegakn_array_proj[lista_dist_min_sorted_index[i],j-1]
            
        #     Omegadataknnproj[i+1]=puntos_Omegakn_array_proj[lista_dist_min_sortedOmega_index[i]]        
        
            
        ydataknnproj_dict={}    
        Omegadataknnproj={}
        ydataknn_dict={}    
        Omegadataknn={}

        for i in list(range(knn)):
            for j in set_nwind:
                ydataknntotalproj_dict[i+1,j]=puntos_omegakn_array_proj[lista_dist_min_sorted_index[i],j-1]
                ydataknn_dict[i+1,j]=puntos_omegakn_array[lista_dist_min_sorted_index[i],j-1]
            
            Omegadataknntotalproj[i+1]=puntos_Omegakn_array_proj[lista_dist_min_sortedOmega_index[i]]
            Omegadataknn[i+1]=puntos_Omegakn_array[lista_dist_min_sortedOmega_index[i]]

        
        
        m =Model('test_scen') 
        
        set_i=set_knn
        # (1/(model.N))*sum(tt[i]   for i in set_i)+sum(coste_reserv_d[j]*(r_D[j])+coste_reserv_u[j]*(r_U[j])  for j in set_ngen)
        tt=m.continuous_var_dict(list(set_i),lb=-float('inf'))
        
        # (1/(model.N))*sum(tt[i]   for i in set_i)+sum(coste_reserv_d[j]*(r_D[j])+coste_reserv_u[j]*(r_U[j])  for j in set_ngen)
        tt=m.continuous_var_dict(list(set_i),lb=-float('inf'))
        r_D=m.continuous_var_dict(list(set_ngen),lb=0)
        r_U=m.continuous_var_dict(list(set_ngen),lb=0)
        g=m.continuous_var_dict(list(set_ngen),lb=-float('inf'))
        beta=m.continuous_var_dict(list(set_ngen),lb=0,ub=1)

        tdata=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf'))  



        
        
        m.minimize( (1/knn)*sum(tt[i]   for i in set_i)+sum(coste_reserv_d[j]*(r_D[j])+coste_reserv_u[j]*(r_U[j])  for j in set_ngen) )

        c1=m.add_constraints((  tt[i]>=sum(tdata[i,j] for j in set_ngen) for i in set_i   ))
        
        c2=m.add_constraints((  tdata[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*Omegadataknn[i])+intercepts_gen[j,s] for i in set_i for j in set_ngen for s in set_pieces ))
        

        # c3=m.addConstrs((  gmin[j]-(g[j]-beta[j]*sum(ydataknn_dict[i,l] for l in set_nwind))<=0 for i in set_i for j in set_ngen  ))

                  
        # c4=m.addConstrs((  g[j]-beta[j]*sum(ydataknn_dict[i,l] for l in set_nwind)<=gmax[j] for i in set_i for j in set_ngen   ))

              
        c5=m.add_constraints((  -r_D[j]<=-beta[j]*sum(ydataknn_dict[i,l] for l in set_nwind) for i in set_i for j in set_ngen  ))

                  
        c6=m.add_constraints((  -beta[j]*sum(ydataknn_dict[i,l] for l in set_nwind)<=r_U[j] for i in set_i for j in set_ngen   ))              
              

        PTDF_gen=PTDF_MATRIX.transpose() @ (array_matrixGbus)
        PTDF_wind=PTDF_MATRIX.transpose() @ (array_matrixHbus)
        
        lin_load=[sum([ (PTDF_MATRIX[b-1,k-1])*(-load[b]) for b in set_nbus] ) for k in set_nlines]
        
        lin_wind=[sum([ (PTDF_wind[k-1,mm-1]*(forecasted_wind[mm]+ydataknn_dict[i,mm])) for mm in set_nwind]) for k in set_nlines]
        # c7=m.addConstrs((  -capline[k]-( gp.LinExpr([ (PTDF_gen[k-1,j-1],g[j]) for j in set_ngen])-sum(ydataknnproj_dict[i,l] for l in set_nwind)*gp.LinExpr([ (PTDF_gen[k-1,j-1],beta[j]) for j in set_ngen])     +
        #                                 +sum([ (PTDF_wind[k-1,mm-1]*(forecasted_wind[mm]+ydataknnproj_dict[i,mm])) for mm in set_nwind]) +sum([ (PTDF_MATRIX[b-1,k-1])*(-load[b]) for b in set_nbus] ) )   <=0 for i in set_i for k in set_nlines   ))              
        c7=m.add_constraints((  -capline[k]-( m.sum( PTDF_gen[k-1,j-1]*g[j] for j in set_ngen)-sum(ydataknn_dict[i,l] for l in set_nwind)*m.sum( PTDF_gen[k-1,j-1]*beta[j] for j in set_ngen)     +
                                        +lin_wind[k-1] +lin_load[k-1] )   <=0 for i in set_i for k in set_nlines   ))              
              
        c8=m.add_constraints((  ( m.sum( PTDF_gen[k-1,j-1]*g[j] for j in set_ngen)-sum(ydataknn_dict[i,l] for l in set_nwind)*m.sum( PTDF_gen[k-1,j-1]*beta[j] for j in set_ngen)     +
                                        +lin_wind[k-1] +lin_load[k-1] )   <=capline[k] for i in set_i for k in set_nlines   ))              

              
     
        c10=m.add_constraint(m.sum(g)==sum(load[b] for b in set_nbus)-sum(forecasted_wind[j] for j in set_nwind) )     
              
              
        c11=m.add_constraint(m.sum(beta)==1)      
              
        c12=m.add_constraints((  g[j]+r_U[j]<=gmax[j] for j in set_ngen  ))           

        c13=m.add_constraints((  g[j]-r_D[j]>=gmin[j] for j in set_ngen  ))

        m.parameters.threads.set(22)
        m.parameters.preprocessing.dual.set(1)
        m.parameters.solutiontype.set(2)
        m.parameters.lpmethod.set(4)
        m.solve(log_output = True)
                
        sol = m.solution
        
        # m.setParam('PreDual',1)
        # m.setParam('Presolve',2)
        # # m.setParam('Method',3)
        # # m.setParam('BarConvTol',1e-5)          
        # m.setParam('BarHomogeneous',1)
        # # m.setParam('ScaleFlag',3)
        # m.setParam('Threads',6)
        # m.setParam('CrossoverBasis',1)
        # m.setParam('NumericFocus',1)
        # m.optimize()
        print("Obj value scen-->", sol.objective_value)
        


        dfgen=np.asarray(list((sol.get_value_dict(g)).values()))
        dfbeta=np.asarray(list((sol.get_value_dict(beta)).values()))
        dfr_D=np.asarray(list((sol.get_value_dict(r_D)).values()))
        dfr_U=np.asarray(list((sol.get_value_dict(r_U)).values()))
        aa = pd.DataFrame()
        for s in range(len(set_knn_real)):
            # plus =  list( -dfgen.reshape(len(set_ngen)) + (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) + np.array(list(gmin.values())).reshape(len(set_ngen)))
            # plus += list(  dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) - np.array(list(gmax.values())).reshape(len(set_ngen)))
            plus =  list( (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) + np.array(list(-dfr_D)).reshape(len(set_ngen))) 
            plus += list(  - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) - np.array(list(dfr_U)).reshape(len(set_ngen))  )
            
            # plus += list(-PTDF_MATRIX @ (in_gen @(dfgen.values.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta.values).reshape(len(set_ngen))) - net_l + scen[s,:]) - np.array(list(capline.values())).reshape(len(set_nlines)))
            # plus += list( PTDF_MATRIX @ (in_gen @(dfgen.values.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta.values).reshape(len(set_ngen))) - net_l + scen[s,:]) - np.array(list(capline.values())).reshape(len(set_nlines)))
            plus += list(-PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s,:])) - np.array(list(capline.values())).reshape(len(set_nlines)))
            plus += list(PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s,:])) - np.array(list(capline.values())).reshape(len(set_nlines)))

            # model.addConstrs((gp.LinExpr([(lin_gen[l,g],gen[g]) for g in range(num_g)]) - omega[s]*gp.LinExpr([(lin_gen[l,g],factor[g]) for g in range(num_g)]) - lin_load[l] + lin_ome[l,s] >= -Pmax_l[l] - Mmin_l[s,l]*(1-y[s]) for l in line_index for s in range(num_s) if line_cons_min.at[s,l] == True))
            # plus += list(PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s,:])) - np.array(list(capline.values())).reshape(len(set_nlines)))

            aa.loc[s,'violation'] = max(plus)
        
        
        violation_prob_condicional_scen=len(aa.loc[aa['violation'] > 1e-6])/len(set_knn_real)
        # violation_prob_condicional_scen2=eps_violation(index_genbus,index_windbus,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,Omegadataknnreal,ydataknnreal_dict,set_ngen,set_nlines,set_nwind,set_nbus,gmin,gmax,capline,PTDF_dict,load,matrixGbus, matrixHbus,forecasted_wind)
        print("violation_prob_condicional_scen",violation_prob_condicional_scen)
        # print("violation_prob_condicional_scen2 metodo antiguo",violation_prob_condicional_scen2)
        
        # actual_expected_cost_scen=actual_expected_cost_linear_piecewise(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)

        
        # actual_expected_cost_scen=actual_expected_cost_linear_piecewise_beta(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)
        # actual_expected_cost_scen=actual_expected_cost_linear_piecewise_mixedgurobi(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen.to_dict()['g'],dfbeta.to_dict()['beta'],dfr_D.to_dict()['r_D'],dfr_U.to_dict()['r_U'],coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)
        # actual_expected_cost_scen=(1/len(set_knn_real))*sum( sum(max([slopes_gen[j,s]*(  (dfgen.values[j-1])[0]-(dfbeta.values[j-1])[0]*(Omegadataknnreal[i+1]))+intercepts_gen[j,s] for s in set_pieces]) +coste_reserv_d[j]*((dfr_D.values[j-1])[0])+coste_reserv_u[j]*((dfr_U.values[j-1])[0]) for j in set_ngen)      for i in range(len(set_knn_real))    )
        # actual_expected_cost_linear_piecewise_mixedgurobi
        m2 = Model('test_redispatch')
        
        
        m2=real_dispatch_piecewise_mixed_cplex(m2,index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_MATRIX,PTDF_gen,PTDF_wind,capline)
        
 
        
        m2.solve(log_output = True)
                
        sol2 = m2.solution
        
        # m.setParam('PreDual',1)
        # m.setParam('Presolve',2)
        # # m.setParam('Method',3)
        # # m.setParam('BarConvTol',1e-5)          
        # m.setParam('BarHomogeneous',1)
        # # m.setParam('ScaleFlag',3)
        # m.setParam('Threads',6)
        # m.setParam('CrossoverBasis',1)
        # m.setParam('NumericFocus',1)
        # m.optimize()
        # print("Obj value trimm-->", sol2.objective_value)
        actual_expected_cost_scen=sol2.objective_value
        # actual_expected_cost_scen=m2.getObjective().getValue()
        print("actual_expected_cost_scen",actual_expected_cost_scen)
            # actual_expected_cost_scen=actual_expected_cost_linear_piecewise(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)

        # actual_expected_cost_scen=coste
        # objval_1scen=float(modelo_dcopf1scen.obj.expr())
        # print("objval_1scen",objval_1scen)
        #quantity1knn=quantity1knn+
    #            valor_medio_var=0
        sum_reserv_total_D=0
        sum_reserv_total_U=0
        gensol={}
        betasol={}
        # for i in set_ngen:
        #     gensol[i]=float(modelo_dcopf1scen.g[i].value)
        #     betasol[i]=float(modelo_dcopf1scen.beta[i].value)  
        #     # print("g[",i,"]= ", float(modelo_dcopf1.g[i].value))
        #     # print("beta[",i,"]= ", float(modelo_dcopf1.beta[i].value))
        #     # print("r_D[",i,"]= ", float(modelo_dcopf1.r_D[i].value))
        #     # print("r_U[",i,"]= ", float(modelo_dcopf1.r_U[i].value))
        #     sum_reserv_total_D=sum_reserv_total_D+float(modelo_dcopf1scen.r_D[i].value)
        #     sum_reserv_total_U=sum_reserv_total_U+float(modelo_dcopf1scen.r_U[i].value)

        # for i in set_i:
        #     print("mubarra[",i,"]= ", float(modelo_dcopf1.mubarra[i].value))
        #     for j in set_l:
        #         # print("t[",i,",",j,"]= ", float(modelo_dcopf1.z[i,j].value))
        #         print("v[",i,",",j,"]= ", float(modelo_dcopf1.v[i,j].value))
        #         print("vtilde[",i,",",j,"]= ", float(modelo_dcopf1.vtilde[i,j].value))
        
        reserv_totscen_D=dfr_D.sum()
        reserv_totscen_U=dfr_U.sum()

        
        
        

        
        nocreado_pasadamodel=False
        # for kk in range_radios:

        print("coste real esperado conjunto scen",actual_expected_cost_scen) 
        # print("coste real esperado condicional",actual_expected_cost_kn)


        array_outofsamplecondscen=np.append(array_outofsamplecondscen,violation_prob_condicional_scen)
        array_performancecondscen=np.append(array_performancecondscen,actual_expected_cost_scen)


        data_f2scen.append(dfr_D.sum())
        data_g2scen.append(dfr_U.sum())


        
        data_a25scen.append(array_performancecondscen)
        full_file_path = os.getcwd()
        
        
        
        
        data_a24scen.append(array_outofsamplecondscen)
        
        dfdata_a24scen=pd.DataFrame(data_a24scen)
        dfdata_a24scen.to_csv('data_a24scen'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        # data_a25knn.append(array_outofsamplecondknn)
        dfdata_a25scen=pd.DataFrame(data_a25scen)
        dfdata_a25scen.to_csv('data_a25scen'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        # data_f2knn.append(array_outofsamplecondknn)
        dfdata_f2scen=pd.DataFrame(data_f2scen)
        dfdata_f2scen.to_csv('data_f2scen'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)

        dfdata_g2scen=pd.DataFrame(data_g2scen)
        dfdata_g2scen.to_csv('data_g2scen'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)




    elif metodo==2:
        #modelo R_1-K/N           
        frec_kn={}
        media_kncost={}
       
    
        
      
        
        
    #    param_min=min(dict_candidates_knboot, key=dict_candidates_knboot.get)
    #    
    #    value_knchosen=(param_min)[0]
    #    value_rochosen=(param_min)[1]
    #    print("media coste esperado modelo 1-k/n boot elegido",media_kncost[value_knchosen,value_rochosen] )
        
        
        # kn=math.floor(Nsamples/(math.log(Nsamples+1)))
        kn=math.floor(math.pow(Nsamples,0.9))
    #    print("valor k modelo 1-k/n",value_knchosen) 
        #knn=math.floor(math.pow(n_mixt_real,0.75))
        set_kn=list(range(1, kn+1))
    #    from sklearn.neighbors import KNeighborsRegressor
    #    neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)

       
        mass=kn/Nsamples
        set_i=range(1,Nsamples+1)
        print("mass",mass)
        
        
        #knn=numkn
        #knn=math.floor(math.pow(n_mixt_real,0.75))
        #set_knnrobust_boot=list(range(1, kn+1))
        # from sklearn.neighbors import KNeighborsRegressor
        # neigh = KNeighborsRegressor(n_neighbors=kn,metric='minkowski',p=1)
        #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
        #        print("y ", XX[:,1])
        puntos_zkn_array=muestra_conjunta_sample[:,[0,1,2,3,4,5,6,7]]
        puntos_ykn_array=muestra_conjunta_sample[:,[8,9,10,11,12,13,14,15,16]]
        
        puntos_omegakn_array=muestra_conjunta_sample[:,[8,9,10,11,12,13,14,15]]
        # print("puntos_omegakn_array",puntos_omegakn_array)
        puntos_Omegakn_array=(muestra_conjunta_sample[:,[16]]).reshape(Nsamples,)
        
       
        zdata=array_to_dict(puntos_zkn_array)
        # print("zdata",zdata)
        omegadata=array_to_dict(puntos_omegakn_array)
        Omegadata=array_to_dict(puntos_Omegakn_array )
        mass2=mass
        
       
                
        dist_mediaknn_boot=0
        dist_mediaknn_bootOmega=0       
        for ii in list(range(1,math.ceil(Nsamples*mass)+1)):
            dist_mediaknn_boot=dist_mediaknn_boot+(1/(Nsamples*mass))*lista_dist_min_sorted[lista_dist_min_sorted_index[ii-1]]
            dist_mediaknn_bootOmega=dist_mediaknn_bootOmega+(1/(Nsamples*mass))*lista_dist_min_sortedOmega[lista_dist_min_sortedOmega_index[ii-1]]
            # print("dist_mediaknn_boot",dist_mediaknn_boot)
           
        dist_mediaknn_boot=dist_mediaknn_boot+(1-(math.floor(Nsamples*mass))/(Nsamples*mass))*lista_dist_min_sorted[lista_dist_min_sorted_index[math.floor(Nsamples*mass)-1]]
        # print("(1-(math.floor(Nsamples*mass))/(Nsamples*mass))*lista_dist_min_sorted[ii]",(1-(math.floor(Nsamples*mass))/(Nsamples*mass))*lista_dist_min_sorted[math.floor(Nsamples*mass)-1])
        dist_mediaknn_bootOmega=dist_mediaknn_bootOmega+(1-(math.floor(Nsamples*mass))/(Nsamples*mass))*lista_dist_min_sortedOmega[lista_dist_min_sortedOmega_index[math.floor(Nsamples*mass)-1]]


        
        dist_trimm_recinto= dist_mediaknn_boot

        radio_rokn_totkn=b1+dist_trimm_recinto
        radio_rokn_totknOmega=b1+dist_mediaknn_bootOmega
        rho2=b1+dist_trimm_recinto
        print("radio_rokn_totkn",radio_rokn_totkn)
        print("dist_mediaknn_bootOmega calculanmdo la distancia al recinto",dist_mediaknn_bootOmega)
        
        
       

        # if nocreado_pasadamodel:
            # epsGD_CVAR=1/Nsamples
        
        # epsGD_CVAR=epsGD
        #     # report_timing()
        # modelo_dcopf1=DCOPF_2_linear_piecewise(lista_index_outsideOmega_left,lista_index_outsideOmega_right,index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,radio_rokn_totknOmega,set_pieces_gen,set_pieces_lines,set_i,set_l,set_p, set_ngen,set_nwind,set_nbus,set_nlines, Nsamples, zdata,omegadata,Omegadata,mass,zpred,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,load, forecasted_wind,liminf_Omega_cond,limsup_Omega_cond,matrixGbus,matrixHbus,gmin,gmax,PTDF_dict,capline,mass2,rho2,epsGD_CVAR,CT,d_vector)
        # opt = SolverFactory('gurobi')
        # results = opt.solve(modelo_dcopf1,tee=True)
       # else:
        #     modelo_dcopf1.ro =radio_rokn_totknOmega
        #     modelo_dcopf1.rho2 =rho2
            
   

        m =Model('test_trimm') 
        

        # (1/(model.N))*sum(tt[i]   for i in set_i)+sum(coste_reserv_d[j]*(r_D[j])+coste_reserv_u[j]*(r_U[j])  for j in set_ngen)
        tt=m.continuous_var_dict(list(set_i),lb=-float('inf'))
        tup=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf'))        
        tdown=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf'))
        tdata=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf')) 
        mubarra=m.continuous_var_dict(list(set_i),lb=0)
        
 
    
        r_D=m.continuous_var_dict(list(set_ngen),lb=0)
        r_U=m.continuous_var_dict(list(set_ngen),lb=0)
        g=m.continuous_var_dict(list(set_ngen),lb=-float('inf'))
        beta=m.continuous_var_dict(list(set_ngen),lb=0,ub=1)
        lamb=m.continuous_var(lb=0)
        theta=m.continuous_var(lb=-float('inf'))
         


        
        
        
        m.minimize(radio_rokn_totknOmega*lamb+theta+(1/(Nsamples*mass))*m.sum(mubarra[i] for i in set_i)+m.sum(coste_reserv_d[j]*(r_D[j])+coste_reserv_u[j]*(r_U[j])  for j in set_ngen) )
            
        c1=m.add_constraints((  mubarra[i]>=-theta-lamb*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+tt[i] for i in set_i   ))
        


        if len(lista_index_outsideOmega_left )>0:
            c11=m.add_constraints((tt[i]>=m.sum(tdown[i,j] for j in set_ngen) -lamb*(liminf_Omega_cond-Omegadata[i]) for i  in lista_index_outsideOmega_left ))
            c21=m.add_constraints((tt[i]>=m.sum(tup[i,j] for j in set_ngen) -lamb*(limsup_Omega_cond-Omegadata[i]) for i  in lista_index_outsideOmega_left ))
            
        if len(lista_index_outsideOmega_right)>0:
            c12=m.add_constraints((tt[i]>=m.sum(tdown[i,j] for j in set_ngen) +lamb*(liminf_Omega_cond-Omegadata[i]) for i   in lista_index_outsideOmega_right ))
            c22=m.add_constraints((tt[i]>=m.sum(tup[i,j] for j in set_ngen) +lamb*(limsup_Omega_cond-Omegadata[i]) for i   in lista_index_outsideOmega_right ))


        
        
        
        c13=m.add_constraints((tt[i]>=m.sum(tdown[i,j] for j in set_ngen) +lamb*(liminf_Omega_cond-Omegadata[i]) for i  in lista_index_interval ))
        
        c2=m.add_constraints((  tdown[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*liminf_Omega_cond)+intercepts_gen[j,s] for i in set_i for j in set_ngen for s in set_pieces  ))
        
  
        
        
        c23=m.add_constraints((tt[i]>=m.sum(tup[i,j] for j in set_ngen) -lamb*(limsup_Omega_cond-Omegadata[i]) for i  in lista_index_interval ))
        

        c3=m.add_constraints((  tup[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*limsup_Omega_cond)+intercepts_gen[j,s] for i in set_i for j in set_ngen for s in set_pieces  ))
             
            
        c32=m.add_constraints((  tt[i]>=m.sum(tdata[i,j] for j in set_ngen) for i in lista_index_interval  ))       

        c33=m.add_constraints((  tdata[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*Omegadata[i])+intercepts_gen[j,s] for i in lista_index_interval for j in set_ngen for s in set_pieces ))
        

        
        tauGD=m.continuous_var(lb=-float('inf'))   
        lambdaGD=m.continuous_var(lb=0)
        thetaGD=m.continuous_var(lb=-float('inf'))
        muGD=m.continuous_var_dict(list(set_i),lb=0)
        dim_d_vector=list(range(1,len(d_vector)+1))

        
        # zGD=m.addVars(list(product(set_i,set_pieces_gen,set_nwind)),name='zGD',lb=-float('inf'))
        # vGD=m.addVars(list(product(set_i,set_pieces_gen,set_nwind)),name='zGD',lb=-float('inf'))
        # vtildeGD=m.addVars(list(product(set_i,set_pieces_gen,dim_d_vector)),name='vtildeGD',lb=0)

        
        c4=m.add_constraint(tauGD+(1/epsGD)*(lambdaGD*rho2+thetaGD+(1/(Nsamples*mass2))*m.sum(muGD[i]   for i in set_i))<=0)
    
        # c42=m.addConstrs(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+(gmin[k]-g[k]-tauGD)+gp.LinExpr([ (d_vector[m],vtildeGD[i,k,m]) for  m in dim_d_vector])\
        #     -gp.LinExpr([ (omegadata[i,l],zGD[i,k,l]) for l in set_nwind])for i in set_i for k in set_ngen  ))
    
        # c43=m.addConstrs(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+gp.LinExpr([ (d_vector[m],vtildeGD[i,Ngen+1,m]) for  m in dim_d_vector])\
        #     -gp.LinExpr([ (omegadata[i,l],zGD[i,Ngen+1,l]) for l in set_nwind]) for i in set_i   ))








            
        # c44=m.addConstrs((  zGD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
        # c45=m.addConstrs((  -zGD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
    
        # c46=m.addConstrs((  vGD[i,k,l]== gp.LinExpr([ (CT[l,n],vtildeGD[i,k,n]) for n in dim_d_vector]) for i in set_i for k in set_pieces_gen for l in set_nwind )) 


    
        # c47=m.addConstrs((  zGD[i,k,l]-vGD[i,k,l]==-(beta[k]   )  for i in set_i for k in set_ngen for l in set_nwind )) 
    
        # c48=m.addConstrs((  zGD[i,Ngen+1,l]-vGD[i,Ngen+1,l]==-(0   )  for i in set_i for l in set_nwind )) 

        # zGU=m.addVars(list(product(set_i,set_pieces_gen,set_nwind)),name='zGU',lb=-float('inf'))
        # vGU=m.addVars(list(product(set_i,set_pieces_gen,set_nwind)),name='zGU',lb=-float('inf'))
        # vtildeGU=m.addVars(list(product(set_i,set_pieces_gen,dim_d_vector)),name='vtildeGU',lb=0)

        
        # c52=m.addConstrs(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+(-gmax[k]+g[k]-tauGD)+gp.LinExpr([ (d_vector[m],vtildeGU[i,k,m]) for  m in dim_d_vector])\
        #     -gp.LinExpr([ (omegadata[i,l],zGU[i,k,l]) for l in set_nwind])for i in set_i for k in set_ngen  ))
    
        # c53=m.addConstrs(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+gp.LinExpr([ (d_vector[m],vtildeGU[i,Ngen+1,m]) for  m in dim_d_vector])\
        #     -gp.LinExpr([ (omegadata[i,l],zGU[i,Ngen+1,l]) for l in set_nwind]) for i in set_i   ))


            
        # c54=m.addConstrs((  zGU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
        # c55=m.addConstrs((  -zGU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
    
        # c56=m.addConstrs((  vGU[i,k,l]== gp.LinExpr([ (CT[l,n],vtildeGU[i,k,n]) for n in dim_d_vector]) for i in set_i for k in set_pieces_gen for l in set_nwind )) 


    
        # c57=m.addConstrs((  zGU[i,k,l]-vGU[i,k,l]==-(-beta[k]   )  for i in set_i for k in set_ngen for l in set_nwind )) 
    
        # c58=m.addConstrs((  zGU[i,Ngen+1,l]-vGU[i,Ngen+1,l]==-(0   )  for i in set_i for l in set_nwind )) 


        zRD=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vRD=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vtildeRD=m.continuous_var_dict(list(product(set_i,set_pieces_gen,dim_d_vector)),lb=0)

    
        c62=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+(-r_D[k]-tauGD)+m.sum( d_vector[m]*vtildeRD[i,k,m] for  m in dim_d_vector)\
            -m.sum(omegadata[i,l]*zRD[i,k,l] for l in set_nwind) for i in set_i for k in set_ngen  ))
    
        c63=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+m.sum( d_vector[m]*vtildeRD[i,Ngen+1,m] for  m in dim_d_vector)\
            -m.sum(omegadata[i,l]*zRD[i,Ngen+1,l] for l in set_nwind) for i in set_i   ))








            
        c64=m.add_constraints((  zRD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
        c65=m.add_constraints((  -zRD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
    
        c66=m.add_constraints((  vRD[i,k,l]== m.sum( CT[l,n]*vtildeRD[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_gen for l in set_nwind )) 


    
        c67=m.add_constraints((  zRD[i,k,l]-vRD[i,k,l]==-(beta[k]   )  for i in set_i for k in set_ngen for l in set_nwind )) 
    
        c68=m.add_constraints((  zRD[i,Ngen+1,l]-vRD[i,Ngen+1,l]==-(0   )  for i in set_i for l in set_nwind )) 

        
        zRU=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vRU=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vtildeRU=m.continuous_var_dict(list(product(set_i,set_pieces_gen,dim_d_vector)),lb=0)

        
    
        c72=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+(-r_U[k]-tauGD)+m.sum( d_vector[m]*vtildeRU[i,k,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zRU[i,k,l] for l in set_nwind)for i in set_i for k in set_ngen  ))
    
        c73=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+m.sum( d_vector[m]*vtildeRU[i,Ngen+1,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zRU[i,Ngen+1,l] for l in set_nwind) for i in set_i   ))








            
        c74=m.add_constraints((  zRU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
        c75=m.add_constraints((  -zRU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
    
        c76=m.add_constraints((  vRU[i,k,l]== m.sum( CT[l,n]*vtildeRU[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_gen for l in set_nwind )) 


    
        c77=m.add_constraints((  zRU[i,k,l]-vRU[i,k,l]==-(-beta[k]   )  for i in set_i for k in set_ngen for l in set_nwind )) 
    
        c78=m.add_constraints((  zRU[i,Ngen+1,l]-vRU[i,Ngen+1,l]==-(0   )  for i in set_i for l in set_nwind ))

 




        
        zLD=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vLD=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vtildeLD=m.continuous_var_dict(list(product(set_i,set_pieces_lines,dim_d_vector)),lb=0)

        PTDF_gen=PTDF_MATRIX.transpose() @ (array_matrixGbus)
        PTDF_wind=PTDF_MATRIX.transpose() @ (array_matrixHbus)
        
        lin_load=[sum([ (PTDF_MATRIX[b-1,k-1])*(-load[b]) for b in set_nbus] ) for k in set_nlines]
        
        lin_wind=[sum([ (PTDF_wind[k-1,mm-1]*(forecasted_wind[mm])) for mm in set_nwind]) for k in set_nlines]
        
        
       
        print("creo restricciones de linea ld")
       
        
        
        c82=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+(-capline[k]-(m.sum( PTDF_gen[k-1,j-1]*g[j] for j in set_ngen)+lin_wind[k-1]+lin_load[k-1])-tauGD)+m.sum( d_vector[m]*vtildeLD[i,k,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLD[i,k,l] for l in set_nwind)for i in set_i for k in set_nlines  ))
    
        c83=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+m.sum( d_vector[m]*vtildeLD[i,Nlines+1,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLD[i,Nlines+1,l] for l in set_nwind) for i in set_i   ))






            
        c84=m.add_constraints((  zLD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
        c85=m.add_constraints((  -zLD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
    
        c86=m.add_constraints((  vLD[i,k,l]== m.sum( CT[l,n]*vtildeLD[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_lines for l in set_nwind )) 


    
        c87=m.add_constraints((  zLD[i,k,l]-vLD[i,k,l]==-(-PTDF_wind[k-1,l-1] + m.sum( PTDF_gen[k-1,j-1]*beta[j] for  j in set_ngen)  )    for i in set_i for k in set_nlines for l in set_nwind )) 
    
        c88=m.add_constraints((  zLD[i,Nlines+1,l]-vLD[i,Nlines+1,l]==-(0   )  for i in set_i for l in set_nwind ))


        print("creo restricciones de linea LU") 
        zLU=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vLU=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vtildeLU=m.continuous_var_dict(list(product(set_i,set_pieces_lines,dim_d_vector)),lb=0)


        
        
       
    
       
        
        
        c92=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+(-capline[k]+(m.sum( PTDF_gen[k-1,j-1]*g[j] for j in set_ngen)+lin_wind[k-1]+lin_load[k-1])-tauGD)+m.sum( d_vector[m]*vtildeLU[i,k,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLU[i,k,l] for l in set_nwind)for i in set_i for k in set_nlines  ))
    
        c93=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+m.sum( d_vector[m]*vtildeLU[i,Nlines+1,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLU[i,Nlines+1,l] for l in set_nwind) for i in set_i   ))






            
        c94=m.add_constraints((  zLU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
        c95=m.add_constraints((  -zLU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
    
        c96=m.add_constraints((  vLU[i,k,l]== m.sum( CT[l,n]*vtildeLU[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_lines for l in set_nwind )) 


    
        c97=m.add_constraints((  zLU[i,k,l]-vLU[i,k,l]==-(PTDF_wind[k-1,l-1]  -m.sum( PTDF_gen[k-1,j-1]*beta[j] for  j in set_ngen)  )    for i in set_i for k in set_nlines for l in set_nwind )) 
    
        c98=m.add_constraints((  zLU[i,Nlines+1,l]-vLU[i,Nlines+1,l]==-(0   )  for i in set_i for l in set_nwind ))
        
    
              
     
        c10=m.add_constraint(m.sum(g)==sum(load[b] for b in set_nbus)-sum(forecasted_wind[j] for j in set_nwind) )     
              
              
        c11=m.add_constraint(m.sum(beta)==1)      
              
        c12=m.add_constraints((  g[j]+r_U[j]<=gmax[j] for j in set_ngen  ))           

        c13=m.add_constraints((  g[j]-r_D[j]>=gmin[j] for j in set_ngen  )) 


        m.parameters.threads.set(22)
        m.parameters.preprocessing.dual.set(1)
        m.parameters.solutiontype.set(2)
        m.parameters.lpmethod.set(4)
        m.solve(log_output = True)
                
        sol = m.solution
        
        # m.setParam('PreDual',1)
        # m.setParam('Presolve',2)
        # # m.setParam('Method',3)
        # # m.setParam('BarConvTol',1e-5)          
        # m.setParam('BarHomogeneous',1)
        # # m.setParam('ScaleFlag',3)
        # m.setParam('Threads',6)
        # m.setParam('CrossoverBasis',1)
        # m.setParam('NumericFocus',1)
        # m.optimize()
        print("Obj value trimm-->", sol.objective_value)
        


        dfgen=np.asarray(list((sol.get_value_dict(g)).values()))
        dfbeta=np.asarray(list((sol.get_value_dict(beta)).values()))
        dfr_D=np.asarray(list((sol.get_value_dict(r_D)).values()))
        dfr_U=np.asarray(list((sol.get_value_dict(r_U)).values()))
        # print("dfgen",dfgen)
        # print("sol.getvalue values()",list((sol.get_value_dict(g)).values()))
        # print("sol.getvalue np array list gen",np.asarray(list((sol.get_value_dict(g)).values())))
        aa = pd.DataFrame()
        for s in range(len(set_knn_real)):
            # plus =  list( -dfgen.reshape(len(set_ngen)) + (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) + np.array(list(gmin.values())).reshape(len(set_ngen)))
            # plus += list(  dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) - np.array(list(gmax.values())).reshape(len(set_ngen)))
            plus =  list( (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) + np.array(list(-dfr_D)).reshape(len(set_ngen))) 
            plus += list(  - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) - np.array(list(dfr_U)).reshape(len(set_ngen))  )
            
            # plus += list(-PTDF_MATRIX @ (in_gen @(dfgen.values.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta.values).reshape(len(set_ngen))) - net_l + scen[s,:]) - np.array(list(capline.values())).reshape(len(set_nlines)))
            # plus += list( PTDF_MATRIX @ (in_gen @(dfgen.values.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta.values).reshape(len(set_ngen))) - net_l + scen[s,:]) - np.array(list(capline.values())).reshape(len(set_nlines)))
            plus += list(-PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s,:])) - np.array(list(capline.values())).reshape(len(set_nlines)))
            plus += list(PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s,:])) - np.array(list(capline.values())).reshape(len(set_nlines)))

            # model.addConstrs((gp.LinExpr([(lin_gen[l,g],gen[g]) for g in range(num_g)]) - omega[s]*gp.LinExpr([(lin_gen[l,g],factor[g]) for g in range(num_g)]) - lin_load[l] + lin_ome[l,s] >= -Pmax_l[l] - Mmin_l[s,l]*(1-y[s]) for l in line_index for s in range(num_s) if line_cons_min.at[s,l] == True))
            # plus += list(PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s,:])) - np.array(list(capline.values())).reshape(len(set_nlines)))

            aa.loc[s,'violation'] = max(plus)
        
        
        violation_prob_condicional_kn=len(aa.loc[aa['violation'] > 1e-6])/len(set_knn_real)
        # violation_prob_condicional_scen2=eps_violation(index_genbus,index_windbus,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,Omegadataknnreal,ydataknnreal_dict,set_ngen,set_nlines,set_nwind,set_nbus,gmin,gmax,capline,PTDF_dict,load,matrixGbus, matrixHbus,forecasted_wind)
        print("violation_prob_condicional_trimm",violation_prob_condicional_kn)
        # print("violation_prob_condicional_scen2 metodo antiguo",violation_prob_condicional_scen2)
        
        # actual_expected_cost_scen=actual_expected_cost_linear_piecewise(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)

        
        # actual_expected_cost_scen=actual_expected_cost_linear_piecewise_beta(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)
        # actual_expected_cost_scen=actual_expected_cost_linear_piecewise_mixedgurobi(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen.to_dict()['g'],dfbeta.to_dict()['beta'],dfr_D.to_dict()['r_D'],dfr_U.to_dict()['r_U'],coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)
        # actual_expected_cost_scen=(1/len(set_knn_real))*sum( sum(max([slopes_gen[j,s]*(  (dfgen.values[j-1])[0]-(dfbeta.values[j-1])[0]*(Omegadataknnreal[i+1]))+intercepts_gen[j,s] for s in set_pieces]) +coste_reserv_d[j]*((dfr_D.values[j-1])[0])+coste_reserv_u[j]*((dfr_U.values[j-1])[0]) for j in set_ngen)      for i in range(len(set_knn_real))    )
        # actual_expected_cost_linear_piecewise_mixedgurobi
        m2 = Model('test_redispatch')
        
        
        m2=real_dispatch_piecewise_mixed_cplex(m2,index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_MATRIX,PTDF_gen,PTDF_wind,capline)
        
 
        
        m2.solve(log_output = True)
                
        sol2 = m2.solution
        
        # m.setParam('PreDual',1)
        # m.setParam('Presolve',2)
        # # m.setParam('Method',3)
        # # m.setParam('BarConvTol',1e-5)          
        # m.setParam('BarHomogeneous',1)
        # # m.setParam('ScaleFlag',3)
        # m.setParam('Threads',6)
        # m.setParam('CrossoverBasis',1)
        # m.setParam('NumericFocus',1)
        # m.optimize()
        print("Obj value trimm-->", sol2.objective_value)
        actual_expected_cost_kn=sol2.objective_value
        print("actual_expected_cost_trimm",actual_expected_cost_kn)
            # actual_expected_cost_scen=actual_expected_cost_linear_piecewise(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)

        # actual_expected_cost_scen=coste
        # objval_1scen=float(modelo_dcopf1scen.obj.expr())
        # print("objval_1scen",objval_1scen)
        #quantity1knn=quantity1knn+
    #            valor_medio_var=0
        sum_reserv_total_D=0
        sum_reserv_total_U=0
        gensol={}
        betasol={}
        # for i in set_ngen:
        #     gensol[i]=float(modelo_dcopf1scen.g[i].value)
        #     betasol[i]=float(modelo_dcopf1scen.beta[i].value)  
        #     # print("g[",i,"]= ", float(modelo_dcopf1.g[i].value))
        #     # print("beta[",i,"]= ", float(modelo_dcopf1.beta[i].value))
        #     # print("r_D[",i,"]= ", float(modelo_dcopf1.r_D[i].value))
        #     # print("r_U[",i,"]= ", float(modelo_dcopf1.r_U[i].value))
        #     sum_reserv_total_D=sum_reserv_total_D+float(modelo_dcopf1scen.r_D[i].value)
        #     sum_reserv_total_U=sum_reserv_total_U+float(modelo_dcopf1scen.r_U[i].value)

        # for i in set_i:
        #     print("mubarra[",i,"]= ", float(modelo_dcopf1.mubarra[i].value))
        #     for j in set_l:
        #         # print("t[",i,",",j,"]= ", float(modelo_dcopf1.z[i,j].value))
        #         print("v[",i,",",j,"]= ", float(modelo_dcopf1.v[i,j].value))
        #         print("vtilde[",i,",",j,"]= ", float(modelo_dcopf1.vtilde[i,j].value))
        
        reserv_tot_D=dfr_D.sum()
        reserv_tot_U=dfr_U.sum()


        # results = opt.solve(modelo_dcopf1)
        #        modeloknn.load(results)
    #    results.write()
        # modelo_dcopf1.display()
    #    modelokn.pprint() 
        # if (results.solver.status == SolverStatus.ok):
        
        # print("lambda sol", modelo_dcopf1.lamb.value)
    #     objval_1kn=float(modelo_dcopf1.obj.expr())
    #     print("objval_trimmings",objval_1kn)
    #     nocreado_pasadamodel=False
    #     #quantity1knn=quantity1knn+
    # #            valor_medio_var=0
    #     sum_reserv_total_D=0
    #     sum_reserv_total_U=0

    #     #         print("vtilde[",i,",",j,"]= ", float(modelo_dcopf1.vtilde[i,j].value))
        
    #     reserv_tot_D=sum_reserv_total_D
    #     reserv_tot_U=sum_reserv_total_U

    #     # beta1=float(modelo_dcopf1.beta[1].value)
    #     # beta2=float(modelo_dcopf1.beta[2].value)
    #     # gen1=float(modelo_dcopf1.g[1].value)
    #     # gen2=float(modelo_dcopf1.g[2].value)
    #     # print(gen1,gen2,beta1,beta2)
    #     # print("reserv_tot",reserv_tot)
        
    # #            for i in set_knn_real:
    # #                for j in set_dx:
    # #            #        print("solucion x ",modeloknn.x[j].value )
    # #                    valor_medio_var=valor_medio_var+modeloknn.x[j].value*ydataknn[i,j]
    # #            
    # #            valor_medio_var=valor_medio_var/len(set_knn_real)
    # #            print("beta=  ", modeloknn.beta.value, "    ", "valor objetivo ",objval_1knn )
        
    # #            print("CVAR",objval_1knn+valor_medio_var )
    
    # #        modeloknn.load(results)
    # #        results.write()
    # #        modeloknn.display()
    # #        modeloknn.pprint() 
    
        
        
        
        # violation_prob_condicional_kn=len(aa.loc[aa['violation'] > 1e-6])/len(set_knn_real)
        
        
        
        
        # violation_prob_condicional_kn=eps_violation(index_genbus,index_windbus,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,Omegadataknnreal,ydataknnreal_dict,set_ngen,set_nlines,set_nwind,set_nbus,gmin,gmax,capline,PTDF_dict,load,matrixGbus, matrixHbus,forecasted_wind)
        # print("violation_prob_condicional_kn",violation_prob_condicional_kn) 
        array_outofsamplecond=np.append(array_outofsamplecond,violation_prob_condicional_kn)
               


        # actual_expected_cost_kn=actual_expected_cost_linear_piecewise(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)
        
        # actual_expected_cost_kn=actual_expected_cost_linear_piecewise_beta(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)
        # actual_expected_cost_kn=(1/len(set_knn_real))*sum( sum(max([slopes_gen[j,s]*(  (dfgen.values[j-1])[0]-(dfbeta.values[j-1])[0]*(Omegadataknnreal[i+1]))+intercepts_gen[j,s] for s in set_pieces]) +coste_reserv_d[j]*((dfr_D.values[j-1])[0])+coste_reserv_u[j]*((dfr_U.values[j-1])[0]) for j in set_ngen)      for i in range(len(set_knn_real))    )

        # actual_expected_cost_kn=actual_expected_cost_linear_piecewise(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)
        
        # actual_expected_cost_kn=
        print("actual_expected_cost_kn",actual_expected_cost_kn)





        array_performancecond=np.append(array_performancecond,actual_expected_cost_kn)
        array_reserv_tot_D=np.append(array_reserv_tot_D,reserv_tot_D)
        array_reserv_tot_U=np.append(array_reserv_tot_U,reserv_tot_U)
        
        data_f2.append(array_reserv_tot_D)
        data_g2.append(array_reserv_tot_U)
        # data_g2knn.append(array_gen3knn)
        # data_a22knn.append(array_beta1knn)
        # data_a23knn.append(array_beta2knn)
        # data_a26knn.append(array_beta3knn)
        
        data_a25.append(array_performancecond)
        full_file_path = os.getcwd()
        
        
        
        
        data_a24.append(array_outofsamplecond)
        
        dfdata_a24=pd.DataFrame(data_a24)
        dfdata_a24.to_csv('data_a24'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        # data_a25knn.append(array_outofsamplecondknn)
        dfdata_a25=pd.DataFrame(data_a25)
        dfdata_a25.to_csv('data_a25'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        # data_f2knn.append(array_outofsamplecondknn)
        dfdata_f2=pd.DataFrame(data_f2)
        dfdata_f2.to_csv('data_f2'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_g2=pd.DataFrame(data_g2)
        dfdata_g2.to_csv('data_g2'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
    elif metodo==3:
        rho2kuhn=b1
        # if nocreado_pasadamodel:

        
        
        
        
        
        
        m =Model('test_kuhn') 
        

        # (1/(model.N))*sum(tt[i]   for i in set_i)+sum(coste_reserv_d[j]*(r_D[j])+coste_reserv_u[j]*(r_U[j])  for j in set_ngen)
        tt=m.continuous_var_dict(list(set_i),lb=-float('inf'))
        tup=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf'))        
        tdown=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf'))
        tdata=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf')) 
        mubarra=m.continuous_var_dict(list(set_i),lb=-float('inf'))
        
 
    
        r_D=m.continuous_var_dict(list(set_ngen),lb=0)
        r_U=m.continuous_var_dict(list(set_ngen),lb=0)
        g=m.continuous_var_dict(list(set_ngen),lb=-float('inf'))
        beta=m.continuous_var_dict(list(set_ngen),lb=0,ub=1)
        lamb=m.continuous_var(lb=0)
        # theta=m.continuous_var(lb=-float('inf'))
         



                

                

        
        
        m.minimize(rho2kuhn*lamb+(1/(Nsamples))*m.sum(mubarra[i] for i in set_i)+m.sum(coste_reserv_d[j]*(r_D[j])+coste_reserv_u[j]*(r_U[j])  for j in set_ngen) )
            
        c1=m.add_constraints((  mubarra[i]>=tt[i] for i in set_i   ))
        



        
        
        
        c13=m.add_constraints((tt[i]>=m.sum(tdown[i,j] for j in set_ngen) +lamb*(liminf_Omega_conjunta-Omegadata[i]) for i  in set_i ))
        
        c2=m.add_constraints((  tdown[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*liminf_Omega_conjunta)+intercepts_gen[j,s] for i in set_i for j in set_ngen for s in set_pieces  ))
        
  
        
        
        c23=m.add_constraints((tt[i]>=m.sum(tup[i,j] for j in set_ngen) -lamb*(limsup_Omega_conjunta-Omegadata[i]) for i  in set_i ))
        

        c3=m.add_constraints((  tup[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*limsup_Omega_conjunta)+intercepts_gen[j,s] for i in set_i for j in set_ngen for s in set_pieces  ))
             
            
        c32=m.add_constraints((  tt[i]>=m.sum(tdata[i,j] for j in set_ngen) for i in set_i  ))       

        c33=m.add_constraints((  tdata[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*Omegadata[i])+intercepts_gen[j,s] for i in set_i for j in set_ngen for s in set_pieces ))
        

        
        tauGD=m.continuous_var(lb=-float('inf'))   
        lambdaGD=m.continuous_var(lb=0)
        # thetaGD=m.continuous_var(lb=-float('inf'))
        muGD=m.continuous_var_dict(list(set_i),lb=-float('inf'))
        # dim_d_vector=list(range(1,len(d_vector)+1))
        # tauGD=m.addVar(name='tauGD',lb=-float('inf'))   
        # lambdaGD=m.addVar(name='lamb',lb=0)
        # thetaGD=m.addVar(name='thetaGD',lb=-float('inf'))
        # muGD=m.addVars(list(set_i),name='muGD',lb=-float('inf'))
        dim_d_vector=list(range(1,len(d_vectorconjunta)+1))

        
        # zGD=m.addVars(list(product(set_i,set_pieces_gen,set_nwind)),name='zGD',lb=-float('inf'))
        # vGD=m.addVars(list(product(set_i,set_pieces_gen,set_nwind)),name='zGD',lb=-float('inf'))
        # vtildeGD=m.addVars(list(product(set_i,set_pieces_gen,dim_d_vector)),name='vtildeGD',lb=0)

        
        # c4=m.addConstr(tauGD+(1/epsGD)*(lambdaGD*rho2kuhn+(1/(Nsamples))*sum(muGD[i]   for i in set_i))<=0)
        
        # zGD=m.addVars(list(product(set_i,set_pieces_gen,set_nwind)),name='zGD',lb=-float('inf'))
        # vGD=m.addVars(list(product(set_i,set_pieces_gen,set_nwind)),name='zGD',lb=-float('inf'))
        # vtildeGD=m.addVars(list(product(set_i,set_pieces_gen,dim_d_vector)),name='vtildeGD',lb=0)

        
        c4=m.add_constraint(tauGD+(1/epsGD)*(lambdaGD*rho2kuhn+(1/(Nsamples))*m.sum(muGD[i]   for i in set_i))<=0)
    



        zRD=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vRD=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vtildeRD=m.continuous_var_dict(list(product(set_i,set_pieces_gen,dim_d_vector)),lb=0)

    
        c62=m.add_constraints(( muGD[i]>=(-r_D[k]-tauGD)+m.sum( d_vectorconjunta[m]*vtildeRD[i,k,m] for  m in dim_d_vector)\
            -m.sum(omegadata[i,l]*zRD[i,k,l] for l in set_nwind) for i in set_i for k in set_ngen  ))
    
        c63=m.add_constraints(( muGD[i]>=m.sum( d_vectorconjunta[m]*vtildeRD[i,Ngen+1,m] for  m in dim_d_vector)\
            -m.sum(omegadata[i,l]*zRD[i,Ngen+1,l] for l in set_nwind) for i in set_i   ))








            
        c64=m.add_constraints((  zRD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
        c65=m.add_constraints((  -zRD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
    
        c66=m.add_constraints((  vRD[i,k,l]== m.sum( CT[l,n]*vtildeRD[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_gen for l in set_nwind )) 


    
        c67=m.add_constraints((  zRD[i,k,l]-vRD[i,k,l]==-(beta[k]   )  for i in set_i for k in set_ngen for l in set_nwind )) 
    
        c68=m.add_constraints((  zRD[i,Ngen+1,l]-vRD[i,Ngen+1,l]==-(0   )  for i in set_i for l in set_nwind )) 

        
        zRU=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vRU=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vtildeRU=m.continuous_var_dict(list(product(set_i,set_pieces_gen,dim_d_vector)),lb=0)

        
    
        c72=m.add_constraints(( muGD[i]>=(-r_U[k]-tauGD)+m.sum( d_vectorconjunta[m]*vtildeRU[i,k,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zRU[i,k,l] for l in set_nwind)for i in set_i for k in set_ngen  ))
    
        c73=m.add_constraints(( muGD[i]>=m.sum( d_vectorconjunta[m]*vtildeRU[i,Ngen+1,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zRU[i,Ngen+1,l] for l in set_nwind) for i in set_i   ))








            
        c74=m.add_constraints((  zRU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
        c75=m.add_constraints((  -zRU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
    
        c76=m.add_constraints((  vRU[i,k,l]== m.sum( CT[l,n]*vtildeRU[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_gen for l in set_nwind )) 


    
        c77=m.add_constraints((  zRU[i,k,l]-vRU[i,k,l]==-(-beta[k]   )  for i in set_i for k in set_ngen for l in set_nwind )) 
    
        c78=m.add_constraints((  zRU[i,Ngen+1,l]-vRU[i,Ngen+1,l]==-(0   )  for i in set_i for l in set_nwind ))

 




        
        zLD=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vLD=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vtildeLD=m.continuous_var_dict(list(product(set_i,set_pieces_lines,dim_d_vector)),lb=0)

        PTDF_gen=PTDF_MATRIX.transpose() @ (array_matrixGbus)
        PTDF_wind=PTDF_MATRIX.transpose() @ (array_matrixHbus)
        
        lin_load=[sum([ (PTDF_MATRIX[b-1,k-1])*(-load[b]) for b in set_nbus] ) for k in set_nlines]
        
        lin_wind=[sum([ (PTDF_wind[k-1,mm-1]*(forecasted_wind[mm])) for mm in set_nwind]) for k in set_nlines]
        
        
       
        print("creo restricciones de linea ld")
       
        
        
        c82=m.add_constraints(( muGD[i]>=(-capline[k]-(m.sum( PTDF_gen[k-1,j-1]*g[j] for j in set_ngen)+lin_wind[k-1]+lin_load[k-1])-tauGD)+m.sum( d_vectorconjunta[m]*vtildeLD[i,k,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLD[i,k,l] for l in set_nwind)for i in set_i for k in set_nlines  ))
    
        c83=m.add_constraints(( muGD[i]>=m.sum( d_vectorconjunta[m]*vtildeLD[i,Nlines+1,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLD[i,Nlines+1,l] for l in set_nwind) for i in set_i   ))






            
        c84=m.add_constraints((  zLD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
        c85=m.add_constraints((  -zLD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
    
        c86=m.add_constraints((  vLD[i,k,l]== m.sum( CT[l,n]*vtildeLD[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_lines for l in set_nwind )) 


    
        c87=m.add_constraints((  zLD[i,k,l]-vLD[i,k,l]==-(-PTDF_wind[k-1,l-1] + m.sum( PTDF_gen[k-1,j-1]*beta[j] for  j in set_ngen)  )    for i in set_i for k in set_nlines for l in set_nwind )) 
    
        c88=m.add_constraints((  zLD[i,Nlines+1,l]-vLD[i,Nlines+1,l]==-(0   )  for i in set_i for l in set_nwind ))


        print("creo restricciones de linea LU") 
        zLU=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vLU=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vtildeLU=m.continuous_var_dict(list(product(set_i,set_pieces_lines,dim_d_vector)),lb=0)


        
        
       
    
       
        
        
        c92=m.add_constraints(( muGD[i]>=(-capline[k]+(m.sum( PTDF_gen[k-1,j-1]*g[j] for j in set_ngen)+lin_wind[k-1]+lin_load[k-1])-tauGD)+m.sum( d_vectorconjunta[m]*vtildeLU[i,k,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLU[i,k,l] for l in set_nwind)for i in set_i for k in set_nlines  ))
    
        c93=m.add_constraints(( muGD[i]>=m.sum( d_vectorconjunta[m]*vtildeLU[i,Nlines+1,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLU[i,Nlines+1,l] for l in set_nwind) for i in set_i   ))






            
        c94=m.add_constraints((  zLU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
        c95=m.add_constraints((  -zLU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
    
        c96=m.add_constraints((  vLU[i,k,l]== m.sum( CT[l,n]*vtildeLU[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_lines for l in set_nwind )) 


    
        c97=m.add_constraints((  zLU[i,k,l]-vLU[i,k,l]==-(PTDF_wind[k-1,l-1]  -m.sum( PTDF_gen[k-1,j-1]*beta[j] for  j in set_ngen)  )    for i in set_i for k in set_nlines for l in set_nwind )) 
    
        c98=m.add_constraints((  zLU[i,Nlines+1,l]-vLU[i,Nlines+1,l]==-(0   )  for i in set_i for l in set_nwind ))
        
    
              
     
        c10=m.add_constraint(m.sum(g)==sum(load[b] for b in set_nbus)-sum(forecasted_wind[j] for j in set_nwind) )     
              
              
        c11=m.add_constraint(m.sum(beta)==1)      
              
        c12=m.add_constraints((  g[j]+r_U[j]<=gmax[j] for j in set_ngen  ))           

        c13=m.add_constraints((  g[j]-r_D[j]>=gmin[j] for j in set_ngen  )) 


        m.parameters.threads.set(22)
        m.parameters.preprocessing.dual.set(1)
        m.parameters.solutiontype.set(2)
        m.parameters.lpmethod.set(4)
        m.solve(log_output = True)
                
        sol = m.solution
        
        # m.setParam('PreDual',1)
        # m.setParam('Presolve',2)
        # # m.setParam('Method',3)
        # # m.setParam('BarConvTol',1e-5)          
        # m.setParam('BarHomogeneous',1)
        # # m.setParam('ScaleFlag',3)
        # m.setParam('Threads',6)
        # m.setParam('CrossoverBasis',1)
        # m.setParam('NumericFocus',1)
        # m.optimize()
        print("Obj value kuhn-->", sol.objective_value)
        


        dfgen=np.asarray(list((sol.get_value_dict(g)).values()))
        dfbeta=np.asarray(list((sol.get_value_dict(beta)).values()))
        dfr_D=np.asarray(list((sol.get_value_dict(r_D)).values()))
        dfr_U=np.asarray(list((sol.get_value_dict(r_U)).values()))
        
        
        
        
        
        
        
        aa = pd.DataFrame()
        for s in range(len(set_knn_real)):
            # plus =  list( -dfgen.reshape(len(set_ngen)) + (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) + np.array(list(gmin.values())).reshape(len(set_ngen)))
            # plus += list(  dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) - np.array(list(gmax.values())).reshape(len(set_ngen)))
            plus =  list( (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) + np.array(list(-dfr_D)).reshape(len(set_ngen))) 
            plus += list(  - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) - np.array(list(dfr_U)).reshape(len(set_ngen))  )
            
            # plus += list(-PTDF_MATRIX @ (in_gen @(dfgen.values.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta.values).reshape(len(set_ngen))) - net_l + scen[s,:]) - np.array(list(capline.values())).reshape(len(set_nlines)))
            # plus += list( PTDF_MATRIX @ (in_gen @(dfgen.values.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta.values).reshape(len(set_ngen))) - net_l + scen[s,:]) - np.array(list(capline.values())).reshape(len(set_nlines)))
            plus += list(-PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s,:])) - np.array(list(capline.values())).reshape(len(set_nlines)))
            plus += list(PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s,:])) - np.array(list(capline.values())).reshape(len(set_nlines)))

            # model.addConstrs((gp.LinExpr([(lin_gen[l,g],gen[g]) for g in range(num_g)]) - omega[s]*gp.LinExpr([(lin_gen[l,g],factor[g]) for g in range(num_g)]) - lin_load[l] + lin_ome[l,s] >= -Pmax_l[l] - Mmin_l[s,l]*(1-y[s]) for l in line_index for s in range(num_s) if line_cons_min.at[s,l] == True))
            # plus += list(PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s,:])) - np.array(list(capline.values())).reshape(len(set_nlines)))

            aa.loc[s,'violation'] = max(plus)
        
        
        violation_prob_condicional_kuhn=len(aa.loc[aa['violation'] > 1e-6])/len(set_knn_real)
        # violation_prob_condicional_scen2=eps_violation(index_genbus,index_windbus,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,Omegadataknnreal,ydataknnreal_dict,set_ngen,set_nlines,set_nwind,set_nbus,gmin,gmax,capline,PTDF_dict,load,matrixGbus, matrixHbus,forecasted_wind)
        print("violation_prob_condicional_kuhn",violation_prob_condicional_kuhn)
        # print("violation_prob_condicional_scen2 metodo antiguo",violation_prob_condicional_scen2)
        
        # actual_expected_cost_scen=actual_expected_cost_linear_piecewise(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)

        
        # actual_expected_cost_scen=actual_expected_cost_linear_piecewise_beta(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)
        # actual_expected_cost_scen=actual_expected_cost_linear_piecewise_mixedgurobi(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen.to_dict()['g'],dfbeta.to_dict()['beta'],dfr_D.to_dict()['r_D'],dfr_U.to_dict()['r_U'],coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)
        # actual_expected_cost_scen=(1/len(set_knn_real))*sum( sum(max([slopes_gen[j,s]*(  (dfgen.values[j-1])[0]-(dfbeta.values[j-1])[0]*(Omegadataknnreal[i+1]))+intercepts_gen[j,s] for s in set_pieces]) +coste_reserv_d[j]*((dfr_D.values[j-1])[0])+coste_reserv_u[j]*((dfr_U.values[j-1])[0]) for j in set_ngen)      for i in range(len(set_knn_real))    )
        # actual_expected_cost_linear_piecewise_mixedgurobi
        m2 = Model('test_redispatch')
        
        
        m2=real_dispatch_piecewise_mixed_cplex(m2,index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_MATRIX,PTDF_gen,PTDF_wind,capline)
        
 
        
        m2.solve(log_output = True)
                
        sol2 = m2.solution
        
        # m.setParam('PreDual',1)
        # m.setParam('Presolve',2)
        # # m.setParam('Method',3)
        # # m.setParam('BarConvTol',1e-5)          
        # m.setParam('BarHomogeneous',1)
        # # m.setParam('ScaleFlag',3)
        # m.setParam('Threads',6)
        # m.setParam('CrossoverBasis',1)
        # m.setParam('NumericFocus',1)
        # m.optimize()
        print("Obj value kuhn redespacho-->", sol2.objective_value)
        actual_expected_cost_kuhn=sol2.objective_value
        # actual_expected_cost_kuhn=m2.getObjective().getValue()
        print("actual_expected_cost_kuhn",actual_expected_cost_kuhn)
            # actual_expected_cost_scen=actual_expected_cost_linear_piecewise(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)

        # actual_expected_cost_scen=coste
        # objval_1scen=float(modelo_dcopf1scen.obj.expr())
        # print("objval_1scen",objval_1scen)
        #quantity1knn=quantity1knn+
    #            valor_medio_var=0
        sum_reserv_total_D=0
        sum_reserv_total_U=0
        gensol={}
        betasol={}
        # for i in set_ngen:

        reserv_totkuhn_D=dfr_D.sum()
        reserv_totkuhn_U=dfr_U.sum()
        

     
        
        
        
        # violation_prob_condicional_kuhn=eps_violation(index_genbus,index_windbus,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,Omegadataknnreal,ydataknnreal_dict,set_ngen,set_nlines,set_nwind,set_nbus,gmin,gmax,capline,PTDF_dict,load,matrixGbus, matrixHbus,forecasted_wind)
        print("violation_prob_condicional_kuhn",violation_prob_condicional_kuhn)
        # actual_expected_cost_kuhn=(1/len(set_knn_real))*sum( sum(max([slopes_gen[j,s]*(  (dfgen.values[j-1])[0]-(dfbeta.values[j-1])[0]*(Omegadataknnreal[i+1]))+intercepts_gen[j,s] for s in set_pieces]) +coste_reserv_d[j]*((dfr_D.values[j-1])[0])+coste_reserv_u[j]*((dfr_U.values[j-1])[0]) for j in set_ngen)      for i in range(len(set_knn_real))    )
        # actual_expected_cost_kuhn=actual_expected_cost_linear_piecewise(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)
        # actual_expected_cost_kn= actual_expected_cost(betasol,gensol,coste1,coste2,coste3,Omegadataknndroboot,len(Omegadataknndroboot),set_ngen)
        # out_of_samplecondkuhn=actual_expected_cost_kuhn-float(modelo_dcopf1kuhn.obj.expr())
    
        
    #    actual_expected_cost_kn=actual_expected_cost(modelokn.beta.value,vector_xsol_kn,muestra_dist_real,len(set_knn_real))
    #
       
        
        # out_of_sample_kn=actual_expected_cost_kn-float(modelokn.obj.expr())                   
        # print("out of sample kuhn", out_of_samplecondkuhn )       
        # print("objval_1kuhn valor obj",objval_1kuhn)
        print("coste real esperado conjunto kuhn",actual_expected_cost_kuhn) 
        # print("coste real esperado condicional",actual_expected_cost_kn)
        
        
        # array_gen1kuhn=np.append(array_gen1kuhn, (dfgen.values).tolist()[0][0])
        # array_gen2kuhn=np.append(array_gen2kuhn, (dfgen.values).tolist()[1][0])
        # array_reserv_totkuhn_D=np.append(array_reserv_totkuhn_D,reserv_totkuhn_D)
        # array_reserv_totkuhn_U=np.append(array_reserv_totkuhn_U,reserv_totkuhn_U)
        # array_gen3kuhn=np.append(array_gen3kuhn, (dfgen.values).tolist()[2][0])
        # array_beta1kuhn=np.append(array_beta1kuhn, (dfbeta.values).tolist()[0][0])
        # array_beta2kuhn=np.append(array_beta2kuhn, (dfbeta.values).tolist()[1][0])
        # array_beta3kuhn=np.append(array_beta3kuhn, (dfbeta.values).tolist()[2][0])

        array_outofsamplecondkuhn=np.append(array_outofsamplecondkuhn,violation_prob_condicional_kuhn)
        array_performancecondkuhn=np.append(array_performancecondkuhn,actual_expected_cost_kuhn)

        array_reserv_totkuhn_D=np.append(array_reserv_totkuhn_D,reserv_totkuhn_D)
        array_reserv_totkuhn_U=np.append(array_reserv_totkuhn_U,reserv_totkuhn_U)
        
        data_f2kuhn.append(array_reserv_totkuhn_D)
        data_g2kuhn.append(array_reserv_totkuhn_U)


        
        data_a25kuhn.append(array_performancecondkuhn)
        full_file_path = os.getcwd()
        
        
        
        
        data_a24kuhn.append(array_outofsamplecondkuhn)
        
        dfdata_a24kuhn=pd.DataFrame(data_a24kuhn)
        dfdata_a24kuhn.to_csv('data_a24kuhn'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        # data_a25knn.append(array_outofsamplecondknn)
        dfdata_a25kuhn=pd.DataFrame(data_a25kuhn)
        dfdata_a25kuhn.to_csv('data_a25kuhn'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        # data_f2knn.append(array_outofsamplecondknn)
        dfdata_f2kuhn=pd.DataFrame(data_f2kuhn)
        dfdata_f2kuhn.to_csv('data_f2kuhn'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)

        dfdata_g2kuhn=pd.DataFrame(data_g2kuhn)
        dfdata_g2kuhn.to_csv('data_g2kuhn'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
