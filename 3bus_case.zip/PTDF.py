import pandas as pd
import numpy as np
#  lines - parameters of line
#  n_nodes - number of nodes
#  node_ref - reference node

def ptdf_matrix(lines,n_nodes,node_ref):

    list_nodes = list(range(1,n_nodes+1))
    
    X = pd.DataFrame(0,index=lines.index,columns=lines.index) # Diagonal matrix of branch reactances
    B = pd.DataFrame(0,index=list_nodes,columns=list_nodes)   # B is the Img of Admitance matrix
    A = pd.DataFrame(0,index=lines.index,columns=list_nodes)  # Incidence matrix
    
    for l in lines.index: 
        X.loc[l,l] = 1/lines.loc[l,'Suscep(MW)']
        from_bus = lines.loc[l,'from_bus']
        to_bus = lines.loc[l,'to_bus']
        A.loc[l,from_bus] = 1
        A.loc[l,to_bus]   = -1
        
    for n in list_nodes:
        node_list   = lines[lines.loc[:,'from_bus'] == n].loc[:,'to_bus'].to_list()
        line_susc   = lines[lines.loc[:,'from_bus'] == n].loc[:,'Suscep(MW)'].to_list()
        node_list   += lines[lines.loc[:,'to_bus'] == n].loc[:,'from_bus'].to_list()
        line_susc   += lines[lines.loc[:,'to_bus'] == n].loc[:,'Suscep(MW)'].to_list()
            
            
        B.loc[n,n]  = sum(line_susc[i] for i in range(len(node_list)))
        for i in range(len(node_list)):  
            B.loc[n,node_list[i]] = -line_susc[i]
    
    
    # Convert to matrix
    B = B.drop(index=node_ref)
    B = B.drop(columns=[node_ref],axis=1)
    A = A.drop(columns=[node_ref],axis=1)
    
    X_m = X.values
    B_m = B.values
    A_m = A.values
    
    S_f = np.dot(np.linalg.inv(X_m),np.dot(A_m,np.linalg.inv(B_m)))
    list_nodes.remove(node_ref)
    PTDF = pd.DataFrame(S_f,index=lines.index,columns=list_nodes)
    
    return PTDF
