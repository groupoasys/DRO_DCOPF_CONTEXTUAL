# -*- coding: utf-8 -*-
"""
Created on Mon Feb  3 18:14:29 2020

@author: Usuario
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Dec 11 10:34:36 2019

@author: Usuario
"""
# from pyomo.environ import *
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 10.7})
#plt.rc('axes', facecolor = 'white')

from docplex.mp.model import Model
import random

import pandas as pd
import scipy
import math
import random
from numpy import linalg
import pandas as pd
import scipy
import math
#from pyomo.environ import *
from collections import defaultdict
# from pyomo.opt import SolverStatus, TerminationCondition
from matplotlib import pyplot as plt
from sklearn.neighbors import KNeighborsRegressor
import numpy as np
import pandas as pd
import scipy
import csv
import pandas as pd 
from random import randint
import power_tools
import pandas as pd
import numpy as np
import pandas as pd
import numpy as np
#  lines - parameters of line
#  n_nodes - number of nodes
#  node_ref - reference node

def ptdf_matrix(lines,n_nodes,node_ref):

    list_nodes = list(range(1,n_nodes+1))
    
    X = pd.DataFrame(0,index=lines.index,columns=lines.index) # Diagonal matrix of branch reactances
    B = pd.DataFrame(0,index=list_nodes,columns=list_nodes)   # B is the Img of Admitance matrix
    A = pd.DataFrame(0,index=lines.index,columns=list_nodes)  # Incidence matrix
    
    for l in lines.index: 
        X.loc[l,l] = 1/lines.loc[l,'Suscep(MW)']
        from_bus = lines.loc[l,'from_bus']
        to_bus = lines.loc[l,'to_bus']
        A.loc[l,from_bus] = 1
        A.loc[l,to_bus]   = -1
        
    for n in list_nodes:
        node_list   = lines[lines.loc[:,'from_bus'] == n].loc[:,'to_bus'].to_list()
        line_susc   = lines[lines.loc[:,'from_bus'] == n].loc[:,'Suscep(MW)'].to_list()
        node_list   += lines[lines.loc[:,'to_bus'] == n].loc[:,'from_bus'].to_list()
        line_susc   += lines[lines.loc[:,'to_bus'] == n].loc[:,'Suscep(MW)'].to_list()
            
            
        B.loc[n,n]  = sum(line_susc[i] for i in range(len(node_list)))
        for i in range(len(node_list)):  
            B.loc[n,node_list[i]] = -line_susc[i]
    
    
    # Convert to matrix
    B = B.drop(index=node_ref)
    B = B.drop(columns=[node_ref],axis=1)
    A = A.drop(columns=[node_ref],axis=1)
    
    X_m = X.values
    B_m = B.values
    A_m = A.values
    
    S_f = np.dot(np.linalg.inv(X_m),np.dot(A_m,np.linalg.inv(B_m)))
    list_nodes.remove(node_ref)
    PTDF = pd.DataFrame(S_f,index=lines.index,columns=list_nodes)
    
    return PTDF




# import pyomo.environ as pe
from collections import defaultdict
# from pyomo.opt import SolverStatus, TerminationCondition
# from pyomo.opt.base import SolverFactory
from matplotlib import pyplot as plt
from sklearn.neighbors import KNeighborsRegressor
import numpy as np
import pandas as pd
import scipy
import csv
import pandas as pd 
from random import randint
from scipy import array, linalg, dot
from numpy.linalg import inv
plt.rcParams.update({'font.size': 12})
import numpy as np
import pandas as pd
import os
from collections import defaultdict
# from pyomo.opt import SolverStatus, TerminationCondition
from matplotlib import pyplot as plt
from sklearn.neighbors import KNeighborsRegressor
import numpy as np
import pandas as pd
import scipy
import csv
import pandas as pd 
from random import randint
from scipy import array, linalg, dot
from numpy.linalg import inv
plt.rcParams.update({'font.size': 12})
import numpy as np
import pandas as pd
import os
from scipy import integrate
from scipy import linalg
from numpy.linalg import matrix_power
from scipy.stats import norm,beta
from scipy.stats.mstats import mquantiles
# from pyomo.opt import SolverStatus, TerminationCondition
import numpy as np
import matplotlib.pyplot as plt
import numpy as np
from numpy import array,append
from sklearn.cluster import KMeans
from sklearn import datasets,svm
from sklearn.svm import SVC
# from pyomo.environ import *
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import integrate
from scipy.stats import beta
from scipy.stats.mstats import mquantiles
# from pyomo.opt import SolverStatus, TerminationCondition
from sklearn.linear_model import SGDClassifier
from sklearn.svm import LinearSVC
# from sklearn.datasets.samples_generator import make_blobs
from sklearn.decomposition import PCA
from sklearn.multiclass import OneVsRestClassifier
from sklearn import tree
from scipy.stats import beta
def array_to_dict(array):
    shp=np.shape(array)
    length=len(shp)
    assert length>0 and length<4 
    dictionary={}
    if length==3:
        l,n,m=shp
        for k in range(l):
            for i in range(n):
                for j in range(m):
                    dictionary[str(k)+str(i)+str(j)]=array[k,i,j]
    elif length==2:
        n,m=shp 
        for i in range(n):
            for j in range(m):
                dictionary[(i+1,j+1)]=array[i,j]
    elif length==1:
        dictionary=dict([i+1,array[i]] for i in range(shp[0]))
    return dictionary

def ptdf_matrix(lines,n_nodes,node_ref):

    list_nodes = list(range(1,n_nodes+1))
    
    X = pd.DataFrame(0,index=lines.index,columns=lines.index) # Diagonal matrix of branch reactances
    B = pd.DataFrame(0,index=list_nodes,columns=list_nodes)   # B is the Img of Admitance matrix
    A = pd.DataFrame(0,index=lines.index,columns=list_nodes)  # Incidence matrix
    
    for l in lines.index: 
        X.loc[l,l] = 1/lines.loc[l,'Suscep(MW)']
        from_bus = lines.loc[l,'from_bus']
        to_bus = lines.loc[l,'to_bus']
        A.loc[l,from_bus] = 1
        A.loc[l,to_bus]   = -1
        
    for n in list_nodes:
        node_list   = lines[lines.loc[:,'from_bus'] == n].loc[:,'to_bus'].to_list()
        line_susc   = lines[lines.loc[:,'from_bus'] == n].loc[:,'Suscep(MW)'].to_list()
        node_list   += lines[lines.loc[:,'to_bus'] == n].loc[:,'from_bus'].to_list()
        line_susc   += lines[lines.loc[:,'to_bus'] == n].loc[:,'Suscep(MW)'].to_list()
            
            
        B.loc[n,n]  = sum(line_susc[i] for i in range(len(node_list)))
        for i in range(len(node_list)):  
            B.loc[n,node_list[i]] = -line_susc[i]
    
    
    # Convert to matrix
    B = B.drop(index=node_ref)
    B = B.drop(columns=[node_ref],axis=1)
    A = A.drop(columns=[node_ref],axis=1)
    
    X_m = X.values
    B_m = B.values
    A_m = A.values
    
    S_f = np.dot(np.linalg.inv(X_m),np.dot(A_m,np.linalg.inv(B_m)))
    list_nodes.remove(node_ref)
    PTDF = pd.DataFrame(S_f,index=lines.index,columns=list_nodes)
    
    return PTDF

    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='mdc opf two stage, unc. set norma infinito de radio W')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    model.p=pe.Set(initialize=set_p) #dim z
    # model.p.pprint()
    model.l=pe.Set(initialize=set_l) #dim omega
    
    model.ngen=pe.Set(initialize=set_ngen)
    model.nwind=pe.Set(initialize=set_nwind)
    model.nbus=pe.Set(initialize=set_nbus)
    # model.nbus.pprint()
    model.nlines=pe.Set(initialize=set_nlines)
    # model.nlines.pprint()
    model.pieces=pe.Set(initialize=set_pieces)
    model.pieces_gen=pe.Set(initialize=set_pieces_gen)
    # model.pieces_gen.pprint()
    model.pieces_lines=pe.Set(initialize=set_pieces_lines)
    # model.pieces_lines.pprint()
#    model.p.pprint()
    model.slopes_gen=pe.Param(model.ngen, model.pieces,initialize=slopes_gen)
    model.intercepts_gen=pe.Param(model.ngen, model.pieces,initialize=intercepts_gen)
    ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=False, doc='Number of samples')
    model.N.pprint()
#    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
#    model.h.pprint()
    
#    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
#    model.b.pprint()
#   
    
    # model.zdata=pe.Param(model.i,model.p,initialize=zdata, doc='Sample data points')
    # model.zdata.pprint()
    model.omegadata=pe.Param(model.i,model.l,initialize=omegadata, mutable=False, doc='Sample data points wind forecast error')
    # model.omegadata.pprint()
    model.Omegadata=pe.Param(model.i, initialize=Omegadata,mutable=False)
    # model.Omegadata.pprint()
    model.zpred=pe.Param(model.p, initialize=zpred)
    # model.zpred.pprint()
  
    # model.mass=pe.Param(initialize=mass)
    # model.mass.pprint()
    model.coste1=pe.Param(model.ngen,initialize=coste1,mutable=False)
    # model.coste1.pprint()
    model.coste2=pe.Param(model.ngen,initialize=coste2,mutable=False)
    # model.coste2.pprint()
    model.coste3=pe.Param(model.ngen,initialize=coste3,mutable=False)
    # model.coste3.pprint()
 
    model.coste_reserv_d=pe.Param(model.ngen,initialize=coste_reserv_d,mutable=False)
    model.coste_reserv_u=pe.Param(model.ngen,initialize=coste_reserv_u,mutable=False)
    model.loads=pe.Param(model.nbus,initialize=loads,mutable=False)
    model.forecasted_wind=pe.Param(model.nwind,initialize=forecasted_wind,mutable=False)
    
    model.liminf_Omega=pe.Param(initialize=liminf_Omega,mutable=False)
    model.limsup_Omega=pe.Param(initialize=limsup_Omega,mutable=False)
    # model.liminf_Omega.pprint()
    # model.limsup_Omega.pprint()
    
    # model.cost_GD=pe.Param(model.ngen, initialize=cost_GD,mutable=False)
    # model.cost_GD.pprint()
    # model.cost_GU=pe.Param(model.ngen, initialize=cost_GU,mutable=False)
    # model.cost_RD=pe.Param(model.ngen, initialize=cost_RD,mutable=False)
    # model.cost_RU=pe.Param(model.ngen, initialize=cost_RU,mutable=False)
    # model.cost_LD=pe.Param(model.nlines, initialize=cost_LD,mutable=False)
    # # model.cost_LD.pprint()
    # model.cost_LU=pe.Param(model.nlines, initialize=cost_LU,mutable=False)
    # model.cost_LU.pprint()
    # model.PTDF=pe.Param(model.nbus,model.nlines,initialize=PTDF,mutable=False)
    # model.PTDF.pprint()
    # model.matrixGbus=pe.Param(model.nbus,model.ngen,  initialize=matrixGbus,mutable=False)
    # model.matrixHbus=pe.Param(model.nbus,model.nwind,  initialize=matrixHbus,mutable=False)
    
    # model.B=pe.Param(model.nwind,model.nwind,  initialize=B,mutable=False)
    # model.matrixHbus.pprint()
#    model.liminf_reserv=pe.Param(model.ngen, initialize=liminf_reserv)
#    model.limsup_reserv=pe.Param(model.ngen, initialize=limsup_reserv)
    model.gmin=pe.Param(model.ngen,initialize=gmin,mutable=False)
    # model.gmin.pprint()
    model.gmax=pe.Param(model.ngen,initialize=gmax,mutable=False)
#    model.rmin=pe.Param(model.ngen,initialize=rmin)
#    model.rmax=pe.Param(model.ngen,initialize=rmax)
    model.capline=pe.Param(model.nlines,initialize=capline,mutable=False)
    
    
    
    # model.size_support=pe.Param(initialize=size_supportset,mutable=False)
    # model.size_support.pprint()
    # model.coste_reserv=pe.Param(model.ngen,initialize=coste_reserv,mutable=False)
#    model.mass.pprint()
#    model.vecsupport=pe.Param(model.l,initialize=vecsupport)
#    model.vecsupport.pprint()
#    model.y0.pprint()
#    model.sigma=pe.Param(initialize=cov)

    ##Define variables##
#    model.x=pe.Var(within=pe.Reals)
    model.lamb=pe.Var(within=pe.NonNegativeReals)
    model.mubarra=pe.Var(model.i,within=pe.NonNegativeReals)
    model.theta=pe.Var(within=pe.Reals)
    
    
#    model.lambda1=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.lambda2=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.mu=pe.Var(model.i, within=pe.Reals)
    model.z=pe.Var(model.i,model.nwind,within=pe.Reals)
    model.beta=pe.Var(model.ngen,within=pe.NonNegativeReals)
    model.g=pe.Var(model.ngen,within=pe.NonNegativeReals)
    
    model.r_D=pe.Var(model.ngen,within=pe.NonNegativeReals)
    model.r_U=pe.Var(model.ngen,within=pe.NonNegativeReals)
#    model.lambda1tilde=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.lambda2tilde=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.mutilde=pe.Var(model.i, within=pe.Reals)
#    
  
    
    model.vtilde=pe.Var(model.i,model.nwind,within=pe.Reals)
    model.v=pe.Var(model.i,model.nwind,within=pe.Reals)
    # model.GtildeD=pe.Var(model.nlines,model.nbus,model.nwind  ,within=pe.Reals )
    # model.GtildeU=pe.Var(model.nlines,model.nbus,model.nwind  ,within=pe.Reals )
#    model.eta=pe.Var(model.l,within=pe.NonNegativeReals)
#    model.etaprima=pe.Var(model.l,within=pe.NonNegativeReals)
    
#    model.vprima=pe.Var(model.i,model.p, within=pe.Reals)
#    model.wprima=pe.Var(model.i, within=pe.Reals)
#    model.w=pe.Var(model.i, within=pe.Reals)
#    model.wtilde=pe.Var(model.i, within=pe.Reals)
#    model.vprimatilde=pe.Var(model.i,model.p, within=pe.Reals)
#    model.wprimatilde=pe.Var(model.i, within=pe.Reals)
    # print("model.zdata[1,2]",model.zdata[1,2])
    ##Define pe.Objective and constrains rules##
    
    model.tt=pe.Var(model.i, model.ngen, within=pe.Reals)
    
    def obj_rule(model): 
        return (1/(model.N))*sum(    sum(model.tt[i,j] +model.coste_reserv_d[j]*(model.r_D[j])+model.coste_reserv_u[j]*(model.r_U[j])  for j in model.ngen)\
                                   for i in model.i)
       

    
        
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()
    # model.con1 = pe.Constraint(model.i,  rule=con_rule_1)
    # # model.con1.pprint()
    # model.con2 = pe.Constraint(model.i,  rule=con_rule_2)
    # model.con3 = pe.Constraint(model.i,  rule=con_rule_3)

    
    
    def con_rule_1(model,i,j,s):
        return model.slopes_gen[j,s]*(model.g[j]-model.beta[j]*model.Omegadata[i])+model.intercepts_gen[j,s]<=model.tt[i,j]
    
    # def con_rule_4b(model,i,j):
    #     return -model.z[i,j]<=model.lamb
        
    # def con_rule_5(model,i,j):
    #     return model.vtilde[i,j]>=(model.v[i,j] )
    # def con_rule_5b(model,i,j):
    #     return model.vtilde[i,j]>=-(model.v[i,j])
    
    model.con1= pe.Constraint(model.i,model.ngen,model.pieces, rule=con_rule_1)
    # model.con4b = pe.Constraint(model.i,model.nwind, rule=con_rule_4b)
    
    # model.con5 = pe.Constraint(model.i,model.nwind, rule=con_rule_5)
    # model.con5b = pe.Constraint(model.i,model.nwind, rule=con_rule_5b)
    
    
    
    # def con_rule_5c(model,i,j):
    #     return model.z[i,j]-model.v[i,j]==-(sum(model.cost_GD[m]*model.y_GD[m,j]+model.cost_GU[m]*model.y_GU[m,j]+model.cost_RD[m]*model.y_RD[m,j]+model.cost_RU[m]*model.y_RU[m,j] for m in model.ngen)+sum(model.cost_LD[l]*model.y_LD[l,j]+model.cost_LU[l]*model.y_LU[l,j] for l in model.nlines))
    
    # model.con5c= pe.Constraint(model.i,model.nwind, rule=con_rule_5c)
    
    
    
    model.tauGD=pe.Var( within=pe.Reals)

    
    model.epsGD=pe.Param( initialize=epsGD)
    model.epsGD.pprint()
    model.sGD=pe.Var(model.i,within=pe.NonNegativeReals)
    
    def con_rule_6(model):
        return model.tauGD+1/(model.epsGD)*((1/(model.N))*sum(model.sGD[i]   for i in model.i))<=0
    def con_rule_6b(model,i,j):
        return model.gmin[j]-model.g[j]+model.beta[j]*sum(model.omegadata[i,m] for m in model.nwind)-model.tauGD<=model.sGD[i]

    
    model.con6 = pe.Constraint( rule=con_rule_6)
    model.con6b = pe.Constraint(model.i, model.ngen,rule=con_rule_6b)
    
    
    
    
    
    # model.tauGU=pe.Var( within=pe.Reals)

    
    # model.epsGU=pe.Param( initialize=epsGU)
    
    # model.sGU=pe.Var(model.i,within=pe.NonNegativeReals)
    
   
    
   
    
    # def con_rule_7(model):
    #     return  model.tauGU+(1/((model.N)*(model.epsGU)))*sum( model.sGU[i] for i in model.i)       <=0
    def con_rule_7b(model,i,j):
        return model.g[j]-model.gmax[j]-model.beta[j]*sum(model.omegadata[i,m] for m in model.nwind)-model.tauGD<=model.sGD[i]

    
    
    

    
    
    # model.con7 = pe.Constraint( rule=con_rule_7)
    model.con7b = pe.Constraint(model.i,model.ngen, rule=con_rule_7b)
    
    
    
    
    # model.tauRD=pe.Var(within=pe.Reals)

    
    # model.epsRD=pe.Param( initialize=epsRD)
    
    # model.sRD=pe.Var(model.i,within=pe.NonNegativeReals)
    
    # def con_rule_8(model):
    #     return model.tauRD+(1/((model.N)*(model.epsRD)))*sum( model.sRD[i] for i in model.i)       <=0
    
    def con_rule_8b(model,i,j):
        return -model.r_D[j]+model.beta[j]*sum(model.omegadata[i,m] for m in model.nwind)-model.tauGD<=model.sGD[i]

    
    # model.con8 = pe.Constraint( rule=con_rule_8)
    model.con8b = pe.Constraint(model.i, model.ngen,rule=con_rule_8b)
    
    # model.tauRU=pe.Var( within=pe.Reals)

    
    # model.epsRU=pe.Param( initialize=epsRU)
    
    # model.sRU=pe.Var(model.i,within=pe.NonNegativeReals)
    
   
    
   
    
    # def con_rule_9(model):
    #     return  model.tauRU+(1/((model.N)*(model.epsRU)))*sum( model.sRU[i] for i in model.i)       <=0
    def con_rule_9b(model,i,j):
        return -model.r_U[j]-model.beta[j]*sum(model.omegadata[i,m] for m in model.nwind)-model.tauGD<=model.sGD[i]

    
    
    

    
    
    # model.con9 = pe.Constraint( rule=con_rule_9)
    model.con9b = pe.Constraint(model.i,model.ngen, rule=con_rule_9b)
    
    
    
    
    # model.tauLD=pe.Var( within=pe.Reals)

    
    # model.epsLD=pe.Param( initialize=epsLD)
    
    # model.sLD=pe.Var(model.i,within=pe.NonNegativeReals)
    
    # def con_rule_10(model,l):
    #     return model.tauLD+(1/((model.N)*(model.epsLD)))*sum( model.sLD[i] for i in model.i)       <=0
    
    # gen_6node=pd.read_csv("gen_6node.csv", header=None)
    
    index_genbus=array_to_dict((gen_6node.iloc[1:Ngen+2,1]).values.astype(int))
    
    index_busgen={key: {} for key in set_nbus}
    for jj in set_nbus:
        index_busgen[jj]=list([k for k,v in index_genbus.items() if v==jj])
        
    
    index_windbus=array_to_dict((wind_6node.iloc[1:Nwind+2,1]).values.astype(int))
    
    index_buswind={key: {} for key in set_nbus}
    for jj in set_nbus:
        index_buswind[jj]=list([k for k,v in index_windbus.items() if v==jj])
    
    
    
    def con_rule_10b(model,i,l):
        
        return -model.capline[l]-sum(PTDF[b,l]*(sum(model.g[m]-model.beta[m]*sum(model.omegadata[i,mm] for mm in model.nwind) for m in index_busgen[b])+sum(model.forecasted_wind[m]+model.omegadata[i,m] for m in index_buswind[b])-model.loads[b]) for b in  model.nbus)-model.tauGD<=model.sGD[i]

            
    # model.con10 = pe.Constraint( rule=con_rule_10)
    model.con10b = pe.Constraint(model.i,model.nlines, rule=con_rule_10b)
    # model.con10b.pprint()
    # model.tauLU=pe.Var( within=pe.Reals)

    
    # model.epsLU=pe.Param( initialize=epsLU)
    
    # model.sLU=pe.Var(model.i,within=pe.NonNegativeReals)
    
   
    
   
    
    # def con_rule_11(model):
    #     return  model.tauLU+(1/((model.N)*(model.epsLU)))*sum( model.sLU[i] for i in model.i)       <=0
    def con_rule_11b(model,i,l):
        return -model.capline[l]+sum(PTDF[b,l]*(sum(model.g[m]-model.beta[m]*sum(model.omegadata[i,mm] for mm in model.nwind) for m in index_busgen[b])+sum(model.forecasted_wind[m]+model.omegadata[i,m] for m in index_buswind[b])-model.loads[b]) for b in  model.nbus)-model.tauGD<=model.sGD[i]

    
    
    
    

    
    
    # model.con11 = pe.Constraint( rule=con_rule_11)
    model.con11b = pe.Constraint(model.i,model.nlines, rule=con_rule_11b)
    
    
    
    
    
    
    
    
    
    
   

    
    def con_rule_balance(model):
        return sum(model.g[m] for m in model.ngen)==sum(model.loads[b] for b in model.nbus)-sum(model.forecasted_wind[j] for j in model.nwind)
    def con_part(model):
        return sum(model.beta[j] for j in model.ngen)==1
    model.con_rule_balance=pe.Constraint(rule=con_rule_balance)
  
    model.con_part=pe.Constraint(rule=con_part)
    
    def con_rule_32(model,j):
        return model.g[j]+model.r_U[j]<=model.gmax[j]
    def con_rule_32b(model,j):
        return model.g[j]-model.r_D[j]>=0
    # def con_rule_33(model,j):
    #     return model.r_U[j]<=model.gmax[j]
    # def con_rule_33b(model,j):
    #     return model.r_U[j]>=model.gmin[j]
    # model.con32 = pe.Constraint(model.ngen, rule=con_rule_32)
    # model.con32b = pe.Constraint(model.ngen, rule=con_rule_32b)
    
    
    


 
    
    

    
   
    
    

    


    return model

def real_dispatch_piecewise_mixed_cplex(m,index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_MATRIX,PTDF_gen,PTDF_wind,capline):
    
    
    set_i=set_knn_real
    tt=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf'))
    loadshed=m.continuous_var_dict(list(product(set_i,set_nbus)),lb=0)
    windspill=m.continuous_var_dict(list(product(set_i,set_nwind)),lb=0)
    reservas=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf'))
    # model.loadshed=pe.Var(model.i,model.nbus, within=pe.NonNegativeReals)
    # model.windspill=pe.Var(model.i,model.nwind,within=pe.NonNegativeReals)
    # model.reservas=pe.Var(model.i,model.ngen,within=pe.Reals)
     # r_D=m.addVars(list(set_ngen),name='r_D',lb=0)
     # r_U=m.addVars(list(set_ngen),name='r_U',lb=0)
     
    g=array_to_dict(dfgen)
    r_D=array_to_dict(dfr_D)
    r_U=array_to_dict(dfr_U)

    # tdata=m.addVars(list(product(set_i,set_ngen)),name='tt',lb=-float('inf'))  

    
    
     # (1/len(model.i))*sum( sum(tt[i,j]  for j in set_ngen)+sum(500*loadshed[i,b] for b in set_nbus) for i in set_i)+sum(coste_reserv_d[j]*(r_D[j])+coste_reserv_u[j]*(r_U[j])  for j in set_ngen)
    m.minimize( (1/len(set_i))*sum( sum(tt[i,j]  for j in set_ngen)+sum(500*loadshed[i,b] for b in set_nbus) for i in set_i)+sum(coste_reserv_d[j]*(r_D[j])+coste_reserv_u[j]*(r_U[j])  for j in set_ngen)  )


    # c1=m.addConstrs((  tt[i,j]>=sum(tdata[i,j] for j in set_ngen) for i in set_i   ))
    # model.slopes_gen[j,s]*(model.g[j]+model.reservas[i,j])+model.intercepts_gen[j,s]<=model.tt[i,j]
    c1=m.add_constraints((  tt[i,j]>=slopes_gen[j,s]*(g[j]+reservas[i,j])+intercepts_gen[j,s] for i in set_i for j in set_ngen for s in set_pieces ))
     

    # c3=m.addConstrs((  gmin[j]-(g[j]-beta[j]*sum(ydataknnproj_dict[i,l] for l in set_nwind))<=0 for i in set_i for j in set_ngen  ))

               
     # c4=m.addConstrs((  g[j]-beta[j]*sum(ydataknnproj_dict[i,l] for l in set_nwind)<=gmax[j] for i in set_i for j in set_ngen   ))

           
    c2=m.add_constraints((  reservas[i,j]>=-r_D[j] for i in set_i for j in set_ngen  ))

               
    c3=m.add_constraints((  reservas[i,j]<=r_U[j] for i in set_i for j in set_ngen   ))              
           
    
    
    c4=m.add_constraints((  windspill[i,mm]<=forecasted_wind[mm]+ydataknnreal[i-1] for i in set_i for mm in set_nwind   ))
     
    c5=m.add_constraints((  loadshed[i,b]<=load[b] for i in set_i for b in set_nbus   ))
    
    
    
    
    
    PTDF_gen=PTDF_MATRIX.transpose() @ (array_matrixGbus)
    PTDF_wind=PTDF_MATRIX.transpose() @ (array_matrixHbus)
    


    lin_gen=[sum([ (PTDF_gen[k-1,j-1])*g[j] for j in set_ngen]) for k in set_nlines]        
    lin_load=[sum([ (PTDF_MATRIX[b-1,k-1])*(-load[b]) for b in set_nbus] ) for k in set_nlines]
            
    # lin_wind=[sum([ (PTDF_wind[k-1,mm-1]*(forecasted_wind[mm]+ydataknnreal[i-1])) for mm in set_nwind]) for k in set_nlines]
    
     # PTDF_wind=PTDF_MATRIX.transpose() @ (array_matrixHbus)
     # gp.LinExpr([ (PTDF_MATRIX[b,k],-load[b]) for b in set_nbus])
     # gp.LinExpr([ (PTDF_gen[k,j],beta[j]*sum(omegadata[i,l] for l in set_nwind)) for j in set_ngen])      
     # c7=m.addConstrs((   -capline[k]-(sum(PTDF_dict[index_genbus[j],k]*(g[j]-beta[j]*sum(omegadata[i,l] for l in set_nwind)   ) for j in set_ngen)+sum(PTDF_dict[index_windbus[mm],k]*(forecasted_wind[mm]+omegadata[i,mm]   ) for mm in set_nwind)+sum(PTDF_dict[b,k]*(-load[b]) for b in  set_nbus))<=0 for i in set_i for k in set_nlines   ))              
    c7=m.add_constraints((  -capline[k]-( lin_gen[k-1]+m.sum( PTDF_gen[k-1,j-1]*reservas[i,j] for j in set_ngen)     +
                                     +sum([ (PTDF_wind[k-1,mm-1]*(forecasted_wind[mm]+ydataknnreal[i-1])) for mm in set_nwind])-m.sum( PTDF_wind[k-1,m-1]*windspill[i,m] for m in set_nwind) +lin_load[k-1]+m.sum( (PTDF_MATRIX[b-1,k-1])*loadshed[i,b] for b in set_nbus) )   <=0 for i in set_i for k in set_nlines   ))              
    c8=m.add_constraints((  ( lin_gen[k-1]+m.sum( PTDF_gen[k-1,j-1]*reservas[i,j] for j in set_ngen)     +
                                     +sum([ (PTDF_wind[k-1,mm-1]*(forecasted_wind[mm]+ydataknnreal[i-1])) for mm in set_nwind])-m.sum( PTDF_wind[k-1,m-1]*windspill[i,m] for m in set_nwind) +lin_load[k-1]+m.sum((PTDF_MATRIX[b-1,k-1])*loadshed[i,b] for b in set_nbus) )   <=capline[k] for i in set_i for k in set_nlines   ))        
     # c7=m.addConstrs(( -capline[k]-( gp.LinExpr([ (PTDF_gen[k,j],g[j]) for g in set_ngen])-(PTDF_gen[k,j],beta[j]*sum(omegadata[i,l] for l in set_nwind)) for g in set_ngen] +gp.LinExpr([ (PTDF_wind[k,mm],forecasted_wind[mm]+omegadata[i,mm]) for mm in set_nwind])+gp.LinExpr([ (PTDF_wind[k,mm],forecasted_wind[mm]+omegadata[i,mm]) for mm in set_nwind]) +gp.LinExpr([ (PTDF_MATRIX[b,k],-load[b]) for b in set_nbus]) )   <=0 for i in set_i for k in set_nlines ))
     # c8=m.addConstrs((   (sum(PTDF_dict[index_genbus[j],k]*(g[j]-beta[j]*sum(omegadata[i,l] for l in set_nwind)   ) for j in set_ngen)+sum(PTDF_dict[index_windbus[mm],k]*(forecasted_wind[mm]+omegadata[i,mm]   ) for mm in set_nwind)+sum(PTDF_dict[b,k]*(-load[b]) for b in  set_nbus))<=capline[k] for i in set_i for k in set_nlines   ))              
     # c8=m.addConstrs((  ( gp.LinExpr([ (PTDF_gen[k-1,j-1],g[j]) for j in set_ngen])-sum(ydataknnproj_dict[i,l] for l in set_nwind)*gp.LinExpr([ (PTDF_gen[k-1,j-1],beta[j]) for j in set_ngen])     +
     #                                 +sum([ (PTDF_wind[k-1,mm-1]*(forecasted_wind[mm]+ydataknnproj_dict[i,mm])) for mm in set_nwind]) +sum([ (PTDF_MATRIX[b-1,k-1])*(-load[b]) for b in set_nbus] ) )   <=capline[k] for i in set_i for k in set_nlines   ))              

           # return sum(model.reservas[i,j] for j in model.ngen)+sum(model.loadshed[i,b] for b in model.nbus)+sum(model.omega_dispatch[i,m]-model.windspill[i,m] for m in model.nwind)==0

  
    c9=m.add_constraints(( sum(reservas[i,j] for j in set_ngen)+sum(loadshed[i,b] for b in set_nbus)+sum(ydataknnreal[i-1]-windspill[i,m] for m in set_nwind)==0 for i in set_i   ))     
           
           


    return m
    
 ##Define Abstract model##
    model = pe.ConcreteModel(name='mdc opf two stage, unc. set norma infinito de radio W')
    
    ##Define sets##
    
    model.i=pe.Set(initialize=set_i)
    # model.i.pprint()
    model.p=pe.Set(initialize=set_p) #dim z
    # model.p.pprint()
    model.l=pe.Set(initialize=set_l) #dim omega
    
    model.ngen=pe.Set(initialize=set_ngen)
    # model.ngen.pprint()
    model.nwind=pe.Set(initialize=set_nwind)
    model.nbus=pe.Set(initialize=set_nbus)
    # model.nbus.pprint()
    model.nlines=pe.Set(initialize=set_nlines)
    # model.nlines.pprint()
    
#    model.p.pprint()
    model.pieces=pe.Set(initialize=set_pieces)
    model.slopes_gen=pe.Param(model.ngen, model.pieces,initialize=slopes_gen)
    model.intercepts_gen=pe.Param(model.ngen, model.pieces,initialize=intercepts_gen)
        ##Define parameters##
    model.N=pe.Param(initialize=Nsamples,mutable=False, doc='Number of samples')
    # model.N.pprint()
    # print("len(model.i)",len(model.i))
#    model.h=pe.Param(initialize=holding_cost,mutable=False,doc='Cost of overproduction')
#    model.h.pprint()
    
#    model.b=pe.Param(initialize=backorder_cost,mutable=False,doc='Cost of under production')
#    model.b.pprint()
#   
    
    # model.zdata=pe.Param(model.i,model.p,initialize=zdata, doc='Sample data points')
    # model.zdata.pprint()
    # model.omegadata=pe.Param(model.i,model.l,initialize=omegadata, mutable=False, doc='Sample data points wind forecast error')
    # model.Omegadata=pe.Param(model.i, initialize=Omegadata,mutable=False)
    # model.Omegadata.pprint()
    # model.zpred=pe.Param(model.p, initialize=zpred)
    # model.zpred.pprint()
  
    # model.mass=pe.Param(initialize=mass)
    # model.mass.pprint()
    model.coste1=pe.Param(model.ngen,initialize=coste1,mutable=False)
    # model.coste1.pprint()
    model.coste2=pe.Param(model.ngen,initialize=coste2,mutable=False)
    # model.coste2.pprint()
    model.coste3=pe.Param(model.ngen,initialize=coste3,mutable=False)
    # model.coste3.pprint()
 
    model.coste_reserv_d=pe.Param(model.ngen,initialize=coste_reserv_d,mutable=False)
    model.coste_reserv_u=pe.Param(model.ngen,initialize=coste_reserv_u,mutable=False)
    model.loads=pe.Param(model.nbus,initialize=loads,mutable=False)
    model.forecasted_wind=pe.Param(model.nwind,initialize=forecasted_wind,mutable=False)
    
    # model.liminf_Omega=pe.Param(initialize=liminf_Omega,mutable=False)
    # model.limsup_Omega=pe.Param(initialize=limsup_Omega,mutable=False)
    # model.liminf_Omega.pprint()
    # model.limsup_Omega.pprint()
    
    # model.cost_GD=pe.Param(model.ngen, initialize=cost_GD,mutable=False)
    # model.cost_GD.pprint()
    # model.cost_GU=pe.Param(model.ngen, initialize=cost_GU,mutable=False)
    # model.cost_RD=pe.Param(model.ngen, initialize=cost_RD,mutable=False)
    # model.cost_RU=pe.Param(model.ngen, initialize=cost_RU,mutable=False)
    # model.cost_LD=pe.Param(model.nlines, initialize=cost_LD,mutable=False)
    # # model.cost_LD.pprint()
    # model.cost_LU=pe.Param(model.nlines, initialize=cost_LU,mutable=False)
    # model.cost_LU.pprint()
    # PTDF=pe.Param(model.nbus,model.nlines,initialize=PTDF,mutable=False)
    # model.PTDF.pprint()
    # model.matrixGbus=pe.Param(model.nbus,model.ngen,  initialize=matrixGbus,mutable=False)
    # model.matrixHbus=pe.Param(model.nbus,model.nwind,  initialize=matrixHbus,mutable=False)
    
    # model.B=pe.Param(model.nwind,model.nwind,  initialize=B,mutable=False)
    # model.matrixHbus.pprint()
#    model.liminf_reserv=pe.Param(model.ngen, initialize=liminf_reserv)
#    model.limsup_reserv=pe.Param(model.ngen, initialize=limsup_reserv)
    model.gmin=pe.Param(model.ngen,initialize=gmin,mutable=False)
    # model.gmin.pprint()
    model.gmax=pe.Param(model.ngen,initialize=gmax,mutable=False)
#    model.rmin=pe.Param(model.ngen,initialize=rmin)
#    model.rmax=pe.Param(model.ngen,initialize=rmax)
    model.capline=pe.Param(model.nlines,initialize=capline,mutable=False)
    
    
    

    
    model.r_D=pe.Param(model.ngen,initialize=r_D)
    model.r_U=pe.Param(model.ngen,initialize=r_U)
#    model.lambda1tilde=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.lambda2tilde=pe.Var(model.i,within=pe.NonNegativeReals)
#    model.mutilde=pe.Var(model.i, within=pe.Reals)
#    
  
    
    # model.vtilde=pe.Var(model.i,model.nwind,within=pe.Reals)
    # model.v=pe.Var(model.i,model.nwind,within=pe.Reals)
    
    
    
    model.loadshed=pe.Var(model.i,model.nbus, within=pe.NonNegativeReals)
    model.windspill=pe.Var(model.i,model.nwind,within=pe.NonNegativeReals)
    model.reservas=pe.Var(model.i,model.ngen,within=pe.Reals)
    
    
    model.omega_dispatch=pe.Param(model.i,model.nwind,initialize=omega_dispatch,mutable=False)
    # model.omega_dispatch.pprint()
    # model.costshed=pe.Param(initialize=omega_dispatch)
    model.g=pe.Param(model.ngen,initialize=gensol)
    # model.g.pprint()
    model.tt=pe.Var(model.i,model.ngen,   within=pe.Reals)
    def obj_rule(model): 
        return  (1/len(model.i))*sum( sum(model.tt[i,j]  for j in model.ngen)+sum(500*model.loadshed[i,b] for b in model.nbus) for i in model.i)
                                  
       

    
        
    model.obj = pe.Objective(rule=obj_rule, sense=pe.minimize)
#    model.obj.pprint()

    def con_rule_1(model,i,j,s):
        return model.slopes_gen[j,s]*(model.g[j]+model.reservas[i,j])+model.intercepts_gen[j,s]<=model.tt[i,j]
    model.con1 = pe.Constraint(model.i,model.ngen, model.pieces,  rule=con_rule_1)
    # model.con1.pprint()



    def con_rule_7b(model,i,b):
        return model.loadshed[i,b]<=model.loads[b]
    
    model.con7b = pe.Constraint(model.i,model.nbus,rule=con_rule_7b)

    def con_rule_8(model,i,j):
        return -model.r_D[j]<=model.reservas[i,j]
    
    def con_rule_8b(model,i,j):
        return model.reservas[i,j]<=model.r_U[j]
    
    model.con8 = pe.Constraint(model.i,model.ngen, rule=con_rule_8)
    model.con8b = pe.Constraint(model.i,model.ngen,rule=con_rule_8b)
    
   
    
    def con_rule_9(model,i,m):
        return  model.windspill[i,m] <=model.forecasted_wind[m]+model.omega_dispatch[i,m]
 

    
    
    model.con9 = pe.Constraint(model.i,model.nwind, rule=con_rule_9)
    # model.con9.pprint()
    
    
    
    
    # index_genbus=array_to_dict((gen_6node.iloc[1:Ngen+2,1]).values.astype(int))
    
    # index_busgen={key: {} for key in set_nbus}
    # for jj in set_nbus:
    #     index_busgen[jj]=list([k for k,v in index_genbus.items() if v==jj])
        
    
    # index_windbus=array_to_dict((wind_6node.iloc[1:Nwind+2,1]).values.astype(int))
    
    # index_buswind={key: {} for key in set_nbus}
    # for jj in set_nbus:
    #     index_buswind[jj]=list([k for k,v in index_windbus.items() if v==jj])
    
    


    
    
    
    
   
    def con_rule_10(model,i,l):
        return -model.capline[l]-sum(PTDF[b,l]*(sum((model.g[m] +model.reservas[i,m] )for m in index_busgen[b])+sum((model.forecasted_wind[m]+model.omega_dispatch[i,m]- model.windspill[i,m]) for m in index_buswind[b])+(-model.loads[b]+model.loadshed[i,b])) for b in  model.nbus)<=0

    def con_rule_10b(model,i,l):
        return sum(PTDF[b,l]*(sum((model.g[m] +model.reservas[i,m] )for m in index_busgen[b])+sum((model.forecasted_wind[m]+model.omega_dispatch[i,m]- model.windspill[i,m]) for m in index_buswind[b])+(-model.loads[b]+model.loadshed[i,b])) for b in  model.nbus)-model.capline[l]<=0
    
    
    
    

    
    
    model.con10 = pe.Constraint(model.i, model.nlines, rule=con_rule_10)
    # model.con10.pprint()
    model.con10b = pe.Constraint(model.i,model.nlines, rule=con_rule_10b)
    
    
    
    
    
    
    
    
    
    
   

    
    def con_rule_balance(model,i):
        return sum(model.reservas[i,j] for j in model.ngen)+sum(model.loadshed[i,b] for b in model.nbus)+sum(model.omega_dispatch[i,m]-model.windspill[i,m] for m in model.nwind)==0




    # def con_rule_balance(i,model):
    #     return sum(model.loadshed[i,b] for b in model.nbus)+sum(model.omega_dispatch[i,m]-model.windspill[i,m] for m in model.nwind)==0

    model.con_rule_balance=pe.Constraint(model.i,rule=con_rule_balance)
  
    # model.con_part=pe.Constraint(rule=con_part)
    
    # def con_rule_32(model,j):

    
    
    


 
    
    

    
   
    
    

    


    return model




    
    

    


    suma=0
    # print("betasol",betasol)
    # # print("gen",gen)
    # print("coste1",coste1)
    # print("coste2",coste2)
    # print("coste3",coste3)
    # print(Omegadatareal)
    # Ndatos=len(Omegadataknndroboot)
    # print("Ndatos",Ndatos)
    # print("set_ngen",list(set_ngen))
    
    # opt = SolverFactory('cplex')
    # opt.options['NonConvex']=2
    # opt.options['Threads']=1
    # opt.options['Methods']=1
    # opt.options['lpmethod']=4
    # from supress_log_file import custom_solver_factory

    # opt = custom_solver_factory('cplex_direct', options={'lpmethod':4,'preprocessing_dual':1})

    opt=SolverFactory('cplex')
    opt.options['preprocessing_dual']=1
    opt.options['lpmethod']=4
    no_creado=True
    omega_dispatch=omegadata
    dfgen.to_dict()['g']
    gensol=dfgen.to_dict()['g']
    # print("gensol DATO",gensol)
    r_D=dfr_D.to_dict()['r_D']
    # print("r_D DATI",r_D)
    r_U=dfr_U.to_dict()['r_U']
    # print("omega dispatch",omega_dispatch)
    # print("set_i",set_i)
    modelo_dispatch=real_dispatch_piecewise(gen_6node,wind_6node,set_pieces,slopes_gen,intercepts_gen,set_i,set_l,set_p, set_ngen,set_nwind,set_nbus,set_nlines,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,loads, forecasted_wind,omega_dispatch,gensol,r_D,r_U,gmin,gmax,PTDF,capline)



    # results = opt.solve(modelo_dispatch,logfile=False)
    results = opt.solve(modelo_dispatch)

    # for i in range(Ndatos):
    #     # print("i",i)
    #     # print("omegadata[i]",omegadata[i][:])
    #     omega_dispatch[i]=array_to_dict(omegadata[i][:])
    #     # print("omega_dispatch",omega_dispatch)
    #     if no_creado:
    #         # print("creo el modelo")
            
    #         # print("r_U DATI",r_U)
    #         modelo_dispatch=real_dispatch_piecewise(set_pieces,slopes_gen,intercepts_gen,set_i,set_l,set_p, set_ngen,set_nwind,set_nbus,set_nlines,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,loads, forecasted_wind,omega_dispatch,gensol,r_D,r_U, liminf_Omega,limsup_Omega,cost_GD,cost_GU,cost_RD,cost_RU,cost_LD,cost_LU,matrixGbus,matrixHbus,size_supportset,gmin,gmax,PTDF,capline,B)
    #         no_creado=False

   
    #         # modelo_dispatch.pprint()
    #         results = opt.solve(modelo_dispatch,tee=False)

    
    #         # print("valor objetivo, punto i",float(modelo_dispatch.obj.expr()))
    #         suma=suma+float(modelo_dispatch.obj.expr())
    #     else:
    #         # print("modelo ya creado")
    #         for j in set_nwind:
    #             modelo_dispatch.omega_dispatch[j]=omega_dispatch[j]
            
    #         # modelo_dispatch.pprint()
    #         results = opt.solve(modelo_dispatch,tee=False)
    #         # print("valor objetivo, punto i",float(modelo_dispatch.obj.expr()))
    #         suma=suma+float(modelo_dispatch.obj.expr())
            
    
    


    # print("suma")
    # coste=suma/Ndatos+  sum(coste2[j]*((dfgen.values[j-1])[0])+coste3[j] +coste_reserv_d[j]*((dfr_D.values[j-1])[0])+coste_reserv_u[j]*((dfr_U.values[j-1])[0]) for j in set_ngen)
    # print("coste 1 etapa",sum(max([slopes_gen[j,s]*((dfgen.values[j-1])[0])+intercepts_gen[j,s] for s in set_pieces]) +coste_reserv_d[j]*((dfr_D.values[j-1])[0])+coste_reserv_u[j]*((dfr_U.values[j-1])[0]) for j in set_ngen))
    print("coste DESPACHO REAL",float(modelo_dispatch.obj.expr()))
    print("coste reservas", sum( coste_reserv_d[j]*((dfr_D.values[j-1])[0])+coste_reserv_u[j]*((dfr_U.values[j-1])[0]) for j in set_ngen))
    coste=float(modelo_dispatch.obj.expr())+  sum( coste_reserv_d[j]*((dfr_D.values[j-1])[0])+coste_reserv_u[j]*((dfr_U.values[j-1])[0]) for j in set_ngen)

    return coste

# n_mixt_real =10000
#


#cov_cond=np.eye(6)
#matriz_cond_product=np.dot(matriz_cond_raiz,matriz_cond_raiz)

# zprediccion_feature={}
# zprediccion_feature[1]=(1000-1000)/50
# zprediccion_feature[2]=(0.01-0.02)/0.01
# zprediccion_feature[3]=(5-math.exp(1/2))/(math.sqrt((math.exp(1)-1)*math.exp(1)))


from scipy import stats
from scipy.stats import multivariate_normal
#calculo el soporte de la distribucion par el modelo de kuhn
num_features=1
# num_dy=6
set_dz=range(1,num_features+1)
# set_dy=range(1,num_dy +1)
# set_dx=set_dy
set_k=range(1,1+1)
# 



#cov_cond=np.power(matriz_cond_raiz,2)
#cov_cond=matrix_power(matriz_cond_raiz,2)
# cov_cond=np.dot(matriz_cond_raiz,matriz_cond_raiz)


#muestra_dist_real=muestra_real_cond(n_mixt_real,mean_cond,cov_cond)

#np.savetxt("muestra_dist_real.csv", muestra_dist_real, delimiter=",")

#muestra_dist_real=[]
#with open('muestra_dist_real.csv', newline='') as File:  
#    reader = csv.reader(File)
#    for row in reader:
#        muestra_dist_real.append(np.array(list(map(float,row))))
#muestra_dist_real=np.asarray(muestra_dist_real)

#


#GENERACION DE DATOS

# df=(pd.read_csv("dataset_wind_europe_2015_2019.csv", usecols = ['DK1_won_da','SE3_won_da'],)).dropna(how='any',axis=0)
# df=df[(df[df.columns] > 0).all(axis=1)]
# # df['DK1_won_da'].interpolate(method='polynomial', order=1)
# # df['SE3_won_da'].interpolate(method='polynomial', order=1)
# times_muestra_conjunta=df.shape[0]
# # times_muestra_conjunta=30000
# # df2=(df[0:times_muestra_conjunta])
# df2=df
# max_valuew1 = df2["DK1_won_da"].max()
# max_valuew2 = df2["SE3_won_da"].max()

# df2=df2.values #ya es un array


# df2[:,0] =(1/max_valuew1 )*df2[:,0]
# df2[:,1] =(1/max_valuew2 )*df2[:,1]

# maxgen_nwind1=70
# maxgen_nwind2=100

# # df2[:,0] =(maxgen_nwind1)*df2[:,0]
# # df2[:,1] =(maxgen_nwind2 )*df2[:,1]




# #### GENERO LOS 30000 PUNTOS DE MI SOPORTE

# size_supportset=3.5

# times_muestra_conjunta=25000
# muestra_real_conjunta=[]


# forecasted_wind=array_to_dict([5,20])

# ####creo la muestra conjunta

# zdata1=df2[:,0]
# zdata2=df2[:,1]
# len_muestraconjunta=0
# j=0


# cov=np.array([[10.92603, -0.02779],
#        [-0.02779,  8.53901]])
# # mean_w1=np.mean(omegadataconjunta[:,0])
# # mean_w2=np.mean(omegadataconjunta[:,1])
# # mean_w=np.mean(omegadataconjunta, axis=0)
# mcholesky=linalg.cholesky(inv(np.matrix(np.asarray(cov))))    
# mcholesky=np.array([[0.30253 , 0.00098],
#        [0.        , 0.34221]])
                   
# while len(muestra_real_conjunta)<times_muestra_conjunta:
#     vector_muestra=[]
    
#     # print("j",j)

    
#     sigma2_w1=(0.21*zdata1[j]+0.016)**2   #predicion de 24 horas
#     sigma2_w2=(0.21*zdata2[j]+0.016)**2   #predicion de 24 horas
    
    
#     alpha_w1=((1-zdata1[j])*(zdata1[j])**2)/(sigma2_w1)-zdata1[j]
    
   
#     beta_w1=(zdata1[j]*(1-zdata1[j])**2)/(sigma2_w1)+zdata1[j]-1
    
#     alpha_w2=((1-zdata2[j])*(zdata2[j])**2)/(sigma2_w2)-zdata2[j]
#     beta_w2=(zdata2[j]*(1-zdata2[j])**2)/(sigma2_w2)+zdata2[j]-1
    
#     if alpha_w1>=0 and beta_w1>=0 and alpha_w2>=0 and beta_w2>=0 :
#         print("alpah bien")
#         omega1=maxgen_nwind1*(np.random.beta(alpha_w1,beta_w1) -zdata1[j]  )
#         omega2=maxgen_nwind2*(np.random.beta(alpha_w2,beta_w2) -zdata2[j]  )
    
#         Omega=omega1+omega2
    
    
#         # vector_muestra.append(zdata1[j]*maxgen_nwind1)
#         # vector_muestra.append(zdata2[j]*maxgen_nwind2)
#         # vector_muestra.append(omega1)
#         # vector_muestra.append(omega2)
#         # vector_muestra.append(Omega)
#         # print("forecasted_wind[1]+omega1",forecasted_wind[1]+omega1)
#         # if forecasted_wind[1]+omega1<=maxgen_nwind1:
#         #     print("omega1 bien")
    
    
        
#         if np.linalg.norm(np.dot(mcholesky,np.array([omega1,omega2])), ord=1)<=size_supportset and forecasted_wind[1]+omega1<=maxgen_nwind1 and forecasted_wind[1]+omega1>=0 and forecasted_wind[2]+omega2<=maxgen_nwind2 and forecasted_wind[2]+omega2>=0:
#             vector_muestra.append(zdata1[j]*maxgen_nwind1)
#             vector_muestra.append(zdata2[j]*maxgen_nwind2)
#             vector_muestra.append(omega1)
#             vector_muestra.append(omega2)
#             vector_muestra.append(Omega)
#             muestra_real_conjunta.append(vector_muestra)
#             len_muestraconjunta=len_muestraconjunta+1
#             print("len_muestraconjunta",len_muestraconjunta)
    
#     j=j+1
    # print("MUESTRA[i]  ",muestra[i])    

# np.savetxt("muestra_real_conjunta.csv", muestra_real_conjunta_def, delimiter=",")
# muestra_real_conjunta=[]
# with open("muestra_real_conjunta.csv", newline='') as File:
#     reader = csv.reader(File)
#     for row in reader:
#         muestra_real_conjunta.append(np.array(list(map(float,row))))

# muestra_real_conjunta=np.asarray(muestra_real_conjunta)




# cov= np.cov(omegadataconjunta.transpose())


# for j in range(35000):
#     if np.linalg.norm(np.dot(mcholesky,omegadataconjunta[j,:]), ord=1)<=3.5 and len(muestra_real_conjunta_def)<30000:
#         muestra_real_conjunta_def.append(muestra_real_conjunta[j,:] )
        
    

    
    




# np.savetxt("muestra_real_conjunta.csv", muestra_real_conjunta, delimiter=",")

# muestra_real_conjunta=[]
# with open("muestra_real_conjunta.csv", newline='') as File:
#     reader = csv.reader(File)
#     for row in reader:
#         muestra_real_conjunta.append(np.array(list(map(float,row))))

# muestra_real_conjunta=np.asarray(muestra_real_conjunta)
###############################################################################################

# muestra_real_conjunta=pd.read_csv("muestra_real_conjunta.csv", header=None).values


# zdataconjunta=muestra_real_conjunta[:,[0,1]]
# ydataconjunta=muestra_real_conjunta[:,[2,3,4]]
# omegadataconjunta=muestra_real_conjunta[:,[2,3]]

# Omegadataconjunta=muestra_real_conjunta[:,[4]]

# # df=(pd.read_csv("dataset_wind_europe_2015_2019.csv", usecols = ['DK1_won_da','SE3_won_da'],)).dropna(how='any',axis=0)
# # df=df[(df[df.columns] > 0).all(axis=1)]
# # df['DK1_won_da'].interpolate(method='polynomial', order=1)
# # df['SE3_won_da'].interpolate(method='polynomial', order=1)

# times_muestra_conjunta=25000

# # times_muestra_conjunta=30000
# # df2=(df[0:times_muestra_conjunta])
# # df2=df
# # max_valuew1 = df2["DK1_won_da"].max()
# # max_valuew2 = df2["SE3_won_da"].max()

# # df2=df2.values #ya es un array


# # df2[:,0] =(1/max_valuew1 )*df2[:,0]
# # df2[:,1] =(1/max_valuew2 )*df2[:,1]






# # df2[:,0] =(maxgen_nwind1)*df2[:,0]
# # df2[:,1] =(maxgen_nwind2 )*df2[:,1]




#### GENERO LOS 30000 PUNTOS DE MI SOPORTE

# size_supportset=10

times_muestra_conjunta=25000
muestra_real_conjunta=[]
maxgen_nwind1=60
# maxgen_nwind2=100

forecasted_wind=array_to_dict([30])
zpred={}
zpred[1]=forecasted_wind[1]
# zpred[2]=forecasted_wind[2]

support_liminfconjunta=array_to_dict([-maxgen_nwind1])
support_limsupconjunta=array_to_dict([maxgen_nwind1])

support_liminfcond=array_to_dict([-zpred[1]])
support_limsupcond=array_to_dict([maxgen_nwind1-zpred[1]])


#construyo matriz del soporte de la condicional CTy d









liminf_Omega_conjunta=-maxgen_nwind1

limsup_Omega_conjunta=maxgen_nwind1

liminf_Omega_cond=-zpred[1]

limsup_Omega_cond=maxgen_nwind1-zpred[1]

Nwind=1
Nfeature=1
Ngen=3
Nbus=3
Nlines=3

Nsamples=30

indices=pd.read_csv("indices30.csv", header=None).values   







set_i=range(1,Nsamples+1)
set_l=range(1,Nwind +1 )
set_p=range(1,Nfeature+1)


set_ngen=range(1,Ngen+1)

set_nwind=range(1,Nwind+1)
set_nbus=range(1,Nbus+1)
set_nlines=range(1,Nlines+1)

set_pieces_gen=range(1,Ngen+1+1)
set_pieces_lines=range(1,Nlines+1+1)

npiecesgen=3
set_pieces=range(1,npiecesgen+1)
slopes_gen=np.empty((len(set_ngen),len(set_pieces)), dtype=object)
intercepts_gen=np.empty((len(set_ngen),len(set_pieces)), dtype=object)





gen_6node=pd.read_csv("gen_3node.csv", header=None)
# gen_3node=array_to_dict(gen_6node.values)
index_genbus=array_to_dict((gen_6node.iloc[1:Ngen+2,1]).values.astype(int))

index_busgen={key: {} for key in set_nbus}
for jj in set_nbus:
    index_busgen[jj]=list([k for k,v in index_genbus.items() if v==jj])
    
wind_6node=pd.read_csv("wind_3node.csv", header=None)
index_windbus=array_to_dict((wind_6node.iloc[1:Nwind+2,1]).values.astype(int))

index_buswind={key: {} for key in set_nbus}
for jj in set_nbus:
    index_buswind[jj]=list([k for k,v in index_windbus.items() if v==jj])
    
 
    
 
    
    
 
matrixC=np.zeros((2*Nwind, Nwind))
matrixC[0,0]=-1
matrixC[1,0]=1
# matrixC[2,1]=-1
# matrixC[3,1]=1

vectord=np.zeros((2*Nwind,))

vectord[0]=-support_liminfcond[1]
vectord[1]=support_limsupcond[1]
# vectord[2]=-support_liminfcond[2]
# vectord[3]=support_limsupcond[2]

CT=array_to_dict(matrixC.transpose())
d_vector=array_to_dict(vectord)    
 
    
vectordconjunta=np.zeros((2*Nwind,))

vectordconjunta[0]=-support_liminfconjunta[1]
vectordconjunta[1]=support_limsupconjunta[1]
# vectordconjunta[2]=-support_liminfconjunta[2]
# vectordconjunta[3]=support_limsupconjunta[2] 
    
d_vectorconjunta=array_to_dict(vectordconjunta)  
    
 
    
####creo la muestra conjunta
from scipy.stats import binom
from random import choices


def muestra_mixtura_bivariate(N,mean,mean2,mean3,cov,cov2,cov3,weights,dimension, maxgen_nwind1):
    NDATA=N
#    mixture_idx = np.random.choice(3, size=3*NDATA, replace=True, p=weights)
    media={}
    covariance={}
    
    media[0]=mean
    media[1]=mean2
    media[2]=mean3
    
    covariance[0]=cov
    covariance[1]=cov2
    covariance[2]=cov3
    
    muestra_bien=0 
    
    muestra=np.zeros(shape=(NDATA,dimension))
    contador=0
    while muestra_bien==0:
        limitsok=False
        mixture_idx = np.random.choice(3, size=1, replace=True, p=weights)
        MM= list(np.random.multivariate_normal(media[i], covariance[i],1).T for i in mixture_idx)
#        print("MM", MM)
        MM_list=MM
        MM=array(MM)
#        print("MM array",MM)
        
#        print(muestra)
#        print("MM de 00", MM[0,0])
#        print("MM de 01", MM[0,1])
#
        if MM[0,0]<= maxgen_nwind1 and MM[0,0]>=0 and MM[0,1]<= maxgen_nwind1-MM[0,0] and MM[0,1]>=-MM[0,0]:
            limitsok=True
        if  muestra_bien==0 and limitsok==True:
           
                
            #            print("MM de 0:", MM[0,:])
#            print("radio ",radio)
##        print("mcholesky", mcholesky)
##        print("limite liminf muestra biv ", liminf[1], limsup[1] )
#            print("producto es menor que r ", np.linalg.norm(np.dot(mcholesky,(MM[0,:]-mean)), ord=1))
#            print("mean", mean)
#            print("resta ", MM[0,:]-mean)
            muestra[contador,0]=MM[0,0]
            muestra[contador,1]=MM[0,1]
            muestra[contador,2]=MM[0,1]
            contador=contador+1
#            print("contador", contador)
            if contador==NDATA:
                muestra_bien=1
        
          
              
#        print("muestra de la real-->", muestra)
    
    

    return muestra


# population = [1, 2, 3]
# weights = [0.,1,0.]
# samples_mixture=[choices(population, weights)[0] for x in range(100000)]
# # zdata1=[np.random.uniform(0.15,0.2,1) if x==1 else np.random.uniform(0.45,0.55,1) if x==2 else np.random.uniform(0.8,0.85,1) if x==3 for x in samples_mixture]
# zdata1=[]
# for kk in samples_mixture:
#     if kk==1:
#         num_mixture_sample=np.random.normal(0.1,0.1,1)
#     elif kk==2:
#         num_mixture_sample=np.random.normal(0.5,0.1,1)
#     else:
#         num_mixture_sample=np.random.normal(0.9,0.01,1)
#     zdata1.append(num_mixture_sample)

# zdata2=[np.random.uniform(0.05,0.45,1) if x==1 else np.random.uniform(0.7,0.8,1) for x in list(binom.rvs(1, 0.5, size=100000))]

# zdata1=np.array([x for x in lk])
# zdata2=np.array([])
len_muestraconjunta=0
j=0





# cov=np.array([[0.5,0.01],
#         [0.01, 4]])


# mean_w1=np.mean(omegadataconjunta[:,0])
# mean_w2=np.mean(omegadataconjunta[:,1])
# mean_w=np.mean(omegadataconjunta, axis=0)
# mcholesky=linalg.cholesky(inv(np.matrix(np.asarray(cov))))    
# mcholesky=np.array([[0.8 ,0.1],
#         [0.1      , 0.3]])
# print("mcholesky",mcholesky)                   
# while len(muestra_real_conjunta)<times_muestra_conjunta:
#     vector_muestra=[]
    
#     # print("j",j)
    
    
#     sigma2_w1=(0.21*zdata1[j]+0.016)**2   #predicion de 24 horas
#     # sigma2_w2=(0.21*zdata2[j]+0.016)**2   #predicion de 24 horas
    
    
#     alpha_w1=((1-zdata1[j])*(zdata1[j])**2)/(sigma2_w1)-zdata1[j]
    
   
#     beta_w1=(zdata1[j]*(1-zdata1[j])**2)/(sigma2_w1)+zdata1[j]-1
    
#     # alpha_w2=((1-zdata2[j])*(zdata2[j])**2)/(sigma2_w2)-zdata2[j]
#     # beta_w2=(zdata2[j]*(1-zdata2[j])**2)/(sigma2_w2)+zdata2[j]-1
#     # print("alpha_1",alpha_w1)
#     # print("beta_1",beta_w1)
#     # print("alpha_2",alpha_w2)
#     # print("beta_2",beta_w2)
#     # import pdb
#     # pdb.set_trace()
    
#     if alpha_w1>=0 and beta_w1>=0 :
#         # print("alpah bien")
#         omega1=maxgen_nwind1*(np.random.beta(alpha_w1,beta_w1) -zdata1[j]  )
#         # omega2=maxgen_nwind2*(np.random.beta(alpha_w2,beta_w2) -zdata2[j]  )
    
#         Omega=omega1
    
    
#         # vector_muestra.append(zdata1[j]*maxgen_nwind1)
#         # vector_muestra.append(zdata2[j]*maxgen_nwind2)
#         # vector_muestra.append(omega1)
#         # vector_muestra.append(omega2)
#         # vector_muestra.append(Omega)
#         # print("forecasted_wind[1]+omega1",forecasted_wind[1]+omega1)
#         # if forecasted_wind[1]+omega1<=maxgen_nwind1:
#         #     print("omega1 bien")
    
#         # print("zdata1",zdata1)
#         # print("np.linalg.=size_supportset",np.linalg.norm(np.dot(mcholesky,np.array([omega1,omega2])), ord=1))
#         vector_muestra.append(zdata1[j]*maxgen_nwind1)
#         # vector_muestra.append(zdata2[j]*maxgen_nwind2)
#         vector_muestra.append(omega1[0])
#         # vector_muestra.append(omega2[0])
#         vector_muestra.append(Omega[0])
#         muestra_real_conjunta.append(vector_muestra)
#         len_muestraconjunta=len_muestraconjunta+1
#             # print("len_muestraconjunta",len_muestraconjunta)
    
#     j=j+1
#     print("j",j)
    # print("MUESTRA[i]  ",muestra[i])    

# np.savetxt("muestra_real_conjunta.csv", muestra_real_conjunta, delimiter=",")

# # 


mean = [30,20]
cov = [[20, 0.1], [0.1, 1]]  # diagonal covariance  

mean2 = [25,-40]
cov2 = [[3, 0.01], [0.01,3]] 

mean3 = [50,-50]
cov3 = [[20, 5], [5, 30]]  # diagonal covariance e 

weights=[0.4,0.3,0.3]
dim_randomvar_conjunta=3
n_mixt_real=25000
muestra_dist_real=muestra_mixtura_bivariate(n_mixt_real,mean,mean2,mean3,cov,cov2,cov3,weights,dim_randomvar_conjunta, maxgen_nwind1)
# np.savetxt("muestra_real_conjunta.csv", muestra_dist_real, delimiter=",")

muestra_real_conjunta=pd.read_csv("muestra_real_conjunta.csv", header=None).values


zdataconjunta=muestra_real_conjunta[:,[0]]
ydataconjunta=muestra_real_conjunta[:,[1,2]]
omegadataconjunta=muestra_real_conjunta[:,[1]]

Omegadataconjunta=muestra_real_conjunta[:,[2]]



knn=math.floor(n_mixt_real/(math.log(n_mixt_real+1)))
#knn=math.floor(math.sqrt(n_mixt_real))
print("knn es",knn)
set_knn=range(1, knn+1)
set_knn_real_cond=set_knn
print("set_knn",set_knn)
from sklearn.neighbors import KNeighborsRegressor
neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
#        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
#        print("y ", XX[:,1])
neigh.fit(zdataconjunta,omegadataconjunta) 
dist,entornos=neigh.kneighbors([[zpred[1]]]) 

distancia_media_knn_real=np.mean(dist)
#print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
dict_entornos=array_to_dict(entornos)
#print("diccionario de entornos", dict_entornos)
print("lista de ebtriornbos",  list(dict_entornos.values()))
ydataknn={}
ydataknn_array=[]
for i in range(1,len(list(dict_entornos.values()))+1):
#    ydataknn[i]=XX[dict_entornos[1,i],1]
    ydataknn[i]=omegadataconjunta[dict_entornos[1,i]]
    ydataknn_array.append(ydataknn[i])

# print("ydataknn calculado con el knn ",ydataknn)

# np.savetxt("ydataknn_array.csv", ydataknn_array, delimiter=",")




longitud=len(ydataknn)
ydataknn_cc=np.asarray(ydataknn)
#ydataknn_c=ydataknn_cc.astype(np.float)
ydataknn_c=np.asarray(ydataknn)
ydataknn={}

#sns.distplot(ydataknn_c, kde=True, norm_hist=True)
#plt.hist(ydataknn_c, bins='auto',density=True,stacked=True)
# ydataknn_realcondicional= dict(zip(range(1,longitud+1),ydataknn_c))

times_muestra_cond=knn


muestra_real_cond=pd.read_csv("ydataknn_array.csv", header=None).values




# zdataconjunta=muestra_real_cond[:,[0,1]]
# ydataconjunta=muestra_real_conjunta[:,[2,3,4]]
omegadatacond=muestra_real_cond[:,0]

Omegadatacond=muestra_real_cond[:,0]


# # cov= np.cov(omegadataconjunta.transpose())


# # for j in range(25000):
# #     if np.linalg.norm(np.dot(mcholesky,omegadataconjunta[j,:]), ord=1)<=3.5 and len(muestra_real_conjunta_def)<30000:
# #         muestra_real_conjunta_def.append(muestra_real_conjunta[j,:] )
        
    

    
    




# np.savetxt("muestra_real_conjunta_bernouilli.csv", muestra_real_conjunta_bernouilli, delimiter=",")

# # muestra_real_conjunta=[]
# # with open("muestra_real_conjunta.csv", newline='') as File:
# #     reader = csv.reader(File)
# #     for row in reader:
# #         muestra_real_conjunta.append(np.array(list(map(float,row))))

# # muestra_real_conjunta=np.asarray(muestra_real_conjunta)
# ###############################################################################################

#genero la condicional real
len_muestracond=0
j=0

# muestra_real_cond=[]
# while len(muestra_real_cond)<times_muestra_cond:
#     vector_muestra=[]
    
#     print("j",j)
    
    
#     sigma2_w1=(0.21*(zpred[1]/maxgen_nwind1)+0.016)**2   #predicion de 24 horas
#     # sigma2_w2=(0.21*(zpred[2]/maxgen_nwind2)+0.016)**2   #predicion de 24 horas
    
    
#     alpha_w1=((1-zpred[1]/maxgen_nwind1)*(zpred[1]/maxgen_nwind1)**2)/(sigma2_w1)-zpred[1]/maxgen_nwind1
    
   
#     beta_w1=((zpred[1]/(maxgen_nwind1))*(1-zpred[1]/maxgen_nwind1)**2)/(sigma2_w1)+zpred[1]/maxgen_nwind1-1
    
#     # alpha_w2=((1-zpred[2]/maxgen_nwind2)*(zpred[2]/maxgen_nwind2)**2)/(sigma2_w2)-zpred[2]/maxgen_nwind2
#     # beta_w2=((zpred[2]/(maxgen_nwind2))*(1-zpred[2]/maxgen_nwind2)**2)/(sigma2_w2)+zpred[2]/maxgen_nwind2-1
    
#     if alpha_w1>=0 and beta_w1>=0 :
#         print("alpha bien cond")
#         omega1=maxgen_nwind1*(np.random.beta(alpha_w1,beta_w1) -zpred[1]/maxgen_nwind1  )
#         # omega2=maxgen_nwind2*(np.random.beta(alpha_w2,beta_w2) -zpred[2]/maxgen_nwind2  )
    
#         Omega=omega1
    
    
#         # vector_muestra.append(zdata1[j]*maxgen_nwind1)
#         # vector_muestra.append(zdata2[j]*maxgen_nwind2)
#         # vector_muestra.append(omega1)
#         # vector_muestra.append(omega2)
#         # vector_muestra.append(Omega)
#         # print("forecasted_wind[2]+omega1",omega2)
#         # if forecasted_wind[1]+omega1<=maxgen_nwind1:
#         #     print("omega1 bien")
    
    
        
#             # vector_muestra.append(zpred[1]*maxgen_nwind1)
#             # vector_muestra.append(zdata2[j]*maxgen_nwind2)
#         vector_muestra.append(omega1)
#         # vector_muestra.append(omega2)
#         vector_muestra.append(Omega)
#         muestra_real_cond.append(vector_muestra)
#         len_muestracond=len_muestracond+1
#             # print("len_muestracond",len_muestracond)
    
#     j=j+1








# np.savetxt("muestra_real_cond.csv", muestra_real_cond, delimiter=",")
# 

# muestra_real_cond=pd.read_csv("muestra_real_cond.csv", header=None).values




# zdataconjunta=muestra_real_cond[:,[0,1]]
# ydataconjunta=muestra_real_conjunta[:,[2,3,4]]
# omegadatacond=muestra_real_cond[:,[0]]

# Omegadatacond=muestra_real_cond[:,[1]]







# cov= np.cov(omegadataconjunta.transpose())
# mean_w1=np.mean(omegadataconjunta[:,0])
# mean_w2=np.mean(omegadataconjunta[:,1])
# mean_w=np.mean(omegadataconjunta, axis=0)
# mcholesky=linalg.cholesky(inv(np.matrix(np.asarray(cov))))    

# B=array_to_dict((inv(mcholesky.transpose())))
# B=array_to_dict((inv(mcholesky).transpose()))







# times=500
# indices={}
# indices_list=[]
# for j in list(range(times)):

#     #saco la muestra
#     indices[j]=np.random.choice(muestra_real_conjunta.shape[0], Nsamples, replace=True)
    
#     indices_list.append(indices [j])
    
# np.savetxt("indices30.csv", indices_list,delimiter=",", fmt='%d')
    
    
    
    

# indices=pd.read_csv("indices200.csv", header=None).values


print("INDICES",indices)


coste1=array_to_dict([0.05,0.15,0.25])
# coste1=array_to_dict([0.0,0.0,0])

coste2=array_to_dict([20,25,30])
# coste2=array_to_dict([11,8.5,12.25])

coste3=array_to_dict([0,0,0])



load=array_to_dict([0,0,200])
# load=array_to_dict([0,0,0,0,130,0,150,0,180])
coste_reserv_d=array_to_dict([6,2,4])
coste_reserv_u=array_to_dict([3,5,8])

# load=array_to_dict([0,0,70,0,170,70])





# liminf_omega=[np.min(muestra_real_conjunta[:,2]),np.min(muestra_real_conjunta[:,3])]
# limsup_omega=[np.max(muestra_real_conjunta[:,2]),np.max(muestra_real_conjunta[:,3])]


# cov= np.cov(omegadataconjunta.transpose())
# # mean_w1=np.mean(omegadataconjunta[:,0])
# # mean_w2=np.mean(omegadataconjunta[:,1])
# # mean_w=np.mean(omegadataconjunta, axis=0)
# mcholesky=linalg.cholesky(inv(np.matrix(np.asarray(cov))))

#calculo Gamma.





# Gamma=sum
# Gamma=0
# for j in range(times_muestra_conjunta):
#     # print(j)
#     if np.linalg.norm(np.dot(mcholesky,omegadataconjunta[j,:]), ord=1)>Gamma:
#         Gamma=np.linalg.norm(np.dot(mcholesky,omegadataconjunta[j,:]), ord=1)

# param_reserv_lines=list(np.arange(250,1000))

# for jj in range(30000):
#     # print(jj)
#     if np.linalg.norm(np.dot(mcholesky,omegadataconjunta[jj,:]), ord=1)<=size_supportset:
#         print("j bien",jj)
#         print("--------")



# cost_GD=array_to_dict(1000*np.ones(Ngen))
# cost_GU=array_to_dict(1000*np.ones(Ngen))

# cost_RD=array_to_dict(1000*np.ones(Ngen))
# cost_RU=array_to_dict(1000*np.ones(Ngen))

# cost_LD=array_to_dict(1000*np.ones(Nlines))
# cost_LU=array_to_dict(1000*np.ones(Nlines))


# size_supportset=max(abs(np.amax(muestra_real_conjunta[:,2])),abs(np.amax(muestra_real_conjunta[:,3])))
array_matrixGbus=np.array([[1,0,0],[0,1,0],[0,0,1]])
matrixGbus=array_to_dict(np.array([[1,0,0],[0,1,0],[0,0,1]]))


array_matrixHbus=np.array([[0],[1],[0]])

matrixHbus=array_to_dict(np.array([[0],[1],[0]]))

# gmin=array_to_dict([100,50,20])
# gmax=array_to_dict([200,150,90])
gmin=array_to_dict([0,0,0])
gmax=array_to_dict([120,80,100])




# 


node_ref=1
lines=pd.read_csv('3busdata.csv', index_col=0)
capline=array_to_dict(list(1*lines['C(MW)'].values))
print("capline",capline)
# capline=array_to_dict([2000,10000,20000,10000,10000,20000,20000])
from power_tools import compute_ptdf_matrix
# PTDF_MATRIX=(np.append(np.zeros((Nlines,1)), ptdf_matrix(lines,Nbus,node_ref).values, axis=1)).transpose()
PTDF_MATRIX=(np.append(np.zeros((Nlines,1)), compute_ptdf_matrix(lines,node_ref).values, axis=1)).transpose()
# compute_ptdf_matrix(input_data, ref_node=None)
print(PTDF_MATRIX)
PTDF_dict=array_to_dict(PTDF_MATRIX)









# import pwlf
# for j in set_ngen:
    
#     c1=coste1[j]
#     c2=coste2[j]
#     c3=coste3[j]
#     x_grid= np.linspace(gmin[j],gmax[j], 1000)
#     y_grid=np.array([c1*x**2+c2*x+c3 for x in x_grid])
#     # print("ygrid",y_grid)
#     # # axes.set_yscale('log')  
#     # plt.figure()
#     # plt.axis('auto')
#     plt.plot(x_grid,y_grid)
#     # plt.show()
#     #fit your data (x and y)
#     myPWLF = pwlf.PiecewiseLinFit(x_grid, y_grid)
    
#     # #fit the data for n line segments
#     breaks= myPWLF.fit(npiecesgen)
#     print("breaks",breaks)
#     # calculate slopes
#     slopes = myPWLF.calc_slopes()
#     intercepts=myPWLF.intercepts
#     for s in range(npiecesgen):
#         slopes_gen[j-1,s]=slopes[s]
#         intercepts_gen[j-1,s]=intercepts[s]
    

# print("slopes_gen antes",slopes_gen)

# print("intercepts_gen antes",intercepts_gen)

# np.savetxt("slopes_gen.csv", slopes_gen, delimiter=",")


slopes_gen=array_to_dict(pd.read_csv("slopes_gen.csv", header=None).values)


# np.savetxt("intercepts_gen.csv", intercepts_gen, delimiter=",")


intercepts_gen=array_to_dict(pd.read_csv("intercepts_gen.csv", header=None).values)
print("slopes_gen",slopes_gen)

print("intercepts_gen",intercepts_gen)







# for j in set_ngen:
    
#     c1=coste1[j]
#     c2=coste2[j]
#     c3=coste3[j]
#     x_grid= np.linspace(gmin[j],gmax[j], 1000)
#     y_grid=np.array([max(slopes_gen[j,1]*x+intercepts_gen[j,1],slopes_gen[j,2]*x+intercepts_gen[j,2],slopes_gen[j,3]*x+intercepts_gen[j,3]) for x in x_grid])
#     # print("ygrid",y_grid)
#     # # axes.set_yscale('log')  
#     # plt.figure()
#     # plt.axis('str)
#     plt.plot(x_grid,y_grid)
    # plt.show()
    #fit your data (x and y)
    # myPWLF = pwlf.PiecewiseLinFit(x_grid, y_grid)
    
    # # #fit the data for n line segments
    # breaks= myPWLF.fit(npiecesgen)
    # print("breaks",breaks)
    # # calculate slopes
    # slopes = myPWLF.calc_slopes()
    # intercepts=myPWLF.intercepts
    # for s in range(npiecesgen):
    #     slopes_gen[j-1,s]=slopes[s]
    #     intercepts_gen[j-1,s]=intercepts[s]


#calculo media y covarianza

# puntos_yconjunta_real=muestra_real_conjunta[:,[3,4,5,6,7,8]]

# cov_yrealconjunta=np.cov(puntos_yconjunta_real,rowvar=False)

# #std_yrealconjunta=sqrtm(cov_yrealconjunta)
# std_yrealconjunta=np.diag(np.sqrt(np.diag(cov_yrealconjunta)))
# media_yrealconjunta=puntos_yconjunta_real.mean(axis=0)

# #np.savetxt("media_yrealconjunta.csv", media_yrealconjunta, delimiter=",")
# #np.savetxt("cov_yrealconjunta.csv", cov_yrealconjunta, delimiter-
# n_mixt_real=muestra_real_conjunta.shape[0]
# n_mixt_real=2

# knnreal=math.floor(n_mixt_real/(math.log(n_mixt_real+1)))

knnreal=times_muestra_cond
# #knn=math.floor(math.sqrt(n_mixt_real))
# print("knn es",knn)
# #set_knn_real=list(range(1, 1000+1))
# set_knn_real=list(range(1, n_mixt_real+1))
# set_dx=list(range(1,6+1))
# set_dy=set_dx
# set_k=list(range(1,3))




# zdataconjunta=muestra_real_conjunta[np.array(list(range(0, 2)))[:,None],[0,1]]
# ydataconjunta=muestra_real_conjunta[np.array(list(range(0, 2)))[:,None],[2,3,4]]

# omegadataconjunta=muestra_real_conjunta[np.array(list(range(0, 2)))[:,None],[2,3]]

# Omegadataconjunta=muestra_real_conjunta[np.array(list(range(0, 2)))[:,None],[4]]

#
from sklearn.neighbors import KNeighborsRegressor
# neigh = KNeighborsRegressor(n_neighbors=knnreal,metric='minkowski',p=1)
# neigh.fit(zdataconjunta,ydataconjunta) 

# dist,entornos=neigh.kneighbors([[zpred[1],zpred[2]]]) 
# media_dist_knn_muestra=np.array([]) 

# dist_knnreal=np.mean(dist)


# #print("z prediccion",zprediccion_feature, ", prediccion ", neigh.predict([[zprediccion_feature]]), " entornos del punto ---> ",entornos )
# dict_entornos=array_to_dict(entornos)
# #print("diccionario de entornos", dict_entornos)
# #print("lista de ebtriornbos",  list(dict_entornos.values()))
# ydataknnreal={}
# ydataknndroboot_array=[]
# ydataknnreal_dict={}
# Omegadataknnreal={}
# for i in range(1,len(list(dict_entornos.values()))+1):
# #    ydataknn[i]=XX[dict_entornos[1,i],1]
#     ydataknnreal[i]=omegadataconjunta[dict_entornos[1,i],[0,1]]
    
#     Omegadataknnreal[i]=(Omegadataconjunta[dict_entornos[1,i],[0]])[0]
#     for jj in range(0,len(set_nwind)):
#         ydataknnreal_dict[i,jj+1]=(ydataknnreal[i])[jj]








# mass=knnreal/n_mixt_real




# def pyomo_to_pandas1(instance,variable):

#     #Function that converts variables in pyomo instance to dataframe
#         df_variables = pd.DataFrame()
#         for v in instance.component_objects(pe.Var, active=True):
#             if str(variable) == str(v):
#                 for i in v:
#                     df_variables.loc[i, str(v)] = v[i].value
#         return df_variables
    
# def pyomo_to_pandas(instance,variable):

#     #Function that converts variables in pyomo instance to dataframe
#         df_variables = pd.DataFrame()
#         for v in instance.component_objects(pe.Var, active=True):
#             if str(variable) == str(v):
#                 for e,i in v:
#                     df_variables.loc[e,i] = v[e,i].value
                    
#         return df_variables
    
# for j in range(times_muestra_conjunta):
#     print(j)
#     if np.linalg.norm(np.dot(mcholesky,omegadataconjunta[j,:]), ord=1)<=3.5:
#         plt.scatter(omegadataconjunta[j,0],omegadataconjunta[j,1],color='red')


# import seaborn as sns
# sns.jointplot(x=muestra_real_cond[:,0], y=muestra_real_cond[:,1], kind="kde")
# sns.jointplot(x=omegadataconjunta[:,0], y=omegadataconjunta[:,1], kind="kde")
# sns.kdeplot(data=omegadataconjunta)
# times_data=0
# for j in range(50000):
#     # print(j)
#     aa= np.array([np.random.uniform(-40,40),np.random.uniform(-40,40)]) 
    
#     if np.linalg.norm(np.dot(mcholesky, aa ), ord=1)<=size_supportset:
#         plt.scatter(aa[0],aa[1],color='red')        
        
# sns.jointplot(x=muestra_real_cond[:,0], y=muestra_real_conda[:,1], kind="kde")
        





ydataknnreal=muestra_real_cond[:,0]

ydataknnreal_dict=array_to_dict(muestra_real_cond[:,[0]])

Omegadataknnreal=array_to_dict(muestra_real_cond[:,0])

knnreal=len(Omegadataknnreal)

set_knn_real=list(range(1, knnreal+1))

import seaborn as sns

# sns.jointplot(x=zdataconjunta[:,0], y=omegadataconjunta[:,0])


import os
# os.environ["OMP_NUM_THREADS"] = "1" 


# sns.jointplot(x=zdataconjunta[:,0], y=muestra_real_cond[:,0])

# sns.jointplot(x=muestra_real_cond[:,0], y=muestra_real_cond[:,1])


epsGD=0.1



gensolreal={}
betasolreal={}
sum_reserv_totalreal=0
quantity_saa_opt=[]
gensol_saa_opt=[]
betasol_saa_opt=[]
reserv_total_saa_opt=[]














#genero las muestras:


from itertools import product


#picasso




vector_sample =list(range(200))
nmethods=3
allcases=[[i,m] for i in vector_sample for m in [1,2,3] ]
case=allcases[int(os.environ['SLURM_ARRAY_TASK_ID'])-1]

index_samplepicasso=case[0]
metodo=case[1]
# 
range_radios=[0.000001,0.00001,0.0001,0.001,0.005,0.01,0.05,0.06,0.07,0.08,0.09,0.1,0.12,0.15,0.18,0.2,0.22,0.25,0.3,0.4,0.5,1,5,10,100,1000]


data_a=[]
data_b=[]
data_a2=[]

data_q1_knn=[]
data_q1_knn_robust=[]
data_q1_knn_dro=[]
data_q1_kn=[]
data_a21=[]
data_a22=[]
data_a23=[]
data_a24=[]
data_a25=[]
data_b2=[]
data_d2=[]
data_e2=[]
data_c2=[]
data_f2=[]

data_a21kuhn=[]
data_a22kuhn=[]
data_a23kuhn=[]
data_a24kuhn=[]
data_a25kuhn=[]
data_b2kuhn=[]
data_d2kuhn=[]
data_e2kuhn=[]
data_c2kuhn=[]
data_f2kuhn=[]


data_a21kuhnnoside=[]
data_a22kuhnnoside=[]
data_a23kuhnnoside=[]
data_a24kuhnnoside=[]
data_a25kuhnnoside=[]
data_b2kuhnnoside=[]
data_d2kuhnnoside=[]
data_e2kuhnnoside=[]
data_c2kuhnnoside=[]
data_f2kuhnnoside=[]



data_gen1kuhnnoside=[]
data_gen2kuhnnoside=[]
data_gen3kuhnnoside=[]
data_beta1kuhnnoside=[]
data_beta2kuhnnoside=[]
data_beta3kuhnnoside=[]


data_gen1kuhn=[]
data_gen2kuhn=[]
data_gen3kuhn=[]
data_beta1kuhn=[]
data_beta2kuhn=[]
data_beta3kuhn=[]

data_gen1=[]
data_gen2=[]
data_gen3=[]
data_beta1=[]
data_beta2=[]
data_beta3=[]




data_a21knn=[]
data_a22knn=[]
data_a23knn=[]
data_a24knn=[]
data_a25knn=[]
data_b2knn=[]
data_d2knn=[]
data_e2knn=[]
data_c2knn=[]
data_f2knn=[]
data_g2=[]
data_g2knn=[]
data_g2kuhn=[]
data_g2kuhnnoside=[]
data_q1_knn=[]

data_d2=[]
data_a2=[]
data_q1_kuhn=[]





range_ro_knn={}
range_ro_kn={}
range_ro_kndro={}
parametros_kn={}
range_eps_knnrobust={}
parametros_knnrobust={}
parametros_knndro={}
#for j in list(range(b1,b1+1)):
#    range_ro_knn[j]=list([math.floor(j/(math.log(j+1)))])
#    
#    #range_ro_kn[j]=[(k*math.sqrt(j)/j**(l))+k/(j**(l)) for k in [2,50,100,500,3000] for l in [0.02,0.03]]
##    range_ro_kn[20]=list([80,85,90,100,120,150]) 
##    range_ro_kn[30]=list([60,65,70,80,90,100,120])
##    range_ro_kn[40]=list([50,55,60,65,70,80,100])
##    range_ro_kn[50]=list([30,35,40,45,55,70])
##    range_ro_kn[60]=list([20,25,30,35,45,60])
##    range_ro_kn[70]=list([20,25,30,35])
##    range_ro_kn[80]=list([8.5,9,15,22,30]) 
##    range_ro_kn[100]=list([8,12,15,22,25])
##    range_ro_kn[200]=list([7.5,10,15,20,25])
##    range_ro_kn[300]=list([7,10,15,20])
##    range_ro_kn[400]=list([6.5,10,14,18])
##    range_ro_kn[500]=list([6,7,8,10])
##    range_ro_kn[600]=list([5,6,7,8])
#    print("numero de muestras j",j)
#    if j>40:
#        range_ro_kndro[j]=[k/(j**(l)) for k in [1] for l in [1/9,0.06]]
#        range_eps_knnrobust[j]=[k/(j**(l)) for k in [1800] for l in [0.08,0.06]]
#    else:
#        range_ro_kndro[j]=[k/(j**(l)) for k in [4] for l in [1/9,0.02]]
#        range_eps_knnrobust[j]=[k/(j**(l)) for k in [4000] for l in [0.02,0.05]]
#
#        
##    parametros_kn[j]=list(map(list,product(range_ro_knn[j],range_ro_kn[j])))
#    
#    
#    
#    parametros_knnrobust[j]=list(map(list,product(range_ro_knn[j],range_eps_knnrobust[j])))
#
#    parametros_knndro[j]=list(map(list,product(range_ro_knn[j],range_ro_kndro[j])))
#
##picasso
##case = int(os.environ['SLURM_ARRAY_TASK_ID']) 
##b1 = vector_b1[case-1]
#print(" parametros_knnrobust",parametros_knnrobust)
    
#b1=20











confidence_level=0.
array_o1n=np.array([])#Array para guardar out of sample disappointment
array_okn=np.array([])
array_oknn=np.array([])
array_oknn_dro=np.array([])
array_oknn_robust=np.array([])
array_outofsamplecond=np.array([])
array_performancecond=np.array([])
array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_eknn=np.array([])
array_eknn_dro=np.array([])
array_eknn_robust=np.array([])

array_gen1=np.array([])
array_gen2=np.array([])
array_reserv_tot_D=np.array([])
array_reserv_tot_U=np.array([])
array_gen3=np.array([])
array_beta1=np.array([])
array_beta2=np.array([])
array_beta3=np.array([])
array_beta3kuhn=np.array([])
array_beta3knn=np.array([])
array_objval_1kn=np.array([])



array_o1n=np.array([])#Array para guardar out of sample disappointment
array_okn=np.array([])
array_oknn=np.array([])
array_oknn_dro=np.array([])
array_oknn_robust=np.array([])
array_outofsamplecondkuhn=np.array([])
array_performancecondkuhn=np.array([])
array_outofsamplecondkuhnnoside=np.array([])
array_performancecondkuhnnoside=np.array([])
array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_eknn=np.array([])
array_eknn_dro=np.array([])
array_eknn_robust=np.array([])

array_gen1kuhn=np.array([])
array_gen2kuhn=np.array([])
array_reserv_totkuhn_D=np.array([])
array_reserv_totkuhn_U=np.array([])
array_gen3kuhn=np.array([])
array_beta1kuhn=np.array([])
array_beta2kuhn=np.array([])
array_objval_1kuhn=np.array([])

array_gen1kuhnnoside=np.array([])
array_gen2kuhnnoside=np.array([])
array_reserv_totkuhnnoside_D=np.array([])
array_reserv_totkuhnnoside_U=np.array([])
array_gen3kuhnnoside=np.array([])
array_beta1kuhnnoside=np.array([])
array_beta2kuhnnoside=np.array([])
array_beta3kuhnnoside=np.array([])
array_objval_1kuhnnoside=np.array([])


array_o1n=np.array([])#Array para guardar out of sample disappointment
array_okn=np.array([])
array_oknn=np.array([])
array_oknn_dro=np.array([])
array_oknn_robust=np.array([])
array_outofsamplecondknn=np.array([])
array_performancecondknn=np.array([])
array_e1n=np.array([])#Array para guardar actual expected cost
array_ekn=np.array([])
array_eknn=np.array([])
array_eknn_dro=np.array([])
array_eknn_robust=np.array([])

array_gen1knn=np.array([])
array_gen2knn=np.array([])
array_reserv_totknn_D=np.array([])
array_reserv_totknn_U=np.array([])
array_gen3knn=np.array([])
array_beta1knn=np.array([])
array_beta2knn=np.array([])
array_objval_1knn=np.array([])


data_a26knn=[]
data_a26kuhn=[]
data_a26=[]
data_a26kuhnnoside=[]
indices_list=[]


    


nocreado_pasadamodel=True

for rr in range_radios:
    # j=3
    b1=rr
    print("MUESTRA NUMERO-->",index_samplepicasso)
    #saco la muestra
#    indices[j]=np.random.choice(muestra_real_conjunta.shape[0], Nsamples, replace=True)
#    print("indices[j]", indices[j])
    set_indices=set(indices[index_samplepicasso])
#    print("set_indices",set_indices)
    muestra_conjunta_sample=muestra_real_conjunta[indices[index_samplepicasso]]
    # print("muestra_conjunta",muestra_conjunta_sample)
    # print("muestra de la real",muestra_real_conjunta[indices[j]])
    #metodo knn
    
    print("pasada radio ", rr)
#
     
#     knn=math.floor(Nsamples/(math.log(Nsamples+1)))
# #    print("valor k modelo 1-k/n",value_knchosen) 
#     #knn=math.floor(math.pow(n_mixt_real,0.75))
#     set_knn=list(range(1, knn+1))
    
    
#     puntos_zkn_array=muestra_conjunta_sample[:,[0]]
#     puntos_ykn_array=muestra_conjunta_sample[:,[1,2]]
    
#     puntos_omegakn_array=muestra_conjunta_sample[:,[1]]
#     # print("puntos_omegakn_array",puntos_omegakn_array)
#     puntos_Omegakn_array=(muestra_conjunta_sample[:,[2]]).reshape(Nsamples,)
    
    
    
    knn=math.floor(Nsamples/(math.log(Nsamples+1)))
#    print("valor k modelo 1-k/n",value_knchosen) 
    # knn=math.floor(math.pow(Nsamples,0.9))
    set_knn=list(range(1, knn+1))
    print("set_knn",set_knn)
    

    
    
    
    
    neigh = KNeighborsRegressor(n_neighbors=knn,metric='minkowski',p=1)
    
    
    # neigh.fit(puntos_zkn_array,puntos_ykn_array) 
    # neigh.fit(puntos_zkn_array,puntos_omegakn_array) 
    
    
    

    # dist,entornos=neigh.kneighbors([[zpred[1],zpred[2],zpred[3],zpred[4],zpred[5],zpred[6]]]) 
    # media_dist_knn_muestra=np.array([]) 
    
    # dist_knnreal=np.mean(dist)
    # dict_entornos=array_to_dict(entornos)
    
    
    # neigh.fit(puntos_zkn_array,puntos_Omegakn_array) 
    
    
    

    # dist2,entornos2=neigh.kneighbors([[zpred[1],zpred[2],zpred[3],zpred[4],zpred[5],zpred[6]]]) 
    # media_dist_knn_muestra=np.array([]) 
    
    # dist_knnreal2=np.mean(dist2)
    # dict_entornos2=array_to_dict(entornos2)

    ydataknn={}
    ydataknndroboot_array=[]
    ydataknn_dict={}
    Omegadataknn={}
    Omegadataknnproj={}
    ydataknnproj_dict={}
    lista_dist_minOmega1=[]
    
    
    
    from sklearn.neighbors import KNeighborsRegressor
    # neigh = KNeighborsRegressor(n_neighbors=kn,metric='minkowski',p=1)
    #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
    #        print("y ", XX[:,1])
    puntos_zkn_array=muestra_conjunta_sample[:,[0]]
    puntos_ykn_array=muestra_conjunta_sample[:,[1,2]]
    
    puntos_omegakn_array=muestra_conjunta_sample[:,[1]]
    # print("puntos_omegakn_array",puntos_omegakn_array)
    puntos_Omegakn_array=(muestra_conjunta_sample[:,[2]]).reshape(Nsamples,)
    

    puntos_omegakn_array_proj={}
    puntos_Omegakn_array_proj={}
    # puntos_omegakn_array_proj=muestra_conjunta_sample[:,[6,7,8,9,10,11]]
    # puntos_Omegakn_array_proj=(muestra_conjunta_sample[:,[12]]).reshape(Nsamples,)
    # puntos_zkn_array=muestra_real_conjunta[np.array([0,1,2])[:,None],[0,1]]
    # puntos_ykn_array=muestra_real_conjunta[np.array([0,1,2])[:,None],[2,3,4]]
    
    # puntos_omegakn_array=muestra_real_conjunta[np.array([0,1,2])[:,None],[2,3]]
    # puntos_Omegakn_array=(muestra_real_conjunta[np.array([0,1,2])[:,None],[4]]).reshape(Nsamples,)
    
    

  
#    print("incremento de radio modelo ro kn elegido",value_rochosen)
    
#    cov_yrealconjunta=np.cov(muestra_conjunta_sample[:,[3,4,5,6,7,8]],rowvar=False)

#std_yrealconjunta=sqrtm(cov_yrealconjunta)
#    std_yrealconjunta_sample=np.diag(np.sqrt(np.diag(cov_yrealconjunta)))



#    media_yrealconjunta_sample=muestra_conjunta_sample[:,[3,4,5,6,7,8]].mean(axis=0)
    
    
    # puntos_ykn_array=np.zeros(shape=(Nsamples,6))
    # for j in range(Nsamples):
    #     puntos_ykn_array[j,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
    
    # neigh.fit(puntos_zkn_array,puntos_omegakn_array) 
    # puntos_yknescalado=array_to_dict(puntos_ykn_array)
    # dist,entornos=neigh.kneighbors([[zpred[1],zpred[2],zpred[3],zpred[4],zpred[5],zpred[6]]]) 
#    dist,entornos=neigh.kneighbors([[970,0,10]])
    # dist_mediaknn=np.mean(dist)
    # print("distancia media knn trimm",dist_mediaknn )
    
    
    

#    radio_rokn_totkn=dist_mediaknn+1000000000000000
    # print("radio_rokn_totkn",radio_rokn_totkn)
   
#    portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_tot,mass,zprediccion_feature,puntos_zboot,puntos_ybootescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))
    # modelokn=portfolio_features_partialmassproblem_escalado(set_i,set_k,set_dz,set_dy,set_dx, Nsamples,coef_betatilde,coef_betatilde1,coef_alphatilde,radio_rokn_totkn,mass,zprediccion_feature,puntos_zkn,puntos_yknescalado,array_to_dict(std_yrealconjunta),array_to_dict(media_yrealconjunta))

    zdata=array_to_dict(puntos_zkn_array)
    # print("zdata",zdata)
    omegadata=array_to_dict(puntos_omegakn_array)
    Omegadata=array_to_dict(puntos_Omegakn_array )
    mass=knn/Nsamples
    mass2=mass
    
    
    
    # dist_mediaknn=0
    # puntos_ykn_array=np.zeros(shape=(Nsamples,6))
    lista_dist_min=[]
    dist_recintoOmega={}
    lista_dist_minOmega=[]
    distnorma1recinto=0
    lista_index_outsideOmega_left=[]
    lista_index_outsideOmega_right=[]
    
    for j in range(Nsamples):
        # puntos_ykn_array[j,:]=np.dot(inv(std_yrealconjunta), muestra_conjunta_sample[j,[3,4,5,6,7,8]]-media_yrealconjunta)
        # zdato=(puntos_zkn_array[j]).tolist()
        lista_dist_minOmegasum=0
        distnorma1recinto=0
        

        for mm in set_nwind:
            distnorma1recinto=distnorma1recinto+abs(puntos_zkn_array[j,mm-1]-zpred[mm])
            lista_dist_minOmegasum=lista_dist_minOmegasum+abs(puntos_zkn_array[j,mm-1]-zpred[mm])
            puntos_omegakn_array_proj[j,mm-1]=puntos_omegakn_array[j,mm-1]
            
            
            if puntos_omegakn_array[j,mm-1]> support_limsupcond[mm]  :
                puntos_omegakn_array_proj[j,mm-1]=support_limsupcond[mm] 
                distnorma1recinto=distnorma1recinto+abs(puntos_omegakn_array[j,mm-1]- support_limsupcond[mm])
                print("he proyectado omega",j,mm)
            
                # print("distnorma1recinto",distnorma1recinto)
            if puntos_omegakn_array[j,mm-1]< support_liminfcond[mm] :
                puntos_omegakn_array_proj[j,mm-1]=support_liminfcond[mm]
                distnorma1recinto=distnorma1recinto+abs(puntos_omegakn_array[j,mm-1]- support_liminfcond[mm])
                print("he proyectado omega",j,mm)
        puntos_Omegakn_array_proj[j]=puntos_Omegakn_array[j]
        if puntos_Omegakn_array[j]<liminf_Omega_cond:
            puntos_Omegakn_array_proj[j]=liminf_Omega_cond
                                    
            lista_dist_minOmegasum=lista_dist_minOmegasum+abs(puntos_Omegakn_array[j]-liminf_Omega_cond)
            print("he proyectado Omega", j)
            lista_index_outsideOmega_left.append(j+1)
        if  puntos_Omegakn_array[j] >limsup_Omega_cond:
            puntos_Omegakn_array_proj[j]=limsup_Omega_cond
            lista_dist_minOmegasum=lista_dist_minOmegasum+abs(puntos_Omegakn_array[j]-limsup_Omega_cond)
            print("he proyectado Omega",j)
            lista_index_outsideOmega_right.append(j+1)
           
        
        
        # print("punto j= ", j, "con distancia z recinto igual a ",np.linalg.norm(puntos_zkn_array[j,:]-np.array([zpred[1],zpred[2]]), ord=1) )
        # print("distnorma1recinto+np.linalg.norm(puntos_zkn_array[j,:]-np.array([zpred[1],zpred[2]]), ord=1)",distnorma1recinto+np.linalg.norm(puntos_zkn_array[j,:]-np.array([zpred[1],zpred[2]]), ord=1))
        # lista_dist_min.append(distnorma1recinto+np.linalg.norm(puntos_zkn_array[j,:]-np.array([zpred[1],zpred[2],zpred[3],zpred[4],zpred[5],zpred[6]]), ord=1))
        # lista_dist_minOmega.append(lista_dist_minOmegasum+np.linalg.norm(puntos_zkn_array[j,:]-np.array([zpred[1],zpred[2],zpred[3],zpred[4],zpred[5],zpred[6]]), ord=1))
        
        
        lista_dist_min.append(distnorma1recinto)
        lista_dist_minOmega.append(lista_dist_minOmegasum)

                
    # lista_dist_min_sorted=sorted(lista_dist_min) 
    lista_dist_min_sorted= { i :sorted((e,i) for i,e in enumerate(lista_dist_min))[i] for i in range(0, len(sorted((e,i) for i,e in enumerate(lista_dist_min))) ) }
   
    
    # lista_dist_min_sortedOmega=sorted(lista_dist_minOmega)                
    # lista_dist_min_sortedOmega=sorted((e,i) for i,e in enumerate(lista_dist_minOmega))        
    lista_dist_min_sortedOmega= { i :sorted((e,i) for i,e in enumerate(lista_dist_minOmega))[i] for i in range(0, len(sorted((e,i) for i,e in enumerate(lista_dist_minOmega))) ) }

    #calculo los puntos proyectados:
    ydataknnproj_dict={}    
    Omegadataknnproj={}
    ydataknn_dict={}    
    Omegadataknn={}
    for i in list(range(knn)):
        for j in set_nwind:
            ydataknnproj_dict[i+1,j]=puntos_omegakn_array_proj[lista_dist_min_sorted[i][1],j-1]
            ydataknn_dict[i+1,j]=puntos_omegakn_array[lista_dist_min_sorted[i][1],j-1]
        
        Omegadataknnproj[i+1]=puntos_Omegakn_array_proj[lista_dist_min_sortedOmega[i][1]]
        Omegadataknn[i+1]=puntos_Omegakn_array[lista_dist_min_sortedOmega[i][1]]
        
    ydataknntotalproj_dict={}    
    Omegadataknntotalproj={}
    # ydataknntotal_dict={}    
    # Omegadataknntotal={}  
    for i in list(range(Nsamples)):
        for j in set_nwind:
            ydataknntotalproj_dict[i+1,j]=puntos_omegakn_array_proj[lista_dist_min_sorted[i][1],j-1]
            # ydataknntotal_dict[i+1,j]=puntos_omegakn_array[lista_dist_min_sorted[i][1],j-1]
        
        Omegadataknntotalproj[i+1]=puntos_Omegakn_array_proj[lista_dist_min_sortedOmega[i][1]] 
        # Omegadataknntotal[i+1]=puntos_Omegakn_array[lista_dist_min_sortedOmega[i][1]]            
        
            
    dist_mediaknn_boot=0
    dist_mediaknn_bootOmega=0       
    for ii in list(range(1,math.ceil(Nsamples*mass)+1)):
        dist_mediaknn_boot=dist_mediaknn_boot+(1/(Nsamples*mass))*lista_dist_min_sorted[ii-1][0]
        dist_mediaknn_bootOmega=dist_mediaknn_bootOmega+(1/(Nsamples*mass))*lista_dist_min_sortedOmega[ii-1][0]
        print("dist_mediaknn_boot",dist_mediaknn_boot)
       
    dist_mediaknn_boot=dist_mediaknn_boot+(1-(math.floor(Nsamples*mass))/(Nsamples*mass))*lista_dist_min_sorted[math.floor(Nsamples*mass)-1][0]
    # print("(1-(math.floor(Nsamples*mass))/(Nsamples*mass))*lista_dist_min_sorted[ii]",(1-(math.floor(Nsamples*mass))/(Nsamples*mass))*lista_dist_min_sorted[math.floor(Nsamples*mass)-1])
    dist_mediaknn_bootOmega=dist_mediaknn_bootOmega+(1-(math.floor(Nsamples*mass))/(Nsamples*mass))*lista_dist_min_sortedOmega[math.floor(Nsamples*mass)-1][0]
        
    print("lista_index_outsideOmega_left",lista_index_outsideOmega_left)
    print("lista_index_outsideOmega_right",lista_index_outsideOmega_right)
    # print("dist media knn Omega",dist_mediaknnOmega)
    lista_index_interval=list(set(range(1,Nsamples+1)) - set(lista_index_outsideOmega_left)-set(lista_index_outsideOmega_right))
    print("lista_index_interval",lista_index_interval)
    set_knntotal=list(range(1, Nsamples+1))
    
    
    if  metodo==1:
        rho2kuhn=b1
        
        Omegadata=Omegadataknn
        omegadata=ydataknn_dict
        m =Model('test_knn')
        tt=m.continuous_var_dict(list(set_knn),lb=-float('inf'))
        tup=m.continuous_var_dict(list(product(set_knn,set_ngen)),lb=-float('inf'))        
        tdown=m.continuous_var_dict(list(product(set_knn,set_ngen)),lb=-float('inf'))
        tdata=m.continuous_var_dict(list(product(set_knn,set_ngen)),lb=-float('inf')) 
        mubarra=m.continuous_var_dict(list(set_knn),lb=-float('inf'))
        
 
    
        r_D=m.continuous_var_dict(list(set_ngen),lb=0)
        r_U=m.continuous_var_dict(list(set_ngen),lb=0)
        g=m.continuous_var_dict(list(set_ngen),lb=-float('inf'))
        beta=m.continuous_var_dict(list(set_ngen),lb=0,ub=1)
        lamb=m.continuous_var(lb=0)
        # theta=m.continuous_var(lb=-float('inf'))
         



                

                
        print("len set_knn", len(set_knn))
        
        
        m.minimize(rho2kuhn*lamb+(1/(len(set_knn)))*m.sum(mubarra[i] for i in set_knn)+m.sum(coste_reserv_d[j]*(r_D[j])+coste_reserv_u[j]*(r_U[j])  for j in set_ngen) )
            
        c1=m.add_constraints((  mubarra[i]>=tt[i] for i in set_knn   ))
        



        
        
        
        c13=m.add_constraints((tt[i]>=m.sum(tdown[i,j] for j in set_ngen) +lamb*(liminf_Omega_conjunta-Omegadata[i]) for i  in set_knn ))
        
        c2=m.add_constraints((  tdown[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*liminf_Omega_conjunta)+intercepts_gen[j,s] for i in set_knn for j in set_ngen for s in set_pieces  ))
        
  
        
        
        c23=m.add_constraints((tt[i]>=m.sum(tup[i,j] for j in set_ngen) -lamb*(limsup_Omega_conjunta-Omegadata[i]) for i  in set_knn ))
        

        c3=m.add_constraints((  tup[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*limsup_Omega_conjunta)+intercepts_gen[j,s] for i in set_knn for j in set_ngen for s in set_pieces  ))
             
            
        c32=m.add_constraints((  tt[i]>=m.sum(tdata[i,j] for j in set_ngen) for i in set_knn  ))       

        c33=m.add_constraints((  tdata[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*Omegadata[i])+intercepts_gen[j,s] for i in set_knn for j in set_ngen for s in set_pieces ))
        

        
        tauGD=m.continuous_var(lb=-float('inf'))   
        lambdaGD=m.continuous_var(lb=0)
        muGD=m.continuous_var_dict(list(set_knn),lb=-float('inf'))

        dim_d_vector=list(range(1,len(d_vectorconjunta)+1))

        


        
        c4=m.add_constraint(tauGD+(1/epsGD)*(lambdaGD*rho2kuhn+(1/(len(set_knn)))*m.sum(muGD[i]   for i in set_knn))<=0)
    



        zRD=m.continuous_var_dict(list(product(set_knn,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vRD=m.continuous_var_dict(list(product(set_knn,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vtildeRD=m.continuous_var_dict(list(product(set_knn,set_pieces_gen,dim_d_vector)),lb=0)

    
        c62=m.add_constraints(( muGD[i]>=(-r_D[k]-tauGD)+m.sum( d_vectorconjunta[m]*vtildeRD[i,k,m] for  m in dim_d_vector)\
            -m.sum(omegadata[i,l]*zRD[i,k,l] for l in set_nwind) for i in set_knn for k in set_ngen  ))
    
        c63=m.add_constraints(( muGD[i]>=m.sum( d_vectorconjunta[m]*vtildeRD[i,Ngen+1,m] for  m in dim_d_vector)\
            -m.sum(omegadata[i,l]*zRD[i,Ngen+1,l] for l in set_nwind) for i in set_knn   ))








            
        c64=m.add_constraints((  zRD[i,k,l]<= lambdaGD for i in set_knn for k in set_pieces_gen for l in set_nwind )) 
        c65=m.add_constraints((  -zRD[i,k,l]<= lambdaGD for i in set_knn for k in set_pieces_gen for l in set_nwind )) 
    
        c66=m.add_constraints((  vRD[i,k,l]== m.sum( CT[l,n]*vtildeRD[i,k,n] for n in dim_d_vector) for i in set_knn for k in set_pieces_gen for l in set_nwind )) 


    
        c67=m.add_constraints((  zRD[i,k,l]-vRD[i,k,l]==-(beta[k]   )  for i in set_knn for k in set_ngen for l in set_nwind )) 
    
        c68=m.add_constraints((  zRD[i,Ngen+1,l]-vRD[i,Ngen+1,l]==-(0   )  for i in set_knn for l in set_nwind )) 

        
        zRU=m.continuous_var_dict(list(product(set_knn,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vRU=m.continuous_var_dict(list(product(set_knn,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vtildeRU=m.continuous_var_dict(list(product(set_knn,set_pieces_gen,dim_d_vector)),lb=0)

        
    
        c72=m.add_constraints(( muGD[i]>=(-r_U[k]-tauGD)+m.sum( d_vectorconjunta[m]*vtildeRU[i,k,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zRU[i,k,l] for l in set_nwind)for i in set_knn for k in set_ngen  ))
    
        c73=m.add_constraints(( muGD[i]>=m.sum( d_vectorconjunta[m]*vtildeRU[i,Ngen+1,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zRU[i,Ngen+1,l] for l in set_nwind) for i in set_knn   ))








            
        c74=m.add_constraints((  zRU[i,k,l]<= lambdaGD for i in set_knn for k in set_pieces_gen for l in set_nwind )) 
        c75=m.add_constraints((  -zRU[i,k,l]<= lambdaGD for i in set_knn for k in set_pieces_gen for l in set_nwind )) 
    
        c76=m.add_constraints((  vRU[i,k,l]== m.sum( CT[l,n]*vtildeRU[i,k,n] for n in dim_d_vector) for i in set_knn for k in set_pieces_gen for l in set_nwind )) 


    
        c77=m.add_constraints((  zRU[i,k,l]-vRU[i,k,l]==-(-beta[k]   )  for i in set_knn for k in set_ngen for l in set_nwind )) 
    
        c78=m.add_constraints((  zRU[i,Ngen+1,l]-vRU[i,Ngen+1,l]==-(0   )  for i in set_knn for l in set_nwind ))

 




        
        zLD=m.continuous_var_dict(list(product(set_knn,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vLD=m.continuous_var_dict(list(product(set_knn,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vtildeLD=m.continuous_var_dict(list(product(set_knn,set_pieces_lines,dim_d_vector)),lb=0)

        PTDF_gen=PTDF_MATRIX.transpose() @ (array_matrixGbus)
        PTDF_wind=PTDF_MATRIX.transpose() @ (array_matrixHbus)
        
        lin_load=[sum([ (PTDF_MATRIX[b-1,k-1])*(-load[b]) for b in set_nbus] ) for k in set_nlines]
        
        lin_wind=[sum([ (PTDF_wind[k-1,mm-1]*(forecasted_wind[mm])) for mm in set_nwind]) for k in set_nlines]
        
        
       
        print("creo restricciones de linea ld")
       
        
        
        c82=m.add_constraints(( muGD[i]>=(-capline[k]-(m.sum( PTDF_gen[k-1,j-1]*g[j] for j in set_ngen)+lin_wind[k-1]+lin_load[k-1])-tauGD)+m.sum( d_vectorconjunta[m]*vtildeLD[i,k,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLD[i,k,l] for l in set_nwind)for i in set_knn for k in set_nlines  ))
    
        c83=m.add_constraints(( muGD[i]>=m.sum( d_vectorconjunta[m]*vtildeLD[i,Nlines+1,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLD[i,Nlines+1,l] for l in set_nwind) for i in set_knn   ))






            
        c84=m.add_constraints((  zLD[i,k,l]<= lambdaGD for i in set_knn for k in set_pieces_lines for l in set_nwind )) 
        c85=m.add_constraints((  -zLD[i,k,l]<= lambdaGD for i in set_knn for k in set_pieces_lines for l in set_nwind )) 
    
        c86=m.add_constraints((  vLD[i,k,l]== m.sum( CT[l,n]*vtildeLD[i,k,n] for n in dim_d_vector) for i in set_knn for k in set_pieces_lines for l in set_nwind )) 


    
        c87=m.add_constraints((  zLD[i,k,l]-vLD[i,k,l]==-(-PTDF_wind[k-1,l-1] + m.sum( PTDF_gen[k-1,j-1]*beta[j] for  j in set_ngen)  )    for i in set_knn for k in set_nlines for l in set_nwind )) 
    
        c88=m.add_constraints((  zLD[i,Nlines+1,l]-vLD[i,Nlines+1,l]==-(0   )  for i in set_knn for l in set_nwind ))


        print("creo restricciones de linea LU") 
        zLU=m.continuous_var_dict(list(product(set_knn,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vLU=m.continuous_var_dict(list(product(set_knn,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vtildeLU=m.continuous_var_dict(list(product(set_knn,set_pieces_lines,dim_d_vector)),lb=0)


        
        
       
    
       
        
        
        c92=m.add_constraints(( muGD[i]>=(-capline[k]+(m.sum( PTDF_gen[k-1,j-1]*g[j] for j in set_ngen)+lin_wind[k-1]+lin_load[k-1])-tauGD)+m.sum( d_vectorconjunta[m]*vtildeLU[i,k,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLU[i,k,l] for l in set_nwind)for i in set_knn for k in set_nlines  ))
    
        c93=m.add_constraints(( muGD[i]>=m.sum( d_vectorconjunta[m]*vtildeLU[i,Nlines+1,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLU[i,Nlines+1,l] for l in set_nwind) for i in set_knn   ))






            
        c94=m.add_constraints((  zLU[i,k,l]<= lambdaGD for i in set_knn for k in set_pieces_lines for l in set_nwind )) 
        c95=m.add_constraints((  -zLU[i,k,l]<= lambdaGD for i in set_knn for k in set_pieces_lines for l in set_nwind )) 
    
        c96=m.add_constraints((  vLU[i,k,l]== m.sum( CT[l,n]*vtildeLU[i,k,n] for n in dim_d_vector) for i in set_knn for k in set_pieces_lines for l in set_nwind )) 


    
        c97=m.add_constraints((  zLU[i,k,l]-vLU[i,k,l]==-(PTDF_wind[k-1,l-1]  -m.sum( PTDF_gen[k-1,j-1]*beta[j] for  j in set_ngen)  )    for i in set_knn for k in set_nlines for l in set_nwind )) 
    
        c98=m.add_constraints((  zLU[i,Nlines+1,l]-vLU[i,Nlines+1,l]==-(0   )  for i in set_knn for l in set_nwind ))
        
    
              
     
        c10=m.add_constraint(m.sum(g)==sum(load[b] for b in set_nbus)-sum(forecasted_wind[j] for j in set_nwind) )     
              
              
        c11=m.add_constraint(m.sum(beta)==1)      
              
        c12=m.add_constraints((  g[j]+r_U[j]<=gmax[j] for j in set_ngen  ))           

        c13=m.add_constraints((  g[j]-r_D[j]>=gmin[j] for j in set_ngen  )) 


        m.parameters.threads.set(6)
        m.parameters.preprocessing.dual.set(1)
        m.parameters.lpmethod.set(4)
        m.solve(log_output = True)
                
        sol = m.solution
        

        print("Obj value kuhn-->", sol.objective_value)
        
        array_gen1kuhn=np.append(array_gen1kuhn, (sol.get_value_dict(g))[1])
        array_gen2kuhn=np.append(array_gen2kuhn, (sol.get_value_dict(g))[2])
        array_gen3kuhn=np.append(array_gen3kuhn, (sol.get_value_dict(g))[3])
        array_beta1kuhn=np.append(array_beta1kuhn, (sol.get_value_dict(beta))[1])
        array_beta2kuhn=np.append(array_beta2kuhn, (sol.get_value_dict(beta))[2])
        array_beta3kuhn=np.append(array_beta3kuhn, (sol.get_value_dict(beta))[3])

        dfgen=np.asarray(list((sol.get_value_dict(g)).values()))
        dfbeta=np.asarray(list((sol.get_value_dict(beta)).values()))
        dfr_D=np.asarray(list((sol.get_value_dict(r_D)).values()))
        dfr_U=np.asarray(list((sol.get_value_dict(r_U)).values()))
        

        
        reserv_totkuhn_D=dfr_D.sum()
        reserv_totkuhn_U=dfr_U.sum()
                
        array_reserv_totkuhn_D=np.append(array_reserv_totkuhn_D,reserv_totkuhn_D)
        array_reserv_totkuhn_U=np.append(array_reserv_totkuhn_U,reserv_totkuhn_U)
        
        
        aa = pd.DataFrame()
        for s in range(len(set_knn_real)):
            plus =  list( (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) + np.array(list(-dfr_D)).reshape(len(set_ngen))) 
            plus += list(  - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) - np.array(list(dfr_U)).reshape(len(set_ngen))  )
            
            plus += list(-PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s])) - np.array(list(capline.values())).reshape(len(set_nlines)))
            plus += list(PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s])) - np.array(list(capline.values())).reshape(len(set_nlines)))


            aa.loc[s,'violation'] = max(plus)
        
        
        violation_prob_condicional_kuhn=len(aa.loc[aa['violation'] > 1e-6])/len(set_knn_real)
        print("violation_prob_condicional_kuhn",violation_prob_condicional_kuhn)

        m2 = Model('test_redispatch')
        
        
        m2=real_dispatch_piecewise_mixed_cplex(m2,index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_MATRIX,PTDF_gen,PTDF_wind,capline)
        
 
        
        m2.solve(log_output = True)
                
        sol2 = m2.solution
        

        print("Obj value knn redespacho-->", sol2.objective_value)
        actual_expected_cost_kuhn=sol2.objective_value       
    

        
        print("coste real esperado conjunto knn",actual_expected_cost_kuhn) 
        
        

        print("violation_prob_condicional_kuhn",violation_prob_condicional_kuhn)
        array_outofsamplecondkuhn=np.append(array_outofsamplecondkuhn,violation_prob_condicional_kuhn)
        array_performancecondkuhn=np.append(array_performancecondkuhn,actual_expected_cost_kuhn)





        data_f2kuhn.append(array_reserv_totkuhn_D)
        data_g2kuhn.append(array_reserv_totkuhn_U)


        
        data_a25kuhn.append(array_performancecondkuhn)
        full_file_path = os.getcwd()
        
        
        
        
        data_a24kuhn.append(array_outofsamplecondkuhn)
        
        dfdata_a24kuhn=pd.DataFrame(data_a24kuhn)
        dfdata_a24kuhn.to_csv('data_a24kuhn'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_a25kuhn=pd.DataFrame(data_a25kuhn)
        dfdata_a25kuhn.to_csv('data_a25kuhn'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_f2kuhn=pd.DataFrame(data_f2kuhn)
        dfdata_f2kuhn.to_csv('data_f2kuhn'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)

        dfdata_g2kuhn=pd.DataFrame(data_g2kuhn)
        dfdata_g2kuhn.to_csv('data_g2kuhn'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)


        data_gen1kuhn.append(array_gen1kuhn)
        data_gen2kuhn.append(array_gen2kuhn)
        data_gen3kuhn.append(array_gen3kuhn)

        data_beta1kuhn.append(array_beta1kuhn)
        data_beta2kuhn.append(array_beta2kuhn)
        data_beta3kuhn.append(array_beta3kuhn)
        
        
        
        
        
        
       
        
        dfdata_gen1kuhn=pd.DataFrame(data_gen1kuhn)
        dfdata_gen1kuhn.to_csv('data_gen1kuhn'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_gen2kuhn=pd.DataFrame(data_gen2kuhn)
        dfdata_gen2kuhn.to_csv('data_gen2kuhn'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_gen3kuhn=pd.DataFrame(data_gen3kuhn)
        dfdata_gen3kuhn.to_csv('data_gen3kuhn'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)



        dfdata_beta1kuhn=pd.DataFrame(data_beta1kuhn)
        dfdata_beta1kuhn.to_csv('data_beta1kuhn'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_beta2kuhn=pd.DataFrame(data_beta2kuhn)
        dfdata_beta2kuhn.to_csv('data_beta2kuhn'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_beta3kuhn=pd.DataFrame(data_beta3kuhn)
        dfdata_beta3kuhn.to_csv('data_beta3kuhn'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False) 

    elif metodo==2:
        #modelo R_1-K/N           
        frec_kn={}
        media_kncost={}
       
    
        
      
        

        
        
        kn=math.floor(Nsamples/(math.log(Nsamples+1)))
    #    print("valor k modelo 1-k/n",value_knchosen) 
        # kn=math.floor(math.pow(Nsamples,0.9))
        set_kn=list(range(1, kn+1))

       
        mass=kn/Nsamples
        set_i=range(1,Nsamples+1)
        
        
        
        #knn=numkn
        #knn=math.floor(math.pow(n_mixt_real,0.75))
        #set_knnrobust_boot=list(range(1, kn+1))
        from sklearn.neighbors import KNeighborsRegressor
        neigh = KNeighborsRegressor(n_neighbors=kn,metric='minkowski',p=1)
        #        print("XX[:,0].reshape(-1, 1)", XX[:,0].reshape(-1, 1))
        #        print("y ", XX[:,1])
        puntos_zkn_array=muestra_conjunta_sample[:,[0]]
        puntos_ykn_array=muestra_conjunta_sample[:,[1,2]]
        
        puntos_omegakn_array=muestra_conjunta_sample[:,[1]]
        # print("puntos_omegakn_array",puntos_omegakn_array)
        puntos_Omegakn_array=(muestra_conjunta_sample[:,[2]]).reshape(Nsamples,)
        
        puntos_omegakn_array_proj=muestra_conjunta_sample[:,[1]]
        puntos_Omegakn_array_proj=(muestra_conjunta_sample[:,[2]]).reshape(Nsamples,)
    
        zdata=array_to_dict(puntos_zkn_array)
        # print("zdata",zdata)
        omegadata=array_to_dict(puntos_omegakn_array)
        Omegadata=array_to_dict(puntos_Omegakn_array )
        mass2=mass
        
        
        

        lista_dist_min_sorted= { i :sorted((e,i) for i,e in enumerate(lista_dist_min))[i] for i in range(0, len(sorted((e,i) for i,e in enumerate(lista_dist_min))) ) }
   
        lista_dist_min_sortedOmega= { i :sorted((e,i) for i,e in enumerate(lista_dist_minOmega))[i] for i in range(0, len(sorted((e,i) for i,e in enumerate(lista_dist_minOmega))) ) }



        
 
            
            
            
                
        dist_mediaknn_boot=0
        dist_mediaknn_bootOmega=0       
        for ii in list(range(1,math.ceil(Nsamples*mass)+1)):
            dist_mediaknn_boot=dist_mediaknn_boot+(1/(Nsamples*mass))*lista_dist_min_sorted[ii-1][0]
            dist_mediaknn_bootOmega=dist_mediaknn_bootOmega+(1/(Nsamples*mass))*lista_dist_min_sortedOmega[ii-1][0]
            print("dist_mediaknn_boot",dist_mediaknn_boot)
           
        dist_mediaknn_boot=dist_mediaknn_boot+(1-(math.floor(Nsamples*mass))/(Nsamples*mass))*lista_dist_min_sorted[math.floor(Nsamples*mass)-1][0]
        dist_mediaknn_bootOmega=dist_mediaknn_bootOmega+(1-(math.floor(Nsamples*mass))/(Nsamples*mass))*lista_dist_min_sortedOmega[math.floor(Nsamples*mass)-1][0]
           
        
        
        
        dist_trimm_recinto= dist_mediaknn_boot

        radio_rokn_totkn=b1+dist_trimm_recinto
        radio_rokn_totknOmega=b1+dist_mediaknn_bootOmega
        rho2=b1+dist_trimm_recinto
        print("radio_rokn_totkn",radio_rokn_totkn)
        print("dist_mediaknn_bootOmega calculanmdo la distancia al recinto",dist_mediaknn_bootOmega)
        
        
        

        
        
        m =Model('test_trimm') 
        

        tt=m.continuous_var_dict(list(set_i),lb=-float('inf'))
        tup=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf'))        
        tdown=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf'))
        tdata=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf')) 
        mubarra=m.continuous_var_dict(list(set_i),lb=0)
        
 
    
        r_D=m.continuous_var_dict(list(set_ngen),lb=0)
        r_U=m.continuous_var_dict(list(set_ngen),lb=0)
        g=m.continuous_var_dict(list(set_ngen),lb=-float('inf'))
        beta=m.continuous_var_dict(list(set_ngen),lb=0,ub=1)
        lamb=m.continuous_var(lb=0)
        theta=m.continuous_var(lb=-float('inf'))
         


        
        
        
        m.minimize(radio_rokn_totknOmega*lamb+theta+(1/(Nsamples*mass))*m.sum(mubarra[i] for i in set_i)+m.sum(coste_reserv_d[j]*(r_D[j])+coste_reserv_u[j]*(r_U[j])  for j in set_ngen) )
            
        c1=m.add_constraints((  mubarra[i]>=-theta-lamb*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+tt[i] for i in set_i   ))
        


        if len(lista_index_outsideOmega_left )>0:
            c11=m.add_constraints((tt[i]>=m.sum(tdown[i,j] for j in set_ngen) -lamb*(liminf_Omega_cond-Omegadata[i]) for i  in lista_index_outsideOmega_left ))
            c21=m.add_constraints((tt[i]>=m.sum(tup[i,j] for j in set_ngen) -lamb*(limsup_Omega_cond-Omegadata[i]) for i  in lista_index_outsideOmega_left ))
            
        if len(lista_index_outsideOmega_right)>0:
            c12=m.add_constraints((tt[i]>=m.sum(tdown[i,j] for j in set_ngen) +lamb*(liminf_Omega_cond-Omegadata[i]) for i   in lista_index_outsideOmega_right ))
            c22=m.add_constraints((tt[i]>=m.sum(tup[i,j] for j in set_ngen) +lamb*(limsup_Omega_cond-Omegadata[i]) for i   in lista_index_outsideOmega_right ))


        
        
        
        c13=m.add_constraints((tt[i]>=m.sum(tdown[i,j] for j in set_ngen) +lamb*(liminf_Omega_cond-Omegadata[i]) for i  in lista_index_interval ))
        
        c2=m.add_constraints((  tdown[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*liminf_Omega_cond)+intercepts_gen[j,s] for i in set_i for j in set_ngen for s in set_pieces  ))
        
  
        
        
        c23=m.add_constraints((tt[i]>=m.sum(tup[i,j] for j in set_ngen) -lamb*(limsup_Omega_cond-Omegadata[i]) for i  in lista_index_interval ))
        

        c3=m.add_constraints((  tup[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*limsup_Omega_cond)+intercepts_gen[j,s] for i in set_i for j in set_ngen for s in set_pieces  ))
             
            
        c32=m.add_constraints((  tt[i]>=m.sum(tdata[i,j] for j in set_ngen) for i in lista_index_interval  ))       

        c33=m.add_constraints((  tdata[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*Omegadata[i])+intercepts_gen[j,s] for i in lista_index_interval for j in set_ngen for s in set_pieces ))
        

        
        tauGD=m.continuous_var(lb=-float('inf'))   
        lambdaGD=m.continuous_var(lb=0)
        thetaGD=m.continuous_var(lb=-float('inf'))
        muGD=m.continuous_var_dict(list(set_i),lb=0)
        dim_d_vector=list(range(1,len(d_vector)+1))

        
      

        
        c4=m.add_constraint(tauGD+(1/epsGD)*(lambdaGD*rho2+thetaGD+(1/(Nsamples*mass2))*m.sum(muGD[i]   for i in set_i))<=0)
    
     


        zRD=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vRD=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vtildeRD=m.continuous_var_dict(list(product(set_i,set_pieces_gen,dim_d_vector)),lb=0)

    
        c62=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+(-r_D[k]-tauGD)+m.sum( d_vector[m]*vtildeRD[i,k,m] for  m in dim_d_vector)\
            -m.sum(omegadata[i,l]*zRD[i,k,l] for l in set_nwind) for i in set_i for k in set_ngen  ))
    
        c63=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+m.sum( d_vector[m]*vtildeRD[i,Ngen+1,m] for  m in dim_d_vector)\
            -m.sum(omegadata[i,l]*zRD[i,Ngen+1,l] for l in set_nwind) for i in set_i   ))








            
        c64=m.add_constraints((  zRD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
        c65=m.add_constraints((  -zRD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
    
        c66=m.add_constraints((  vRD[i,k,l]== m.sum( CT[l,n]*vtildeRD[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_gen for l in set_nwind )) 


    
        c67=m.add_constraints((  zRD[i,k,l]-vRD[i,k,l]==-(beta[k]   )  for i in set_i for k in set_ngen for l in set_nwind )) 
    
        c68=m.add_constraints((  zRD[i,Ngen+1,l]-vRD[i,Ngen+1,l]==-(0   )  for i in set_i for l in set_nwind )) 

        
        zRU=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vRU=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vtildeRU=m.continuous_var_dict(list(product(set_i,set_pieces_gen,dim_d_vector)),lb=0)

        
    
        c72=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+(-r_U[k]-tauGD)+m.sum( d_vector[m]*vtildeRU[i,k,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zRU[i,k,l] for l in set_nwind)for i in set_i for k in set_ngen  ))
    
        c73=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+m.sum( d_vector[m]*vtildeRU[i,Ngen+1,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zRU[i,Ngen+1,l] for l in set_nwind) for i in set_i   ))








            
        c74=m.add_constraints((  zRU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
        c75=m.add_constraints((  -zRU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
    
        c76=m.add_constraints((  vRU[i,k,l]== m.sum( CT[l,n]*vtildeRU[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_gen for l in set_nwind )) 


    
        c77=m.add_constraints((  zRU[i,k,l]-vRU[i,k,l]==-(-beta[k]   )  for i in set_i for k in set_ngen for l in set_nwind )) 
    
        c78=m.add_constraints((  zRU[i,Ngen+1,l]-vRU[i,Ngen+1,l]==-(0   )  for i in set_i for l in set_nwind ))

 




        
        zLD=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vLD=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vtildeLD=m.continuous_var_dict(list(product(set_i,set_pieces_lines,dim_d_vector)),lb=0)

        PTDF_gen=PTDF_MATRIX.transpose() @ (array_matrixGbus)
        PTDF_wind=PTDF_MATRIX.transpose() @ (array_matrixHbus)
        
        lin_load=[sum([ (PTDF_MATRIX[b-1,k-1])*(-load[b]) for b in set_nbus] ) for k in set_nlines]
        
        lin_wind=[sum([ (PTDF_wind[k-1,mm-1]*(forecasted_wind[mm])) for mm in set_nwind]) for k in set_nlines]
        
        
       
        print("creo restricciones de linea ld")
       
        
        
        c82=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+(-capline[k]-(m.sum( PTDF_gen[k-1,j-1]*g[j] for j in set_ngen)+lin_wind[k-1]+lin_load[k-1])-tauGD)+m.sum( d_vector[m]*vtildeLD[i,k,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLD[i,k,l] for l in set_nwind)for i in set_i for k in set_nlines  ))
    
        c83=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+m.sum( d_vector[m]*vtildeLD[i,Nlines+1,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLD[i,Nlines+1,l] for l in set_nwind) for i in set_i   ))






            
        c84=m.add_constraints((  zLD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
        c85=m.add_constraints((  -zLD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
    
        c86=m.add_constraints((  vLD[i,k,l]== m.sum( CT[l,n]*vtildeLD[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_lines for l in set_nwind )) 


    
        c87=m.add_constraints((  zLD[i,k,l]-vLD[i,k,l]==-(-PTDF_wind[k-1,l-1] + m.sum( PTDF_gen[k-1,j-1]*beta[j] for  j in set_ngen)  )    for i in set_i for k in set_nlines for l in set_nwind )) 
    
        c88=m.add_constraints((  zLD[i,Nlines+1,l]-vLD[i,Nlines+1,l]==-(0   )  for i in set_i for l in set_nwind ))


        print("creo restricciones de linea LU") 
        zLU=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vLU=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vtildeLU=m.continuous_var_dict(list(product(set_i,set_pieces_lines,dim_d_vector)),lb=0)


        
        
       
    
       
        
        
        c92=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+(-capline[k]+(m.sum( PTDF_gen[k-1,j-1]*g[j] for j in set_ngen)+lin_wind[k-1]+lin_load[k-1])-tauGD)+m.sum( d_vector[m]*vtildeLU[i,k,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLU[i,k,l] for l in set_nwind)for i in set_i for k in set_nlines  ))
    
        c93=m.add_constraints(( muGD[i]>=-thetaGD-lambdaGD*(sum(abs(zdata[i,p]-zpred[p]) for p in set_p))+m.sum( d_vector[m]*vtildeLU[i,Nlines+1,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLU[i,Nlines+1,l] for l in set_nwind) for i in set_i   ))






            
        c94=m.add_constraints((  zLU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
        c95=m.add_constraints((  -zLU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
    
        c96=m.add_constraints((  vLU[i,k,l]== m.sum( CT[l,n]*vtildeLU[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_lines for l in set_nwind )) 


    
        c97=m.add_constraints((  zLU[i,k,l]-vLU[i,k,l]==-(PTDF_wind[k-1,l-1]  -m.sum( PTDF_gen[k-1,j-1]*beta[j] for  j in set_ngen)  )    for i in set_i for k in set_nlines for l in set_nwind )) 
    
        c98=m.add_constraints((  zLU[i,Nlines+1,l]-vLU[i,Nlines+1,l]==-(0   )  for i in set_i for l in set_nwind ))
        
    
              
     
        c10=m.add_constraint(m.sum(g)==sum(load[b] for b in set_nbus)-sum(forecasted_wind[j] for j in set_nwind) )     
              
              
        c11=m.add_constraint(m.sum(beta)==1)      
              
        c12=m.add_constraints((  g[j]+r_U[j]<=gmax[j] for j in set_ngen  ))           

        c13=m.add_constraints((  g[j]-r_D[j]>=gmin[j] for j in set_ngen  )) 


        m.parameters.threads.set(6)
        m.parameters.preprocessing.dual.set(1)
        m.parameters.lpmethod.set(4)
        m.solve(log_output = True)
                
        sol = m.solution
        

        print("Obj value trimm-->", sol.objective_value)
        


        array_gen1=np.append(array_gen1, (sol.get_value_dict(g))[1])
        array_gen2=np.append(array_gen2, (sol.get_value_dict(g))[2])
        array_gen3=np.append(array_gen3, (sol.get_value_dict(g))[3])
        array_beta1=np.append(array_beta1, (sol.get_value_dict(beta))[1])
        array_beta2=np.append(array_beta2, (sol.get_value_dict(beta))[2])
        array_beta3=np.append(array_beta3, (sol.get_value_dict(beta))[3])

        dfgen=np.asarray(list((sol.get_value_dict(g)).values()))
        dfbeta=np.asarray(list((sol.get_value_dict(beta)).values()))
        dfr_D=np.asarray(list((sol.get_value_dict(r_D)).values()))
        dfr_U=np.asarray(list((sol.get_value_dict(r_U)).values()))
        aa = pd.DataFrame()
        for s in range(len(set_knn_real)):
            plus =  list( (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) + np.array(list(-dfr_D)).reshape(len(set_ngen))) 
            plus += list(  - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) - np.array(list(dfr_U)).reshape(len(set_ngen))  )
            
            plus += list(-PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s])) - np.array(list(capline.values())).reshape(len(set_nlines)))
            plus += list(PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s])) - np.array(list(capline.values())).reshape(len(set_nlines)))


            aa.loc[s,'violation'] = max(plus)
        
        
        violation_prob_condicional_kn=len(aa.loc[aa['violation'] > 1e-6])/len(set_knn_real)
        print("violation_prob_condicional_trimm",violation_prob_condicional_kn)

        m2 = Model('test_redispatch')
        
        
        m2=real_dispatch_piecewise_mixed_cplex(m2,index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_MATRIX,PTDF_gen,PTDF_wind,capline)
        
 
        
        m2.solve(log_output = True)
                
        sol2 = m2.solution
        

        print("Obj value trimm-->", sol2.objective_value)
        actual_expected_cost_kn=sol2.objective_value
        print("actual_expected_cost_trimm",actual_expected_cost_kn)
            
        reserv_tot_D=dfr_D.sum()
        reserv_tot_U=dfr_U.sum()
                
        array_reserv_tot_D=np.append(array_reserv_tot_D,reserv_tot_D)
        array_reserv_tot_U=np.append(array_reserv_tot_U,reserv_tot_U)    
            

    
        array_outofsamplecond=np.append(array_outofsamplecond,violation_prob_condicional_kn)
        # print("violation_prob_condicional_kn",violation_prob_condicional_kn)
        array_performancecond=np.append(array_performancecond,actual_expected_cost_kn)
        
        data_f2.append(array_reserv_tot_D)
        data_g2.append(array_reserv_tot_U)

        
        data_a25.append(array_performancecond)
        full_file_path = os.getcwd()
        
        
        
        
        data_a24.append(array_outofsamplecond)
        
        dfdata_a24=pd.DataFrame(data_a24)
        dfdata_a24.to_csv('data_a24'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        # data_a25knn.append(array_outofsamplecondknn)
        dfdata_a25=pd.DataFrame(data_a25)
        dfdata_a25.to_csv('data_a25'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        # data_f2knn.append(array_outofsamplecondknn)
        dfdata_f2=pd.DataFrame(data_f2)
        dfdata_f2.to_csv('data_f2'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_g2=pd.DataFrame(data_g2)
        dfdata_g2.to_csv('data_g2'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        
        
        data_gen1.append(array_gen1)
        data_gen2.append(array_gen2)
        data_gen3.append(array_gen3)
        
        data_beta1.append(array_beta1)
        data_beta2.append(array_beta2)
        data_beta3.append(array_beta3)
        
        
        
        
        
        
        
        
        dfdata_gen1=pd.DataFrame(data_gen1)
        dfdata_gen1.to_csv('data_gen1'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_gen2=pd.DataFrame(data_gen2)
        dfdata_gen2.to_csv('data_gen2'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_gen3=pd.DataFrame(data_gen3)
        dfdata_gen3.to_csv('data_gen3'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        
        
        dfdata_beta1=pd.DataFrame(data_beta1)
        dfdata_beta1.to_csv('data_beta1'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_beta2=pd.DataFrame(data_beta2)
        dfdata_beta2.to_csv('data_beta2'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_beta3=pd.DataFrame(data_beta3)
        dfdata_beta3.to_csv('data_beta3'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)     
            
            
            
            
            
            
            
            
            
            
            
            
            


    else:
        set_Nsamples=list(range(1, Nsamples+1))
        
        ydata_dict=array_to_dict(puntos_omegakn_array)
        omegadata=ydata_dict
        Omegadatadict=array_to_dict(puntos_Omegakn_array)
        Omegadata=Omegadatadict
        rho2kuhnnoside=b1
        
        # if nocreado_pasadamodel:
            # modelo_dcopf1kuhnnoside=DCOPF_2kuhn_linear_piecewise(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,b1,set_pieces_gen,set_pieces_lines,set_Nsamples,set_l,set_p, set_ngen,set_nwind,set_nbus,set_nlines,Nsamples,ydata_dict,Omegadatadict,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,load, forecasted_wind,liminf_Omega_conjunta,limsup_Omega_conjunta,matrixGbus,matrixHbus,gmin,gmax,PTDF_dict,capline,rho2kuhnnoside,epsGD,CT,d_vectorconjunta)
            # modelo_dcopf1kuhn=DCOPF_2kuhn_linear_piecewise(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,b1,set_pieces_gen,set_pieces_lines,set_knn,set_l,set_p, set_ngen,set_nwind,set_nbus,set_nlines, knn,ydataknnproj_dict,Omegadataknnproj,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,load, forecasted_wind,liminf_Omega_cond,limsup_Omega_cond,matrixGbus,matrixHbus,gmin,gmax,PTDF_dict,capline,rho2kuhn,epsGD,CT,d_vector)
        
        # else:
        #     modelo_dcopf1kuhnnoside.ro =rho2kuhnnoside
        #     modelo_dcopf1kuhnnoside.rho2 =rho2kuhnnoside
        
        m =Model('test_kuhn') 
        tt=m.continuous_var_dict(list(set_i),lb=-float('inf'))
        tup=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf'))        
        tdown=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf'))
        tdata=m.continuous_var_dict(list(product(set_i,set_ngen)),lb=-float('inf')) 
        mubarra=m.continuous_var_dict(list(set_i),lb=-float('inf'))
        
 
    
        r_D=m.continuous_var_dict(list(set_ngen),lb=0)
        r_U=m.continuous_var_dict(list(set_ngen),lb=0)
        g=m.continuous_var_dict(list(set_ngen),lb=-float('inf'))
        beta=m.continuous_var_dict(list(set_ngen),lb=0,ub=1)
        lamb=m.continuous_var(lb=0)
        # theta=m.continuous_var(lb=-float('inf'))
         



                

                

        
        
        m.minimize(rho2kuhnnoside*lamb+(1/(Nsamples))*m.sum(mubarra[i] for i in set_i)+m.sum(coste_reserv_d[j]*(r_D[j])+coste_reserv_u[j]*(r_U[j])  for j in set_ngen) )
            
        c1=m.add_constraints((  mubarra[i]>=tt[i] for i in set_i   ))
        



        
        
        
        c13=m.add_constraints((tt[i]>=m.sum(tdown[i,j] for j in set_ngen) +lamb*(liminf_Omega_conjunta-Omegadata[i]) for i  in set_i ))
        
        c2=m.add_constraints((  tdown[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*liminf_Omega_conjunta)+intercepts_gen[j,s] for i in set_i for j in set_ngen for s in set_pieces  ))
        
  
        
        
        c23=m.add_constraints((tt[i]>=m.sum(tup[i,j] for j in set_ngen) -lamb*(limsup_Omega_conjunta-Omegadata[i]) for i  in set_i ))
        

        c3=m.add_constraints((  tup[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*limsup_Omega_conjunta)+intercepts_gen[j,s] for i in set_i for j in set_ngen for s in set_pieces  ))
             
            
        c32=m.add_constraints((  tt[i]>=m.sum(tdata[i,j] for j in set_ngen) for i in set_i  ))       

        c33=m.add_constraints((  tdata[i,j]>=slopes_gen[j,s]*(g[j]-beta[j]*Omegadata[i])+intercepts_gen[j,s] for i in set_i for j in set_ngen for s in set_pieces ))
        

        
        tauGD=m.continuous_var(lb=-float('inf'))   
        lambdaGD=m.continuous_var(lb=0)
        # thetaGD=m.continuous_var(lb=-float('inf'))
        muGD=m.continuous_var_dict(list(set_i),lb=-float('inf'))

        dim_d_vector=list(range(1,len(d_vectorconjunta)+1))

        


        
        c4=m.add_constraint(tauGD+(1/epsGD)*(lambdaGD*rho2kuhnnoside+(1/(Nsamples))*m.sum(muGD[i]   for i in set_i))<=0)
    



        zRD=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vRD=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vtildeRD=m.continuous_var_dict(list(product(set_i,set_pieces_gen,dim_d_vector)),lb=0)

    
        c62=m.add_constraints(( muGD[i]>=(-r_D[k]-tauGD)+m.sum( d_vectorconjunta[m]*vtildeRD[i,k,m] for  m in dim_d_vector)\
            -m.sum(omegadata[i,l]*zRD[i,k,l] for l in set_nwind) for i in set_i for k in set_ngen  ))
    
        c63=m.add_constraints(( muGD[i]>=m.sum( d_vectorconjunta[m]*vtildeRD[i,Ngen+1,m] for  m in dim_d_vector)\
            -m.sum(omegadata[i,l]*zRD[i,Ngen+1,l] for l in set_nwind) for i in set_i   ))








            
        c64=m.add_constraints((  zRD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
        c65=m.add_constraints((  -zRD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
    
        c66=m.add_constraints((  vRD[i,k,l]== m.sum( CT[l,n]*vtildeRD[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_gen for l in set_nwind )) 


    
        c67=m.add_constraints((  zRD[i,k,l]-vRD[i,k,l]==-(beta[k]   )  for i in set_i for k in set_ngen for l in set_nwind )) 
    
        c68=m.add_constraints((  zRD[i,Ngen+1,l]-vRD[i,Ngen+1,l]==-(0   )  for i in set_i for l in set_nwind )) 

        
        zRU=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vRU=m.continuous_var_dict(list(product(set_i,set_pieces_gen,set_nwind)),lb=-float('inf'))
        vtildeRU=m.continuous_var_dict(list(product(set_i,set_pieces_gen,dim_d_vector)),lb=0)

        
    
        c72=m.add_constraints(( muGD[i]>=(-r_U[k]-tauGD)+m.sum( d_vectorconjunta[m]*vtildeRU[i,k,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zRU[i,k,l] for l in set_nwind)for i in set_i for k in set_ngen  ))
    
        c73=m.add_constraints(( muGD[i]>=m.sum( d_vectorconjunta[m]*vtildeRU[i,Ngen+1,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zRU[i,Ngen+1,l] for l in set_nwind) for i in set_i   ))








            
        c74=m.add_constraints((  zRU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
        c75=m.add_constraints((  -zRU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_gen for l in set_nwind )) 
    
        c76=m.add_constraints((  vRU[i,k,l]== m.sum( CT[l,n]*vtildeRU[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_gen for l in set_nwind )) 


    
        c77=m.add_constraints((  zRU[i,k,l]-vRU[i,k,l]==-(-beta[k]   )  for i in set_i for k in set_ngen for l in set_nwind )) 
    
        c78=m.add_constraints((  zRU[i,Ngen+1,l]-vRU[i,Ngen+1,l]==-(0   )  for i in set_i for l in set_nwind ))

 




        
        zLD=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vLD=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vtildeLD=m.continuous_var_dict(list(product(set_i,set_pieces_lines,dim_d_vector)),lb=0)

        PTDF_gen=PTDF_MATRIX.transpose() @ (array_matrixGbus)
        PTDF_wind=PTDF_MATRIX.transpose() @ (array_matrixHbus)
        
        lin_load=[sum([ (PTDF_MATRIX[b-1,k-1])*(-load[b]) for b in set_nbus] ) for k in set_nlines]
        
        lin_wind=[sum([ (PTDF_wind[k-1,mm-1]*(forecasted_wind[mm])) for mm in set_nwind]) for k in set_nlines]
        
        
       
        print("creo restricciones de linea ld")
       
        
        
        c82=m.add_constraints(( muGD[i]>=(-capline[k]-(m.sum( PTDF_gen[k-1,j-1]*g[j] for j in set_ngen)+lin_wind[k-1]+lin_load[k-1])-tauGD)+m.sum( d_vectorconjunta[m]*vtildeLD[i,k,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLD[i,k,l] for l in set_nwind)for i in set_i for k in set_nlines  ))
    
        c83=m.add_constraints(( muGD[i]>=m.sum( d_vectorconjunta[m]*vtildeLD[i,Nlines+1,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLD[i,Nlines+1,l] for l in set_nwind) for i in set_i   ))






            
        c84=m.add_constraints((  zLD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
        c85=m.add_constraints((  -zLD[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
    
        c86=m.add_constraints((  vLD[i,k,l]== m.sum( CT[l,n]*vtildeLD[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_lines for l in set_nwind )) 


    
        c87=m.add_constraints((  zLD[i,k,l]-vLD[i,k,l]==-(-PTDF_wind[k-1,l-1] + m.sum( PTDF_gen[k-1,j-1]*beta[j] for  j in set_ngen)  )    for i in set_i for k in set_nlines for l in set_nwind )) 
    
        c88=m.add_constraints((  zLD[i,Nlines+1,l]-vLD[i,Nlines+1,l]==-(0   )  for i in set_i for l in set_nwind ))


        print("creo restricciones de linea LU") 
        zLU=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vLU=m.continuous_var_dict(list(product(set_i,set_pieces_lines,set_nwind)),lb=-float('inf'))
        vtildeLU=m.continuous_var_dict(list(product(set_i,set_pieces_lines,dim_d_vector)),lb=0)


        
        
       
    
       
        
        
        c92=m.add_constraints(( muGD[i]>=(-capline[k]+(m.sum( PTDF_gen[k-1,j-1]*g[j] for j in set_ngen)+lin_wind[k-1]+lin_load[k-1])-tauGD)+m.sum( d_vectorconjunta[m]*vtildeLU[i,k,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLU[i,k,l] for l in set_nwind)for i in set_i for k in set_nlines  ))
    
        c93=m.add_constraints(( muGD[i]>=m.sum( d_vectorconjunta[m]*vtildeLU[i,Nlines+1,m] for  m in dim_d_vector)\
            -m.sum( omegadata[i,l]*zLU[i,Nlines+1,l] for l in set_nwind) for i in set_i   ))






            
        c94=m.add_constraints((  zLU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
        c95=m.add_constraints((  -zLU[i,k,l]<= lambdaGD for i in set_i for k in set_pieces_lines for l in set_nwind )) 
    
        c96=m.add_constraints((  vLU[i,k,l]== m.sum( CT[l,n]*vtildeLU[i,k,n] for n in dim_d_vector) for i in set_i for k in set_pieces_lines for l in set_nwind )) 


    
        c97=m.add_constraints((  zLU[i,k,l]-vLU[i,k,l]==-(PTDF_wind[k-1,l-1]  -m.sum( PTDF_gen[k-1,j-1]*beta[j] for  j in set_ngen)  )    for i in set_i for k in set_nlines for l in set_nwind )) 
    
        c98=m.add_constraints((  zLU[i,Nlines+1,l]-vLU[i,Nlines+1,l]==-(0   )  for i in set_i for l in set_nwind ))
        
    
              
     
        c10=m.add_constraint(m.sum(g)==sum(load[b] for b in set_nbus)-sum(forecasted_wind[j] for j in set_nwind) )     
              
              
        c11=m.add_constraint(m.sum(beta)==1)      
              
        c12=m.add_constraints((  g[j]+r_U[j]<=gmax[j] for j in set_ngen  ))           

        c13=m.add_constraints((  g[j]-r_D[j]>=gmin[j] for j in set_ngen  )) 


        m.parameters.threads.set(6)
        m.parameters.preprocessing.dual.set(1)
        m.parameters.lpmethod.set(4)
        m.solve(log_output = True)
                
        sol = m.solution
        
        # m.setParam('PreDual',1)
        # m.setParam('Presolve',2)
        # # m.setParam('Method',3)
        # # m.setParam('BarConvTol',1e-5)          
        # m.setParam('BarHomogeneous',1)
        # # m.setParam('ScaleFlag',3)
        # m.setParam('Threads',6)
        # m.setParam('CrossoverBasis',1)
        # m.setParam('NumericFocus',1)
        # m.optimize()
        print("Obj value kuhn-->", sol.objective_value)
        
        array_gen1kuhnnoside=np.append(array_gen1kuhnnoside, (sol.get_value_dict(g))[1])
        array_gen2kuhnnoside=np.append(array_gen2kuhnnoside, (sol.get_value_dict(g))[2])
        array_gen3kuhnnoside=np.append(array_gen3kuhnnoside, (sol.get_value_dict(g))[3])
        array_beta1kuhnnoside=np.append(array_beta1kuhnnoside, (sol.get_value_dict(beta))[1])
        array_beta2kuhnnoside=np.append(array_beta2kuhnnoside, (sol.get_value_dict(beta))[2])
        array_beta3kuhnnoside=np.append(array_beta3kuhnnoside, (sol.get_value_dict(beta))[3])

        dfgen=np.asarray(list((sol.get_value_dict(g)).values()))
        dfbeta=np.asarray(list((sol.get_value_dict(beta)).values()))
        dfr_D=np.asarray(list((sol.get_value_dict(r_D)).values()))
        dfr_U=np.asarray(list((sol.get_value_dict(r_U)).values()))
        
        
        
        
        
        
        
        aa = pd.DataFrame()
        for s in range(len(set_knn_real)):
            # plus =  list( -dfgen.reshape(len(set_ngen)) + (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) + np.array(list(gmin.values())).reshape(len(set_ngen)))
            # plus += list(  dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) - np.array(list(gmax.values())).reshape(len(set_ngen)))
            plus =  list( (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) + np.array(list(-dfr_D)).reshape(len(set_ngen))) 
            plus += list(  - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen)) - np.array(list(dfr_U)).reshape(len(set_ngen))  )
            
            # plus += list(-PTDF_MATRIX @ (in_gen @(dfgen.values.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta.values).reshape(len(set_ngen))) - net_l + scen[s,:]) - np.array(list(capline.values())).reshape(len(set_nlines)))
            # plus += list( PTDF_MATRIX @ (in_gen @(dfgen.values.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta.values).reshape(len(set_ngen))) - net_l + scen[s,:]) - np.array(list(capline.values())).reshape(len(set_nlines)))
            plus += list(-PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s])) - np.array(list(capline.values())).reshape(len(set_nlines)))
            plus += list(PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s])) - np.array(list(capline.values())).reshape(len(set_nlines)))

            # model.addConstrs((gp.LinExpr([(lin_gen[l,g],gen[g]) for g in range(num_g)]) - omega[s]*gp.LinExpr([(lin_gen[l,g],factor[g]) for g in range(num_g)]) - lin_load[l] + lin_ome[l,s] >= -Pmax_l[l] - Mmin_l[s,l]*(1-y[s]) for l in line_index for s in range(num_s) if line_cons_min.at[s,l] == True))
            # plus += list(PTDF_MATRIX.transpose() @ (array_matrixGbus @(dfgen.reshape(len(set_ngen)) - (Omegadataknnreal[s+1] * dfbeta).reshape(len(set_ngen))) - np.array(list(load.values())).reshape(len(set_nbus)) + array_matrixHbus@(np.array(list(forecasted_wind.values())).reshape(len(set_nwind))+ydataknnreal[s])) - np.array(list(capline.values())).reshape(len(set_nlines)))

            aa.loc[s,'violation'] = max(plus)
        
        
        violation_prob_condicional_kuhnnoside=len(aa.loc[aa['violation'] > 1e-6])/len(set_knn_real)
        # violation_prob_condicional_scen2=eps_violation(index_genbus,index_windbus,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,Omegadataknnreal,ydataknnreal_dict,set_ngen,set_nlines,set_nwind,set_nbus,gmin,gmax,capline,PTDF_dict,load,matrixGbus, matrixHbus,forecasted_wind)
        print("violation_prob_condicional_kuhn",violation_prob_condicional_kuhnnoside)
        # print("violation_prob_condicional_scen2 metodo antiguo",violation_prob_condicional_scen2)
        
        # actual_expected_cost_scen=actual_expected_cost_linear_piecewise(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)

        
        # actual_expected_cost_scen=actual_expected_cost_linear_piecewise_beta(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)
        # actual_expected_cost_scen=actual_expected_cost_linear_piecewise_mixedgurobi(index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,len(set_knn_real),dfgen.to_dict()['g'],dfbeta.to_dict()['beta'],dfr_D.to_dict()['r_D'],dfr_U.to_dict()['r_U'],coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_dict,capline)
        # actual_expected_cost_scen=(1/len(set_knn_real))*sum( sum(max([slopes_gen[j,s]*(  (dfgen.values[j-1])[0]-(dfbeta.values[j-1])[0]*(Omegadataknnreal[i+1]))+intercepts_gen[j,s] for s in set_pieces]) +coste_reserv_d[j]*((dfr_D.values[j-1])[0])+coste_reserv_u[j]*((dfr_U.values[j-1])[0]) for j in set_ngen)      for i in range(len(set_knn_real))    )
        # actual_expected_cost_linear_piecewise_mixedgurobi
        m2 = Model('test_redispatch')
        
        
        m2=real_dispatch_piecewise_mixed_cplex(m2,index_genbus,index_windbus,set_pieces,slopes_gen,intercepts_gen,dfgen,dfbeta,dfr_D,dfr_U,coste1,coste2,coste3,coste_reserv_d,coste_reserv_u,Omegadataknnreal,ydataknnreal,set_ngen,set_nlines,set_nwind,set_nbus,load,forecasted_wind,set_knn_real,set_l,set_p,gmin,gmax,PTDF_MATRIX,PTDF_gen,PTDF_wind,capline)
        
 
        
        m2.solve(log_output = True)
                
        sol2 = m2.solution
        
        # m.setParam('PreDual',1)
        # m.setParam('Presolve',2)
        # # m.setParam('Method',3)
        # # m.setParam('BarConvTol',1e-5)          
        # m.setParam('BarHomogeneous',1)
        # # m.setParam('ScaleFlag',3)
        # m.setParam('Threads',6)
        # m.setParam('CrossoverBasis',1)
        # m.setParam('NumericFocus',1)
        # m.optimize()
        print("Obj value kuhn redespacho-->", sol2.objective_value)
        actual_expected_cost_kuhnnoside=sol2.objective_value
        
        reserv_totkuhnnoside_D=dfr_D.sum()
        reserv_totkuhnnoside_U=dfr_U.sum()
        
    
        print("actual_expected_cost_kuhnnoside",actual_expected_cost_kuhnnoside)
    

        
        reserv_totkuhnnoside_D=dfr_D.sum()
        reserv_totkuhnnoside_U=dfr_U.sum()
                
        array_reserv_totkuhnnoside_D=np.append(array_reserv_totkuhnnoside_D,reserv_totkuhnnoside_D)
        array_reserv_totkuhnnoside_U=np.append(array_reserv_totkuhnnoside_U,reserv_totkuhnnoside_U)


        # print("violation_prob_condicional_kuhnnoside",violation_prob_condicional_kuhnnoside)
        # violation_prob_condicional_kuhnnoside=eps_violation(len(set_knn_real),dfgen,dfbeta,dfr_D,dfr_U,Omegadataknnreal,ydataknnreal_dict,set_ngen,set_nlines,set_nwind,set_nbus,gmin,gmax,capline,PTDF_dict,load,matrixGbus, matrixHbus,forecasted_wind)
        print("violation_prob_condicional_kuhnnoside",violation_prob_condicional_kuhnnoside)
        array_outofsamplecondkuhnnoside=np.append(array_outofsamplecondkuhnnoside,violation_prob_condicional_kuhnnoside)
        array_performancecondkuhnnoside=np.append(array_performancecondkuhnnoside,actual_expected_cost_kuhnnoside)
        
        data_f2kuhnnoside.append(array_reserv_totkuhnnoside_D)
        data_g2kuhnnoside.append(array_reserv_totkuhnnoside_U)


        
        data_a25kuhnnoside.append(array_performancecondkuhnnoside)
        full_file_path = os.getcwd()
        
        
        
        
        data_a24kuhnnoside.append(array_outofsamplecondkuhnnoside)
        
        dfdata_a24kuhnnoside=pd.DataFrame(data_a24kuhnnoside)
        dfdata_a24kuhnnoside.to_csv('data_a24kuhnnoside'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        # data_a25knn.append(array_outofsamplecondknn)
        dfdata_a25kuhnnoside=pd.DataFrame(data_a25kuhnnoside)
        dfdata_a25kuhnnoside.to_csv('data_a25kuhnnoside'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        # data_f2knn.append(array_outofsamplecondknn)
        dfdata_f2kuhnnoside=pd.DataFrame(data_f2kuhnnoside)
        dfdata_f2kuhnnoside.to_csv('data_f2kuhnnoside'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)

        dfdata_g2kuhnnoside=pd.DataFrame(data_g2kuhnnoside)
        dfdata_g2kuhnnoside.to_csv('data_g2kuhnnoside'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)




        data_gen1kuhnnoside.append(array_gen1kuhnnoside)
        data_gen2kuhnnoside.append(array_gen2kuhnnoside)
        data_gen3kuhnnoside.append(array_gen3kuhnnoside)

        data_beta1kuhnnoside.append(array_beta1kuhnnoside)
        data_beta2kuhnnoside.append(array_beta2kuhnnoside)
        data_beta3kuhnnoside.append(array_beta3kuhnnoside)
        
        
        
        
        
        
       
        
        dfdata_gen1kuhnnoside=pd.DataFrame(data_gen1kuhnnoside)
        dfdata_gen1kuhnnoside.to_csv('data_gen1kuhnnoside'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_gen2kuhnnoside=pd.DataFrame(data_gen2kuhnnoside)
        dfdata_gen2kuhnnoside.to_csv('data_gen2kuhnnoside'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_gen3kuhnnoside=pd.DataFrame(data_gen3kuhnnoside)
        dfdata_gen3kuhnnoside.to_csv('data_gen3kuhnnoside'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)



        dfdata_beta1kuhnnoside=pd.DataFrame(data_beta1kuhnnoside)
        dfdata_beta1kuhnnoside.to_csv('data_beta1kuhnnoside'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_beta2kuhnnoside=pd.DataFrame(data_beta2kuhnnoside)
        dfdata_beta2kuhnnoside.to_csv('data_beta2kuhnnoside'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)
        
        dfdata_beta3kuhnnoside=pd.DataFrame(data_beta3kuhnnoside)
        dfdata_beta3kuhnnoside.to_csv('data_beta3kuhnnoside'+str(index_samplepicasso)+'.csv', mode='w',index=False,header=False)    
    















