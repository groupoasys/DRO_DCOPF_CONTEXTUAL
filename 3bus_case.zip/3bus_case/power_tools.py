# -*- coding: utf-8 -*-
"""
Created on Fri Nov  6 16:04:35 2020

@author: Usuario
"""


import pandas
import numpy
from dataclasses import dataclass

@dataclass
class Labels:
    from_bus: str = 'from bus'
    to_bus: str = 'to bus'
    impedance: str = 'Z'
    resistance: str = 'R'
    reactance: str = 'X'
    admittance: str = 'Y'
    conductance: str = 'G'
    susceptance: str = 'B'
    capacity: str = 'C'
    shunt_susceptance: str = 'b_shunt'


def build_admittance_matrix(input_data, ref_node=None):
    """Computes the B matrix. It assumes pandas DataFrame input of the form:
    index, from bus, to bus, X
    2,     101,      102,    0.013
    17,    101,      104,    0.015
    where the index of the DataFrame is the index of each line (row).
    """

    input_data = input_data.copy()
    line_index = list(input_data.index)
    columns = input_data.columns

    # Checks
    if Labels.reactance in columns and Labels.susceptance in columns:
        raise ValueError('X and B was specified, erase one to compute the matrix.\n'
                         'Rename B as b_shunt if B refers to shunt susceptance.')
    elif Labels.reactance in columns:
        mode = 'from_impedance'
        try:
            input_data[Labels.resistance]
        except KeyError:
            input_data[Labels.resistance] = 0
    elif Labels.susceptance in columns:
        mode = 'from_admittance'
        try:
            input_data[Labels.conductance]
        except KeyError:
            input_data[Labels.conductance] = 0
    else:
        raise ValueError('Neither reactance nor susceptance was indicated. ')

    if len(line_index) != len(set(line_index)):
        raise ValueError('There are two lines with the same index.')

    if ref_node is not None:
        ref_node = int(ref_node)

    from_set = set(list(input_data[Labels.from_bus].values))
    to_set = set(list(input_data[Labels.to_bus].values))
    node_set = from_set.union(to_set)
    n_nodes = len(node_set)

    B_N = pandas.DataFrame(numpy.zeros((n_nodes, n_nodes)), index=node_set, columns=node_set)
    G_N = pandas.DataFrame(numpy.zeros((n_nodes, n_nodes)), index=node_set, columns=node_set)

    # Off-diagonal elements B-matrix
    for i in line_index:
        from_bus = input_data.at[i, Labels.from_bus]
        to_bus = input_data.at[i, Labels.to_bus]
        if mode == 'from_impedance':
            r_i = input_data.at[i, Labels.resistance]
            x_i = input_data.at[i, Labels.reactance]
            # G-matrix
            G_N.at[from_bus, to_bus] = -1 * (r_i / (r_i**2 + x_i**2))
            G_N.at[to_bus, from_bus] = -1 * (r_i / (r_i**2 + x_i**2))
            # B-matrix
            B_N.at[from_bus, to_bus] = -1 * (x_i / (r_i**2 + x_i**2))
            B_N.at[to_bus, from_bus] = -1 * (x_i / (r_i**2 + x_i**2))
        elif mode == 'from_admittance':
            g_i = input_data.at[i, Labels.conductance]
            b_i = input_data.at[i, Labels.susceptance]
            # G-matrix
            G_N.at[from_bus, to_bus] = -1 * g_i
            G_N.at[to_bus, from_bus] = -1 * g_i
            # B-matrix
            B_N.at[from_bus, to_bus] = -1 * b_i
            B_N.at[to_bus, from_bus] = -1 * b_i

    # Diagonal elements B-matrix
    for node in node_set:
        B_N.at[node, node] = -1 * sum(B_N.loc[node, :].values)
        G_N.at[node, node] = -1 * sum(G_N.loc[node, :].values)

    # Admittance shunt
    B_N = B_N + admittance_shunt_per_node(input_data)

    # Remove reference node
    if ref_node:
        B_N.drop(index=[ref_node], columns=[ref_node], inplace=True)
        G_N.drop(index=[ref_node], columns=[ref_node], inplace=True)

    Y_N = G_N - 1j * B_N

    return Y_N, G_N, B_N


def admittance_shunt_per_node(input_data):
    line_index = list(input_data.index)
    from_set = set(list(input_data[Labels.from_bus].values))
    to_set = set(list(input_data[Labels.to_bus].values))
    node_set = from_set.union(to_set)
    n_nodes = len(node_set)

    B_sh = pandas.DataFrame(numpy.zeros((n_nodes, n_nodes)), index=node_set, columns=node_set)
    if Labels.shunt_susceptance in input_data.columns:
        for i in line_index:
            from_bus = input_data.at[i, Labels.from_bus]
            to_bus = input_data.at[i, Labels.to_bus]
            B_sh.at[from_bus, from_bus] += input_data.at[i, Labels.shunt_susceptance] / 2
            B_sh.at[to_bus, to_bus] += input_data.at[i, Labels.shunt_susceptance] / 2
    return B_sh


def susceptance_shunt_per_line(input_data):
    line_index = list(input_data.index)
    from_set = set(list(input_data[Labels.from_bus].values))
    to_set = set(list(input_data[Labels.to_bus].values))
    node_set = from_set.union(to_set)
    n_nodes = len(node_set)

    b = pandas.DataFrame(numpy.zeros((n_nodes, n_nodes)), index=node_set, columns=node_set)
    if Labels.shunt_susceptance in input_data.columns:
        for i in line_index:
            from_bus = input_data.at[i, Labels.from_bus]
            to_bus = input_data.at[i, Labels.to_bus]
            b.at[from_bus, to_bus] = input_data.at[i, Labels.shunt_susceptance]
            b.at[to_bus, from_bus] = input_data.at[i, Labels.shunt_susceptance]
    return b


def compute_impedance_matrix(admittance_matrix=None, input_data=None, ref_node=None):

    if (admittance_matrix is None) and (input_data is None):
        raise ValueError('Either admittance matrix or input data is required.')
    if (input_data is not None) and (admittance_matrix is None):
        admittance_matrix, _, _ = build_admittance_matrix(input_data, ref_node)
    elif (admittance_matrix is not None) and (input_data is not None):
        print('Input data not used. Only admittance matrix is considered.')

    # Invert the admittance matrix
    impedance_matrix = pandas.DataFrame(
        numpy.linalg.inv(admittance_matrix.values),
        index=admittance_matrix.index,
        columns=admittance_matrix.columns,
    )

    return impedance_matrix


def build_b_l_matrix(input_data, ref_node=None):
    """Computes the B_L matrix. It assumes pandas DataFrame input of the form:
    index, from bus, to bus, X
    2,     101,      102,    0.013
    17,    101,      104,    0.015
    where the index of the DataFrame is the index of each line (row).
    """

    input_data = input_data.copy()
    line_index = list(input_data.index)
    columns = input_data.columns

    # Checks
    if Labels.reactance in columns and Labels.susceptance in columns:
        raise ValueError('X and B was specified, erase one to compute the matrix.\n'
                         'Rename B as b_shunt if B refers to shunt susceptance.')
    elif Labels.reactance in columns:
        mode = 'from_impedance'
        try:
            input_data[Labels.resistance]
        except KeyError:
            input_data[Labels.resistance] = 0
    elif Labels.susceptance in columns:
        mode = 'from_admittance'
        try:
            input_data[Labels.conductance]
        except KeyError:
            input_data[Labels.conductance] = 0
    else:
        raise ValueError('Neither reactance nor susceptance was indicated. ')

    if len(line_index) != len(set(line_index)):
        raise ValueError('There are two lines with the same index.')

    if ref_node is not None:
        ref_node = int(ref_node)

    from_set = set(list(input_data[Labels.from_bus].values))
    to_set = set(list(input_data[Labels.to_bus].values))
    node_set = from_set.union(to_set)
    n_nodes = len(node_set)

    # B_L matrix
    B_L = pandas.DataFrame(numpy.zeros((len(line_index), n_nodes)), index=line_index, columns=node_set)

    # Off-diagonal elements B-matrix

    for i in line_index:
        from_bus = input_data.at[i, Labels.from_bus]
        to_bus = input_data.at[i, Labels.to_bus]

        if mode == 'from_impedance':
            r_i = input_data.at[i, Labels.resistance]
            x_i = input_data.at[i, Labels.reactance]
            # B-matrix
            B_L.at[i, from_bus] = 1 * (x_i / (r_i**2 + x_i**2))
            B_L.at[i, to_bus] = -1 * (x_i / (r_i**2 + x_i**2))
        elif mode == 'from_admittance':
            g_i = input_data.at[i, Labels.conductance]
            b_i = input_data.at[i, Labels.susceptance]
            # B-matrix
            B_L.at[i, from_bus] = b_i
            B_L.at[i, to_bus] = -1 * b_i

    # Remove reference node

    if ref_node:
        B_L.drop(columns=[ref_node], inplace=True)

    return B_L


def compute_ptdf_matrix(input_data, ref_node=None):
    """Computes the PTDF matrix. It assumes pandas DataFrame input of the form:
    index, from bus, to bus, X
    2,     101,      102,    0.013
    17,    101,      104,    0.015
    where the index of the DataFrame is the index of each line (row).
    """

    input_data = input_data.copy()
    if ref_node is not None:
        ref_node = int(ref_node)

    _, _, B_NN = build_admittance_matrix(input_data, ref_node)
    B_LL = build_b_l_matrix(input_data, ref_node)

    PTDF_nrf = B_LL.values @ numpy.linalg.inv(B_NN.values)
    PTDF_nrf = pandas.DataFrame(PTDF_nrf, index=B_LL.index, columns=B_LL.columns)

    return PTDF_nrf